> **Generated:** Friday, May 08, 2026 at 09:52 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**SCOUT Authorized**

BCAX (Bicara Therapeutics) displays a robust institutional trend following a Bullish Break of Structure (BOS) at `$19.68`. However, the current setup fails the primary mathematical hurdle for a full **Sniper STRIKE** due to a Sortino Ratio of `1.08`, which sits well below our `2.0` requirement. Price is currently navigating a Bearish Liquidity Sweep at `$23.02` and is hitting a tactical ceiling characterized by heavy insider selling at 52-week highs.

The rationale for a **SCOUT** probe (0.5R) is based on the strong institutional backing from FMR LLC and T. Rowe Price, balanced against the "Sell the News" risk preceding the May 11 earnings report. We are seeking to capture a potential breakout above the `$24.05` Value Area High (VAH) while maintaining a tight risk profile to protect against a reversal into the Bullish Fair Value Gap (FVG) below.


***


# 2. Institutional News & Social Sentiment

*   **FMR LLC reports 2.10M shares in Bicara Therapeutics** (Source: Stock Titan, 2d ago)
*   **T. Rowe Price lists 10.1% stake in Bicara Therapeutics in 13G/A filing** (Source: Stock Titan, 4d ago)
*   **Bicara Therapeutics to Report Q1 2026 Financial Results on May 11, 2026** (Source: GlobeNewswire, 1d ago)
*   **CEO Claire Mazumdar Sells 15,000 Shares; CFO and COO also report significant sales** (Source: MarketBeat/Investing.com, 2-5d ago)
*   **Bicara Therapeutics stock hits 52-week high at $24.14** (Source: Investing.com, 1d ago)

**Sentiment Synthesis**: Institutional accumulation (Sword) is fighting against heavy executive profit-taking (Shield). The proximity to the earnings catalyst creates a high-volatility environment. Social sentiment remains cautiously bullish, focused on the "Breakthrough Status" and clinical progress, though the insider selling has introduced a layer of tactical skepticism.


***


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: Bullish (MTF BOS confirmed at `$19.68`)
*   **Macro Ceiling**: `$24.25` (52-week resistance)
*   **Primary Demand Zone**: `$17.63` - `$19.41` (Bullish Order Block)
*   **Intraday Imbalance**: Bullish FVG noted between `$22.26` and `$22.54`
*   **Liquidity Profile**: A Bearish Sweep occurred at `$23.02`. Price must hold above this level to invalidate the retail "double top" trap.
*   **Volume Anchor**: The 5-day Point of Control (POC) is established at `$22.97`, acting as the immediate magnet for price action.


***


# 4. Mathematical Hurdle

*   **Sortino Ratio**: `1.08` 
*   **Hurdle Status**: **FAIL** (Required: `2.0`)
*   **Downside Deviation**: `0.63%`
*   **ATR (5m)**: `0.34`

**Analysis**: While the directional bias is clear, the risk-adjusted return metric is insufficient for full capital deployment. The high downside deviation relative to current gains suggests that while the "Sword" is sharp, the "Shield" is currently thin.


***


# 5. Execution Parameters

Under the **Sniper Strategy**, we utilize the following parameters for a high-precision probe:

*   **Risk Unit (R)**: `$250`
*   **Tactical Allocation**: **SCOUT** (0.5R = `$125`)
*   **Strike Zone (Entry)**: `$23.35` (Near current market price/Session POC)
*   **Hard Stop**: `$22.65` (Below the session liquidity and FVG ceiling)
*   **Share Quantity**: `178` Shares
*   **Target (4:1 RR)**: `$26.15`


***


# 6. Risk Guardrails

*   **Kill Switch**: Close the position immediately if price accepts back below `$22.20`, as this indicates a failure of the current momentum and a likely re-test of the macro Order Block.
*   **MOC Exit**: If volatility (VIX) exceeds `25` near the close, exit the position at `3:55 PM` ET to avoid overnight gap risk, especially with the May 11 earnings catalyst approaching.
*   **Narrative Note**: We are essentially "Sniping" a breakout. If the `$24.14` high is not cleared with volume (RVOL > `2.0`), we anticipate a "Sell the News" liquidation event. Keep the scout size small and the stop disciplined.