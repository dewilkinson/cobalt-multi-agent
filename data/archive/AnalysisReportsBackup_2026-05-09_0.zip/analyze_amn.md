> **Generated:** Friday, May 08, 2026 at 12:34 PM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


The tactical assessment for **AMN** confirms a high-probability **Sniper** setup. The asset has undergone a structural **Change of Character (CHoCH)** at `$21.6050`, signaling a definitive shift from institutional distribution to aggressive accumulation. With a **Sortino Ratio of 6.51**, the ticker far exceeds our internal efficiency hurdle of `2.0`, indicating that price volatility is heavily skewed toward the upside with minimal downside leakage. 


The current price action is characterized by "Thin Air" expansion. Having cleared the high-volume nodes and established a massive **Bullish Fair Value Gap (FVG)** between `$21.38` and `$24.20`, the stock is now hunting for external buy-side liquidity above `$27.00`. We are deploying a **Sword** position here to capture high-velocity momentum.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


[DATA_UNAVAILABLE]


---


# 3. TECHNICAL & STRUCTURAL AUDIT (SMC)


*   **Institutional Bias**: **Bullish** (Confirmed via CHoCH)
*   **Market Structure**: 
    *   **Change of Character (CHoCH)**: Established at `$21.6050`.
    *   **Bullish Order Block (OB)**: Located at `$17.44` – `$18.48` (Deep Discount).
    *   **Fair Value Gap (FVG)**: Massive expansion void from `$21.38` to `$24.20`.
*   **Volume Profile Analysis**: 
    *   **Macro POC**: `$20.70` (Point of Control).
    *   **Value Area High (VAH)**: `$21.95`.
    *   **Current State**: Price is trading significantly above the Value Area, indicating an imbalance phase where price is seeking a new fair value at higher levels.


---


# 4. MATHEMATICAL EFFICIENCY (SORTINO)


*   **Sortino Ratio**: `6.51`
*   **Downside Deviation**: `0.41%`
*   **Hurdle Status**: **PASS** 


The Sortino Ratio confirms that for every unit of downside risk, the asset is generating significantly higher risk-adjusted returns compared to the benchmark. This is an optimal environment for a **Sniper** execution, where we prioritize precision and high Reward-to-Risk (RR) ratios.


---


# 5. EXECUTION PARAMETERS


*   **Strategy**: **Sniper (4:1 RR Focus)**
*   **Execution State**: **STRIKE**
*   **Entry Zone (Strike)**: `$26.66`
*   **Hard Stop**: `$25.66` (Protects against session mean-reversion)
*   **Primary Target (4R)**: `$30.66`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` **Shares**


---


# 6. RISK GUARDRAILS & MONITORING


*   **Kill Switch**: A daily close below `$24.20` (the upper bound of the FVG) invalidates the immediate expansion thesis and requires an immediate exit to preserve capital.
*   **Trailing Protocol**: Once price reaches **2R** (`$28.66`), the Hard Stop must be moved to **Break-Even** (`$26.66`) to eliminate principal risk.
*   **Volatility Warning**: Current **ATR** is `0.33`. Ensure the stop distance remains wider than the 5-minute noise floor to avoid premature "stop-outs" before the momentum move completes.