> **Generated:** Friday, May 08, 2026 at 10:08 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**STRIKE Authorized** 


The institutional analysis for `DSGN` confirms a high-conviction **Sniper** entry profile. The ticker has transitioned from a ranging phase into a clear institutional expansion, validated by a Macro Break of Structure (**BOS**) at `$10.97`. This "Sword" asset is currently riding a wave of fundamental momentum following a Q1 earnings beat and significant price target revisions from top-tier analysts at Oppenheimer and Jefferies. 


The technical narrative is driven by a strong displacement leg that has left an unfilled Fair Value Gap (**FVG**) between `$13.77` and `$13.96`. We are authorizing a **STRIKE** execution on a tactical retracement to this zone. The synthesis of a `$2.51` Sortino Ratio and a robust `$222.8M` cash runway provides the mathematical and fundamental margin of safety required for a professional risk-managed entry. 


---


# 2. Institutional News & Social Sentiment

*   **Oppenheimer (3h ago)**: Analyst maintains "Buy" rating and aggressively raises price target to `$21.00`, citing clinical progress in the Friedreich’s Ataxia program.
*   **MarketBeat (5h ago)**: `DSGN` reaches a new 52-week high following a Q1 2026 earnings beat, confirming institutional accumulation.
*   **Stock Titan (8h ago)**: Company confirms a cash runway extending into **2029** with `$222.8M` in liquidity, significantly de-risking the "Sword" profile.
*   **Jefferies (Yesterday)**: Initiated coverage with a "Buy" rating and a price target of `$15.00`.
*   **Social Sentiment**: Reddit/X sentiment is highly bullish, specifically focusing on the H2 2026 clinical catalysts (RESTORE-FA and DM1 programs). There is a noticeable shift from "speculative" to "institutional" ownership as major banks initiate coverage.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Strongly Bullish**
*   **Macro Structure (1d)**: Confirmed **BOS** at `$10.97`. Current price action represents the "Run" phase of the Sniper cycle.
*   **Tactical Anchor (5d)**: The Volume Profile reveals a Point of Control (**POC**) at `$13.22`, acting as the ultimate structural floor for this leg.
*   **Institutional Magnet**: A Bullish **FVG** exists between `$13.77` and `$13.96`. We expect institutional "Smart Money" to look for liquidity in this gap before continuing the expansion.
*   **Relative Strength**: `DSGN` is currently outperforming the `IBB` and `XBI` indices, showing independent institutional demand.


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: **Day Trading Sortino Ratio**
*   **Value**: `2.51`
*   **Status**: **PASS** (Hurdle: `> 2.0`)
*   **Interpretation**: The volatility is skewed heavily toward the upside. Downside deviation is constrained at `0.91%`, suggesting that sell-offs are being met with aggressive institutional absorption.


---


# 5. Execution Parameters

*   **Risk Unit (1R)**: `$250`
*   **Strike Zone (Entry)**: `$13.90` (Top of the 1h Bullish FVG)
*   **Hard Stop**: `$12.90` (Below the 5d POC and Tactical Order Block)
*   **Share Quantity**: `250` Shares
*   **Target (Sniper 4:1 RR)**: `$17.90` (Aligns with the Year-High liquidity sweep target)


---


# 6. Risk Guardrails

*   **Kill Switch**: `$12.31`. A daily close below the 5d **VAL** (Value Area Low) invalidates the current expansion thesis and triggers an immediate liquidation of all "Sword" units.
*   **Volatility Warning**: Be advised of the low intraday **ATR** of `$0.09`. This indicates a tight, controlled move. Any sudden spike in ATR `> 0.25` without price appreciation suggests institutional distribution, requiring an immediate move to **Break-Even**.
*   **MOC Exit**: If the trade is active and price is below `$13.50` at `3:55 PM ET`, exit the position regardless of the stop loss to preserve capital for the next session.


---


# 7. Analyst/Catalyst Intelligence

*   **Top Rating**: Oppenheimer Target `$21.00`
*   **Fundamental Floor**: `$222.8M` Cash (Runway to **2029**)
*   **Catalyst Horizon**: Multiple data readouts scheduled for **H2 2026** (RESTORE-FA).
*   **Institutional Ownership**: Increasing, evidenced by new coverage from Jefferies and RBC Capital.