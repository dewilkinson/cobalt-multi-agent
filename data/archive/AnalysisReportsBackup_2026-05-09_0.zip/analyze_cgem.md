> **Generated:** Friday, May 08, 2026 at 09:58 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**Recommendation: WAIT (RETAIN CASH)**


CGEM currently presents a conflict between macro structural alignment and immediate mathematical efficiency. While the **Institutional Macro Trend** is confirmed bullish following a Break of Structure (BOS) at `$13.33`, the asset fails the mandatory **Sortino Ratio** hurdle. The current reading of `0.78` sits significantly below our institutional requirement of `2.0`, indicating that recent volatility is not providing a high-fidelity risk-adjusted return.


Price is currently localized within a high-density "churn zone" between the **Macro POC** (`$14.14`) and the **Tactical 5-Day POC** (`$14.98`). Under the Sniper Strategy, we do not fire into the heart of the Volume Profile. We require a clean displacement above the current supply cluster to authorize a high-conviction strike. Until the Sortino Ratio stabilizes and price clears the `$14.98` resistance, capital remains sidelined to protect the daily 3R stop.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


**[DATA_UNAVAILABLE]**


---


# 3. TECHNICAL STRUCTURAL AUDIT


**Market Structure (Dual-Anchor Protocol)**

*   **Macro Institutional Trend**: Bullish (BOS confirmed at `$13.33`)
*   **Macro Ceiling (60d VAH)**: `$16.13`
*   **Value Area High (5d VAH)**: `$15.44`
*   **Tactical Displacement Pivot**: `$13.33` (Pivot for macro invalidation)


**Institutional Footprint & Liquidity**

*   **Order Block (Bullish)**: `$11.36` - `$12.48` (Primary zone for long-term accumulation)
*   **Fair Value Gaps (Bullish)**: `$13.66` - `$14.21` (Acting as an institutional magnet/support)
*   **Liquidity Pools**: Buy-side liquidity resides at `$16.13` (60d VAH breakout point).
*   **Current State**: Equilibrium. Price is "trapped" in the value area, lacking the impulsive displacement required for a Sniper entry.


---


# 4. MATHEMATICAL HURDLE (SORTINO)


*   **Hurdle Status**: **FAIL**
*   **Day Trading Sortino**: `0.78`
*   **Institutional Target**: `2.0`
*   **Analysis**: The asset is exhibiting excessive downside deviation relative to its upside capture during this session. This metric suggests that a "Strike" execution at this level carries a higher probability of a stop-out than a 4:1 reward realization.


---


# 5. EXECUTION PARAMETERS (CONTINGENT)


Execution is authorized **ONLY** upon a clean 5-minute candle close above the **Tactical POC** on relative volume (RVOL) > `2.0`. 


*   **Strike Zone (Entry)**: `$15.05` (Clearance of the 5-day volume cluster)
*   **Hard Stop**: `$14.05` (Protection below the Macro Point of Control)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` shares
*   **Target 1 (4:1 RR)**: `$19.05`


---


# 6. RISK GUARDRAILS


*   **Daily Stop**: `3R` (`$750` total account heat)
*   **Strategy Metric**: 40% Win Rate / 4:1 Reward-to-Risk.
*   **Kill Switch**: A breach below `$13.33` invalidates the macro bullish narrative and requires a full psychological reset.
*   **Volatility Check**: ATR (5m) is currently `$0.24`. Avoid entry if ATR expands beyond `$0.45` without a corresponding increase in price velocity.