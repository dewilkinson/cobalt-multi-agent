> **Generated:** Wednesday, May 06, 2026 at 09:35 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**SCOUT Authorized**

The analysis of **EBS** confirms a tactical shift in market structure, warranting a **0.5R SCOUT** entry. While the macro institutional trend remains bearish (Daily CHoCH at `$9.02`), the 5-minute chart has successfully reclaimed the **Tactical Displacement Pivot (DP)** at `$9.02`, signaling an internal **Change of Character (CHoCH)**. This price action, combined with a **Sortino Ratio** of `2.22`, suggests that the "Smart Money" is beginning to defend lower liquidity pools.

The current setup is a classic "Sword" play—high growth potential in a turnaround phase but carrying significant structural baggage. By utilizing a **SCOUT** (half-sized) entry, we mitigate the risk of the macro bearish trend while positioning for an asymmetric move toward the **Macro Ceiling** at `$14.06`.


---


# 2. Institutional News & Social Sentiment

*   **Emergent BioSolutions (EBS) Q1 EPS Profit Challenges Narrative** (Sahm - 4d ago)
    Reported Q1 2026 revenue of `$156.1M` and basic EPS of `$0.13`, providing a surprise quarterly profit despite trailing 12-month net losses of `$8.6M`.

*   **Director Insider Activity: Sales to Cover Tax Obligations** (Investing.com - 5d ago)
    Directors Keith Katkin and Donald DeGolyer sold shares (approx. `$128k` to `$130k` each) specifically to cover tax obligations from vested RSUs. This is interpreted as neutral-to-bullish "administrative" selling rather than a lack of confidence.

*   **SVP Paul Anthony Williams Awarded 100,111 RSUs** (Stock Titan - 5d ago)
    Significant equity grant following stockholder approval of the 2006 Stock Incentive Plan amendment, aligning executive incentives with long-term recovery.

*   **Q1 Revenue Drop of 30% Y/Y** (Stock Titan - 6d ago)
    Despite the EPS beat, a sharp revenue decline remains the primary fundamental headwind, keeping the "Shield" logic out of this ticker for now.


---


# 3. Execution Parameters

*   **Risk Unit (R)**: `$125` (`0.5R` Scout)
*   **Share Quantity**: `178 Shares`
*   **Strike Zone (Entry)**: `$9.15` - `$9.25`
*   **Hard Stop**: `$8.55` (Below the 5m Displacement Wick)
*   **Target 1 (1R Trailing Anchor)**: `$9.95`
*   **Target 2 (Macro Supply)**: `$10.96`


---


# 4. Technical & Structural Analysis

**Market Structure (SMC Framework)**:
*   **Macro Ceiling**: `$14.06` (The absolute high and ultimate exit target).
*   **Tactical DP**: `$9.02` (Successfully reclaimed; confirmed CHoCH).
*   **Bullish Order Block (OB)**: `$8.09` - `$8.10` (The "Hard Floor" where institutional buyers are anchored).
*   **Fair Value Gap (FVG)**: `$8.63` - `$9.12` (The institutional magnet that was recently filled and rejected).

**Tape Reading & Volume Profile**:
*   **POC (Point of Control)**: `$8.21` - `$8.24` (Consensus value area is significantly lower; we are trading in a high-momentum expansion zone).
*   **RVOL Validation**: Volume is currently accumulating at the `$9.22` level. A break above today's high would confirm a high-conviction momentum spike.


---


# 5. Mathematical Hurdle & Risk Guardrails

*   **Sortino Ratio**: `2.22` (**PASS**)
    The historical recovery math for **EBS** during intraday dips meets the Sniper mandate. A downside deviation of only `0.53%` indicates that volatility is skewed heavily to the upside during recent sessions.

*   **Dual-Anchor Protocol**:
    The trade is authorized because the price has reclaimed the **Tactical DP** (`$9.02`) and the **EMA 50**, despite not yet challenging the **Macro Ceiling**. 

*   **Kill Switch**:
    A total liquidation of the position is required if price closes below `$8.09` on a 1-hour candle, as this would invalidate the structural "Sword" recovery thesis. 

*   **Strategy Note**:
    If the position hits the `1R` target, engage the **1R Trailing Anchor** immediately. Scale to a full **STRIKE** (`1.0R`) only upon a confirmed 5-minute **Break of Structure (BoS)** above `$9.50` with `RVOL > 2.0`.