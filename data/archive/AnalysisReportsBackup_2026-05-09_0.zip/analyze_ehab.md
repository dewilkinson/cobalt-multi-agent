> **Generated:** Friday, May 08, 2026 at 10:10 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Retain Cash)**


The strategic audit for **EHAB** reveals a robust bullish institutional framework, characterized by a confirmed **CHoCH** at `$8.82` and a recent bullish liquidity sweep at `$13.79`. However, from a **Sniper Strategy** perspective, the ticker fails to clear the mandatory mathematical hurdle. The current **Sortino Ratio** of `0.36` is significantly below our institutional floor of `2.0`, indicating that the current price action lacks the risk-adjusted efficiency required for a high-conviction strike.


While the structural "Sword" potential is visible due to the aggressive upward displacement, the quality of the entry at these levels is poor. We are currently trading in a **Premium Zone** relative to the primary institutional demand. Execution is deferred until the risk-to-reward profile realigns with our `4:1` **Sniper** requirement or the **Sortino Ratio** scales above the threshold.


---


# 2. Institutional News & Social Sentiment

**[DATA_UNAVAILABLE]**


---


# 3. Execution Parameters (Contingent)

Should the mathematical profile shift to authorize an entry, the following parameters are established:

*   **Execution State**: **WAIT**
*   **Strike Zone (Entry)**: `$13.75` - `$13.80`
*   **Hard Stop**: `$12.75`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Target (4:1 RR)**: `$17.80`


---


# 4. Institutional Structural Audit (SMC)

**Market Structure & Narrative:**
*   **Institutional Trend**: **Bullish**. The macro landscape shifted with a **CHoCH** (Change of Character) at `$8.82`, confirming that "Smart Money" has transitioned from distribution to accumulation.
*   **Liquidity Profile**: A Bullish Liquidity Sweep was detected at `$13.79` on the 5m timeframe, suggesting local absorption of sell-side pressure.
*   **Value Areas**:
    *   **Macro POC**: `$13.67`
    *   **Tactical POC (5-Day)**: `$13.69`
    *   **Session POC**: `$13.69`
*   **Institutional Zones**:
    *   **Demand (Order Block)**: `$10.21` - `$10.49` (Deep Discount).
    *   **Fair Value Gap (FVG)**: A bullish gap exists between `$13.68` and `$14.04`, providing a thin layer of tactical support.


---


# 5. Risk & Performance Metrics

*   **Sortino Ratio**: `0.36` (Hurdle: `> 2.0`). This is the primary "Kill Switch" for the trade. The volatility-adjusted return is currently insufficient.
*   **Downside Deviation**: `0.18%`. While the risk of a "crash" is statistically low based on recent candles, the reward side of the equation is not compensating for the capital at risk.
*   **Volatility (ATR)**: `0.00` (5m expectation). This suggests a tightening range or a period of consolidation immediately following the previous expansion.
*   **RVOL Baseline**: Current volume at `70,100` shares is below the high-intensity accumulation requirement for a **Sniper** breakout.


---


# 6. Analyst Notes & Guardrails

**Sword vs. Shield Analysis**: 
**EHAB** is exhibiting "Sword" characteristics (high growth potential, aggressive structure), but it is currently a "Blunt Blade." We do not deploy capital into inefficient moves. 

**Tactical Warning**:
The proximity of bearish **Fair Value Gaps** between `$13.75` and `$14.04` suggests heavy overhead supply. For a **Sniper** to fire, we need to see price clear the `$14.04` level with high relative volume (**RVOL > 2.0**) to prove that institutions are willing to defend the new higher-value area. Until the **Sortino Ratio** reflects this strength, we remain in cash.

**Psych Reset**:
Adhere to the **CMA Risk Protocol**. This constitutes a non-event. No trade, no risk, capital preserved for the next `5R` opportunity.