> **Generated:** Thursday, May 07, 2026 at 06:30 AM

Active Strategy: Shield Strategy


# 1. EXECUTION SUMMARY

**SCOUT Authorized (Shield Class)**

The structural analysis of **$BIDU$** confirms a **Change of Character (CHoCH)** on both daily and hourly timeframes, signaling an institutional rotation toward defensive accumulation. With a **Sortino Ratio** of `2.97`, the asset comfortably clears our institutional hurdle ($\ge 2.0$), indicating superior risk-adjusted efficiency. While regulatory friction regarding robotaxi permits in China has created short-term "noise," the underlying tape shows aggressive absorption near the `$133.50` structural floor. 

As a **Shield** position in the current War Barbell, **$BIDU$** offers a "Safety Net" profile due to its AI asset revaluation and high relative strength compared to broader China-tech peers. We are initiating a **SCOUT** probe to navigate the regulatory headlines, with plans to scale into a full **STRIKE** once the tactical displacement pivot is cleared.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

*   **Baidu Group-SW (09888) Surges Over 6% as Market Focuses on AI Asset Revaluation** (Moomoo, 2h ago): Institutional focus is shifting toward the company's strong synergy in computing power and chip integration.
*   **Baidu Inc. (BIDU) Launches Upgraded General AI Agent** (Insider Monkey, 4h ago): Launch of GenFlow 4.0 and integration with OpenClaw is positioning Baidu Drive as a personal AI workspace.
*   **Is Baidu, Inc. (BIDU) The Best Chinese Stock to Buy According to Hedge Funds?** (Insider Monkey, 6h ago): Despite a `-14%` YTD decline, major analysts from Macquarie and BofA maintain positive ratings, anticipating an AI-driven turnaround.
*   **BIDU Shares Decline Following Robotaxi Permit Suspension** (GuruFocus, 8h ago): Chinese regulators have reportedly halted new licenses following a system malfunction in Wuhan, creating a tactical overhang.
*   **Should Baidu's (BIDU) Weaker EPS Outlook Recast Its AI Investment Story?** (Simply Wall Street, 10h ago): Analysts predict a double-digit earnings decline ahead of the May 18, 2026, earnings release, suggesting a "wait and see" approach from value-sensitive institutions.

**Sentiment Synthesis**: Social sentiment on Twitter/X and Stocktwits remains "Cautiously Bullish" as retail traders focus on the AI breakout, while institutional desks are carefully weighing the Robotaxi regulatory "Shield Wall" against the massive AI asset revaluation.


---


# 3. STRUCTURAL AUDIT & TAPE READING

*   **Market Structure**: **CHoCH Confirmed**. The break above `$138.50` has successfully invalidated the local supply chain, shifting the bias to Bullish Defense.
*   **Dual-Anchor Protocol**:
    *   **Macro Ceiling (Absolute High)**: `$165.30` (Primary Profit Target).
    *   **Tactical DP (Displacement Pivot)**: `$141.30` (The immediate hurdle for STRIKE authorization).
*   **The Shield Wall (Support Zones)**:
    *   **Bullish Order Block (OB)**: `$119.00` – `$122.80` (Foundational support).
    *   **Fair Value Gap (FVG)**: `$124.07` – `$125.19` (The "Safety Net" zone for dip absorption).
*   **Volume Profile Analysis**:
    *   **Macro POC**: `$124.37` (Heavy long-term accumulation).
    *   **Tactical POC**: `$126.16` (Short-term institutional value area).
    *   **Session VAH**: `$130.22`.


---


# 4. EXECUTION PARAMETERS

*   **Execution State**: **SCOUT (0.5R)**
*   **Risk Unit (R)**: `$125` (Reduced size for regulatory caution)
*   **Share Quantity**: `18 Shares`
*   **Strike Zone (Entry)**: `$138.50` – `$140.59`
*   **Hard Stop**: `$133.50` (Below the structural pivot/Shield Wall)
*   **Profit Target 1 (1R Anchor)**: `$147.94` (Session VAH / Bearish OB)
*   **Profit Target 2 (Macro)**: `$165.30` (Cycle High)


---


# 5. RISK GUARDRAILS & MONITORING

*   **The Sortino Mandate**: At `2.97`, **$BIDU$** exhibits very low downside deviation (`0.33%`). If the Sortino drops below `2.0` on a rolling 20-day window, the Shield is compromised.
*   **Volatility Check**: ATR (5m) is currently `0.30`. Intraday noise within this range should be ignored.
*   **Kill Switch**: A daily close below `$130.22` (Session VAL) invalidates the Bullish CHoCH and requires an immediate manual exit.
*   **Event Warning**: **Earnings expected May 18, 2026**. Position must be closed or hedged by 3:55 PM ET on May 17 to adhere to the Sortino Mandate.