> **Generated:** Friday, May 08, 2026 at 09:35 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY

**SCOUT Authorized**


The technical architecture for **AESI** (Atlas Energy Solutions) is currently in a high-velocity discovery phase, having cleared its primary institutional hurdle via a **Bullish BOS** at `$14.23`. While the macro trend is unequivocally bullish, the current lack of a valid Sortino Ratio (`0.0`) prevents a full-sized **STRIKE** execution under our strict risk protocols. 


We are authorizing a **SCOUT** probe (0.5R) to capitalize on the price action compressing between the Tactical POC of `$17.19` and the Buy-Side Liquidity pool at `$18.29`. This allows Dave and the team at Blueshell Securities to maintain exposure to this "Sword" asset while mitigating the risk of a mean-reversion move toward the institutional imbalance zones near `$16.50`.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

[DATA_UNAVAILABLE]


---


# 3. STRUCTURAL SMC AUDIT

*   **Institutional Trend**: **Bullish**. A confirmed Break of Structure (BOS) occurred at `$14.23`, shifting the macro bias from consolidation to aggressive expansion.


*   **Macro Map (1d)**:
    *   **Market Structure**: Bullish BOS at `$14.23`.
    *   **Hard Floor**: Bullish Order Block mapped between `$9.27` and `$10.06`.


*   **Tactical Map (1h)**:
    *   **Primary Gap**: Bullish FVG identified between `$16.50` and `$16.72`. This serves as the first major magnet for any corrective pullbacks.
    *   **Secondary Gap**: Bullish FVG between `$15.51` and `$15.98`.


*   **Execution Trigger (5m)**:
    *   **Liquidity Sweep**: A Bullish sweep was detected at `$18.29`. This level is our primary "Line in the Sand" for momentum continuation.


---


# 4. VOLUME PROFILE & FOOTPRINT

Our Tri-Mandate Volume Profile indicates that **AESI** has significantly decoupled from its long-term institutional value zones, signaling high relative strength (RS).


*   **Macro POC (60d)**: `$11.13` (Current price is trading `-61.45%` above this anchor).
*   **Macro VAH (60d)**: `$13.52` (Price has exited the value area, indicating a trending state).
*   **Tactical POC (Short-term)**: `$17.19` (This serves as our "Kill Switch" level).
*   **Current Price**: `$17.97`


---


# 5. EXECUTION PARAMETERS

Following the **Sniper Strategy** logic, we are hunting for a high-RR entry on the break of local liquidity.


*   **Strategy Tier**: **SCOUT** (0.5R)
*   **Risk Unit (R)**: `$125.00`
*   **Strike Zone (Entry)**: `$18.35` (Breakout confirmation above the sweep level)
*   **Hard Stop**: `$17.80` (Protecting below today’s micro-consolidation)
*   **Share Quantity**: `227 Shares`
*   **Target RR**: `4:1` (Estimated Target: `$20.55`)


---


# 6. RISK MANAGEMENT & GUARDRAILS

*   **Kill Switch**: If price closes below the Tactical POC of `$17.19`, the bullish thesis is invalidated for the intraday session.
*   **ATR Watch**: Current 5m ATR is `$0.19`. Expect moderate volatility during the entry sequence.
*   **Scale-In Protocol**: We will only scale the remaining `0.5R` (to reach a full STRIKE unit) once the initial **SCOUT** position reaches a `1:1` RR and stops are moved to Break-Even.
*   **Portfolio Balance**: As a "Sword" position, **AESI** represents high-growth potential. Ensure "Shield" positions (Low Vol/ETFs) are maintained to offset the discovery-phase volatility of this trade.