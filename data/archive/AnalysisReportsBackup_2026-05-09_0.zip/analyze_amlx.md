> **Generated:** Friday, May 08, 2026 at 09:38 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**Execution Authorization: WAIT**

The quantitative data for `AMLX` confirms a significant failure of the **Sniper Strategy** mathematical hurdles. While the Macro structure recently printed a Bullish Change of Character (`CHoCH`) at `15.6983`, the current session price of `$15.14` (a `-5.73%` decline) represents a total breakdown of tactical momentum. Most critically, the **Sortino Ratio** of `0.27` is vastly inferior to our institutional requirement of `2.0`, signaling that the downside volatility is uncompensated and dangerous.

The asset is currently in a "Liquidation Phase," having sliced through the 5-day Tactical Point of Control (`POC`) at `$17.01`. We are observing a "Falling Knife" scenario where the price is gravitating toward the Macro Volume Anchor at `$14.23`. Until the Sortino Ratio stabilizes and price re-claims the Tactical Pivot, no capital deployment is authorized.


***


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


***


# 3. Structural Audit & Tape Reading

*   **Market Structure**: Neutral-Bearish. The bullish `CHoCH` at `15.6983` has been invalidated on a closing basis, shifting the immediate bias to a deep retracement.
*   **Institutional Footprint**:
    *   **Bearish FVG**: A significant "Fair Value Gap" exists between `15.20` and `15.60`. This zone is now acting as a hard supply ceiling.
    *   **Value Area**: Price has exited the "Value Area High" (`VAH`) of `17.78` and is seeking the "Value Area Low" (`VAL`) near `$13.10`.
*   **Volume Profile**:
    *   **Macro POC**: `$14.23`. This is the primary magnet for the current sell-off.
    *   **Tactical POC**: `$17.01`. This level was defended by "Smart Money" for five days but has now been surrendered to the sellers.


***


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Sortino Ratio
*   **Current Value**: `0.27`
*   **Sniper Hurdle**: `2.0`
*   **Status**: **CRITICAL FAIL**
*   **Analysis**: The `0.69%` downside deviation relative to the lack of upward drift renders this "Sword" position blunt. The risk of further drawdown is mathematically high.


***


# 5. Execution Parameters

*   **Current State**: **WAIT / CASH**
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `0`
*   **Hypothetical Strike Zone**: `$14.25` - `$14.50` (Conditional on Macro POC interaction)
*   **Hard Stop**: `$13.75` (Below the Bullish Order Block)
*   **Target (4:1 RR)**: `$17.50`


***


# 6. Risk Guardrails

*   **Daily Stop Alert**: If `AMLX` breaches the Macro `VAL` of `$13.10`, the long-term bullish thesis is fully terminated.
*   **Tactical Requirement**: For a "Sniper" entry to be reconsidered, we require a "Liquidity Sweep" of the `$14.05` session lows followed by a high-volume recovery above the `$15.60` Bearish FVG.
*   **Psychological Reset**: After today's `-5.73%` flush, the system remains in **WAIT** mode to avoid revenge trading or catching a falling growth asset. We will prioritize "Shield" assets until the "Sword" (AMLX) shows signs of institutional accumulation at the `$14.23` anchor point.