> **Generated:** Thursday, May 07, 2026 at 04:37 PM

Active Strategy: Shield Strategy


# 1. Execution Summary


**STRIKE Authorized**


EFXT is exhibiting premier characteristics for a "Shield" allocation within the Blueshell Securities LLC "War Barbell" framework. The asset demonstrates high-fidelity institutional accumulation with a confirmed Macro Break of Structure (BOS) at `23.82`. Most critically, the strategy is validated by a **Sortino Ratio** of `4.90`, which effectively doubles our institutional requirement of `2.0`, signaling that the recent price appreciation is driven by consistent demand rather than high-risk volatility. 


The structural tape reading shows EFXT clearing local liquidity pools at `28.50` while maintaining a rigorous defense of tactical Fair Value Gaps (FVG). As an IRA-eligible, long-only defensive play, EFXT serves as a high-integrity stabilizer that protects the portfolio against broader macro downside while capturing alpha through institutional order flow.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading (Shield Focus)


*   **Institutional Bias**: **Bullish** (Confirmed by MTF Alignment)


*   **Market Structure**:
    *   **Macro Shield Floor (BOS)**: `23.82` (Structural breakout level)
    *   **Defensive Order Block**: `19.43` - `21.07` (Long-term institutional floor)
    *   **Tactical Displacement Pivot (POC)**: `25.54` (High-volume node for risk management)
    *   **Liquidity Ceiling**: `28.50` (Immediate target for capital expansion)


*   **Volume Metrics**:
    *   **Value Area High (VAH)**: `28.50`
    *   **Value Area Low (VAL)**: `22.19`
    *   **Price Status**: Pushing the upper boundaries of the tactical range, indicating high-conviction momentum.


---


# 4. Mathematical Hurdle (Sortino)


*   **Hurdle Result**: **PASS**
*   **Metric Value**: `4.90`
*   **Analysis**: This metric confirms that the "Shield" is providing maximum protection for the portfolio. A Sortino of `4.90` indicates that the upside volatility is strictly controlled and the downside deviation of `0.52%` is remarkably low for a `+2.94%` daily mover.


---


# 5. Execution Parameters


*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$28.30` - `$28.39`
*   **Share Quantity**: `210`
*   **Risk Unit (R)**: `$250`
*   **Hard Stop**: `$27.20`
*   **Target (Min 3:1 RR)**: `$31.96`


---


# 6. Risk Guardrails


*   **ATR (5m)**: `0.11` (Daily range is within expected boundaries for a Shield asset).
*   **Kill Switch**: Close position if price breaches the local pivot at `26.50`.
*   **Portfolio Balance**: This position adds low-beta stability to the growth-heavy "Sword" components of the IRA. Ensure the total "Shield" allocation aligns with current VIX levels. If VIX exceeds `26`, revert to SCOUT sizing as per the **CMA Risk Management Protocol**.


---


**Status: Active**
**Institutional Analyst: Dave Wilkinson (Blueshell Securities LLC)**