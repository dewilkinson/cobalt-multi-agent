> **Generated:** Friday, May 08, 2026 at 09:44 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


ASC (Ardmore Shipping Corporation) is currently operating as a high-velocity **Sword** asset, exhibiting extreme institutional efficiency and a clear breakout from mid-term value clusters. The asset has successfully transitioned from accumulation to an aggressive expansion phase, clearing its Macro POC of `$15.55` and its Tactical POC of `$15.40`. 


The primary rationale for this **STRIKE** is the convergence of a massive **Sortino Ratio** of `4.37` with a fundamental catalyst (dividend hike and fleet expansion). The price action is currently in a "liquidity vacuum" above `$19.20`, suggesting a path of least resistance toward the `$20.00` psychological barrier. We are looking to "snipe" an entry on a micro-pullback to structural support to maintain a high reward-to-risk ratio.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Ardmore Shipping Raises Dividend to $0.39 Per Share** (MarketBeat) - *3h ago*
*   **Ardmore Orders 2 New Tankers, Sells 1, Lifts Payout to Two-Thirds** (Stock Titan) - *5h ago*
*   **Tudor Investment Corp ET AL Invests $1.17 Million in ASC** (MarketBeat) - *1d ago*
*   **Ardmore Shipping Hits New 52-Week High of $17.34** (Markets Mojo) - *2d ago*
*   **American Century Companies Inc. Boosts Position in ASC** (MarketBeat) - *3d ago*


**Social Sentiment Synthesis**: Sentiment across specialized shipping and energy forums is overwhelmingly bullish. Retail interest is beginning to spike following the dividend announcement, but the tape shows heavy "Smart Money" accumulation from institutional desks like Tudor and American Century, suggesting this move is underpinned by professional capital rather than pure retail speculation.


---


# 3. STRUCTURAL AUDIT & TAPE READING


**Market Structure (Dual-Anchor Protocol)**


*   **Institutional Trend**: Bullish (CHoCH confirmed at `$13.55`)


*   **Market Structure**: Bullish Alignment (MTF)


*   **Macro Ceiling**: `$19.62` (Current price testing the outer edge of liquidity)


*   **Tactical Displacement Pivot**: `$17.86` (Previous breakout level, now structural floor)


*   **Value Area High (5d)**: `$17.86`


*   **Point of Control (Macro)**: `$15.55`


**Institutional Footprint (SMC)**


*   **Bullish Order Block**: `$14.87` - `$15.42`


*   **Key Fair Value Gap (FVG)**: `$17.85` - `$18.05` (Primary magnet for mean reversion)


*   **Liquidity Pool**: `$19.62` (Buy-side liquidity resting at the session peak)


---


# 4. MATHEMATICAL HURDLES


*   **Sortino Ratio**: `4.37` (**PASS**)


*   **Volatility (ATR 5m)**: `$0.05`


*   **Relative Volume (RVOL)**: High (Institutional accumulation baseline exceeded)


*   **Analysis**: The Sortino Ratio of `4.37` indicates exceptional risk-adjusted performance. The downside deviation is remarkably low at `0.42%`, confirming that the current volatility is skewed heavily to the upside—ideal for a Sniper execution.


---


# 5. EXECUTION PARAMETERS: THE SNIPER PATH


**Tactical Status**: **STRIKE Authorized**


*   **Entry Zone (Strike)**: `$18.85` - `$19.05`


*   **Hard Stop**: `$18.35`


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `500` Shares


*   **Profit Target (Initial)**: `$20.85` (Realizing a `4:1` RR)


---


# 6. RISK GUARDRAILS


*   **Daily Kill Switch**: Price closure below `$17.80` (5d VAL violation).


*   **Psychological Reset**: If 3 consecutive stop-outs occur across the portfolio, revert to `0.5R` Scouts.


*   **MOC Exit**: Close laggards at `3:55 PM` if VIX remains elevated or if momentum stalls below the `$19.00` handle.


*   **Tactical Note**: ASC is a pure momentum **Sword**. The volume profile indicates a "vacuum" above current levels. If the session high of `$19.62` is breached with volume expansion, expect a rapid move toward `$20.00+`. Maintain the tight stop at `$18.35` to protect the capital base while allowing for the high RR profile required by the Sniper strategy.