> **Generated:** Friday, May 08, 2026 at 09:47 AM

Active Strategy: Sniper Strategy

# Institutional Sniper Analysis: AVBP (ArriVent BioPharma)

---

### 1. Execution Summary

**STRIKE Authorized**

AVBP is currently exhibiting high-conviction institutional footprint characteristics following a major liquidity disclosure by **FMR LLC (Fidelity)**, which now holds a `6.8%` stake (`3.02M` shares). This fundamental catalyst is reinforced by aggressive price target revisions from **Citigroup** and **B. Riley** to `$45.00`. 

Technically, the asset has cleared its **Macro CHoCH** (Change of Character) at `$21.86` and recently completed a tactical **Liquidity Sweep** at `$28.83`. Under the **Sniper Strategy**, we are engaging this "Sword" position as it trades at a structural discount relative to the 5-day **Point of Control (POC)** of `$30.95`. The mathematical hurdle is cleared with a **Sortino Ratio** of `2.95`, indicating high-quality risk-adjusted momentum.

---

### 2. Institutional News & Social Sentiment

*   **Fidelity Disclosure (2h ago)**: FMR LLC disclosed a massive `6.8%` stake, signaling institutional "Smart Money" accumulation and long-term conviction.
*   **Analyst Upgrades (4h ago)**: **Citigroup** and **Guggenheim** reiterated "Buy" ratings, with Citi raising the price target to `$45.00` from previous levels.
*   **Technical Milestone (Daily)**: AVBP hit a new 52-week high of `$29.56`, confirming a **Value Breakout** state.
*   **Clinical Catalyst (Upcoming)**: ArriVent is scheduled to present preclinical data for **firmonertinib** and its ADC program at **AACR 2026**, providing an upcoming volatility window.
*   **Social Sentiment**: High-frequency mentions on institutional scanners suggest AVBP is being rotated into as a high-alpha "Sword" play while broader biotech indices (IBB/XBI) face consolidation.

---

### 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bullish** (Confirmed by MTF Alignment)
*   **Macro Structure (1D)**: **CHoCH** confirmed at `$21.86`. The long-term trend has shifted from accumulation to active markup.
*   **Tactical Zones (1H)**:
    *   **Bullish Order Block**: `$20.72` - `$21.51` (Primary Floor)
    *   **Fair Value Gap (FVG)**: `$27.81` - `$28.60` (Magnet Zone for mean reversion)
*   **Execution Trigger (5M)**: **Liquidity Sweep** identified at `$28.83`. This level served as the spring for the current move toward the session highs.
*   **Volume Profile Context**:
    *   **5-Day POC**: `$30.95`
    *   **5-Day VAL**: `$28.75`
    *   **Current State**: Price is trading within the Value Area, approaching the high-volume node.

---

### 4. Mathematical Metrics

*   **Sortino Ratio**: `2.95` (Hurdle: `> 2.0`) **[PASS]**
*   **ATR (5m)**: `$0.19`
*   **RVOL**: Significant institutional participation noted on the move above `$28.00`.
*   **Performance Tier**: **Sword** (High-growth, high-RR potential).

---

### 5. Execution Parameters

*   **Execution State**: **STRIKE**
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$29.21`
*   **Hard Stop**: `$28.80` (Positioned below the `$28.83` liquidity sweep)
*   **Share Quantity**: `609 Shares`
*   **Primary Target (4:1 RR)**: `$30.85`
*   **Secondary Target**: `$32.14` (52-week high retest)

---

### 6. Risk Guardrails

*   **Daily Stop Alert**: If the position incurs a `-1R` loss, we exit immediately. A breach of `$28.80` invalidates the Sniper momentum thesis.
*   **Kill Switch**: A close below the tactical **VAL** of `$28.75` suggests the institutional "Sword" momentum has stalled; position should be liquidated.
*   **Scaling Protocol**: No scale-in authorized unless the first unit reaches a `2:1` RR.
*   **Portfolio Balance**: As a "Sword" play, this position is high-alpha. Ensure "Shield" positions (Low vol/Steady yield) are maintained to offset potential clinical-phase volatility.

---

**Execution Authorization**: **AUTHORIZED**
*Status: Active monitoring of the $30.95 POC for profit taking.*