> **Generated:** Friday, May 08, 2026 at 09:40 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


Adlai Nortye Ltd (`ANL`) has demonstrated a significant institutional regime shift, confirmed by a Macro Change of Character (`CHoCH`) at `$1.91`. The asset is currently in a premium price discovery phase, trading well above its `60d` Value Area High. With a Day Trading Sortino Ratio of `3.51`, the stock comfortably clears our `2.0` mathematical hurdle, indicating that the recent upside volatility is providing high-quality risk-adjusted returns. Despite a minor intraday pullback of `-1.24%`, the structural alignment between the `1h` tactical order blocks and the prevailing `1d` bullish trend justifies a high-conviction "Sword" entry to capitalize on the next impulse leg toward the `$17.25` liquidity pool.


***


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


***


# 3. Execution Parameters


*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$13.50` - `$13.55`
*   **Share Quantity**: `250` Shares
*   **Risk Unit (R)**: `$250`
*   **Hard Stop**: `$12.50`
*   **Primary Target**: `$17.25`
*   **Tactical RR**: `4:1`


***


# 4. SMC Structural Audit


*   **Institutional Trend**: **Bullish** (Confirmed by `CHoCH` at `$1.9127`).
*   **Market Structure**: Currently in an expansionary phase. The break of structure (`BOS`) is continuing through recent local highs.
*   **Bearish Fair Value Gaps (FVG)**:
    *   `$15.20` - `$15.40`
    *   `$13.10` - `$13.81` (Price currently interacting within this zone).
*   **Key Order Blocks**:
    *   Bullish Base: `$6.34` - `$7.07`
    *   Immediate Resistance: `$17.25` (External Liquidity Pool).
*   **Institutional Footprint**: The high `Apex Authorization` pass indicates that the current accumulation at the `$13.50` handle is supported by deep-pocketed smart money positioning.


***


# 5. Volume Profile & Volatility


*   **Macro POC (60d)**: `$1.50`
*   **Tactical POC (5d)**: `$13.98`
*   **Value Area High (VAH)**: `$16.82`
*   **Value Area Low (VAL)**: `$12.01`
*   **ATR (5m)**: `0.11`


The massive migration of the Point of Control (`POC`) from `$1.50` to `$13.98` signifies a complete revaluation of the asset. The market is successfully defending the `$13.00` – `$14.00` range, treating it as the new institutional floor.


***


# 6. Mathematical Hurdle (Sortino)


*   **Metric**: Day Trading Sortino Ratio
*   **Hurdle**: `2.0`
*   **Result**: **PASS**
*   **Current Value**: `3.51`
*   **Downside Deviation**: `1.48%`


The risk-adjusted performance is exceptional. The low downside deviation relative to the price velocity suggests that the "Sword" is cutting cleanly through resistance with minimal erratic retracements.


***


# 7. Risk Guardrails & Kill Switch


*   **Daily Stop (Account Level)**: `3R` (`$750`)
*   **Position Kill Switch**: Close position immediately if price closes below `$11.80` (departure from the `5d` Value Area).
*   **Advisory**: This is a "Sword" position. While the potential for `+5R` or higher is significant, the volatility inherent in such aggressive expansions requires strict adherence to the `$12.50` hard stop. Do not scale in unless the first unit reaches break-even.