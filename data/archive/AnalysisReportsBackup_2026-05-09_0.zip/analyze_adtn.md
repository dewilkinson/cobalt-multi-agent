> **Generated:** Friday, May 08, 2026 at 09:34 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**Execution Authorization**: **WAIT (Retain Cash)**


The analysis of **ADTN** reveals a stock in a structural transition, but one that currently fails our high-fidelity math hurdles for a **Sniper Strike**. While the Macro (1d) timeframe has confirmed a Bullish Change of Character (CHoCH) at `$10.75`, the stock is presently trading in a low-conviction "void" between the Macro Point of Control (POC) of `$10.19` and the Tactical POC of `$16.73`.


The **Sortino Ratio** of `1.69` falls short of our mandatory `2.0` threshold. From a risk-management perspective, entering at the current price of `$14.85` forces a stop-loss placement that does not provide the required `4:1` Reward-to-Risk (RR) ratio characteristic of the Sniper style. We remain on the sidelines until price retraces to a high-probability demand zone or clears the tactical supply wall.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


**[DATA_UNAVAILABLE]**


---


# 3. STRUCTURAL AUDIT & SMC ANALYSIS


**Institutional Trend**: **BULLISH** (MTF Alignment Confirmed)


*   **Macro Map (1d)**: The trend transitioned from Bearish to Bullish following the CHoCH at `$10.75`. Institutional accumulation is evident near the `$10.19` level.
*   **Tactical Zones (1h)**:
    *   **High-Conviction Demand**: Bullish Order Blocks are anchored between `$9.16` and `$9.81`.
    *   **Institutional Magnets**: A significant Bullish Fair Value Gaps (FVG) exists at `$17.74` — `$17.94`, representing the likely target for the next major displacement.
*   **Supply Dynamics**: The Tactical POC at `$16.73` acts as a heavy ceiling. Price is currently trapped below the Tactical Value Area Low (VAL) of `$14.70`, suggesting the current move lacks sufficient institutional "Sword" momentum to pierce overhead resistance immediately.


---


# 4. QUANTITATIVE METRICS


*   **Last Price**: `$14.85`
*   **Daily Change**: `+2.85%`
*   **Morning Volume**: `100,652`
*   **Sortino Ratio**: `1.69` (Target: `≥ 2.0`) — **FAIL**
*   **Volatility (ATR)**: `1.01`
*   **Macro POC**: `$10.19`
*   **Tactical POC**: `$16.73`


---


# 5. EXECUTION PARAMETERS (THE SNIPER PATH)


Should price action satisfy our retracement requirements, the following parameters are authorized for a **PROBE** or **STRIKE** entry:


*   **Active Strategy**: Sniper Strategy
*   **Execution State**: **WAIT**
*   **Strike Zone (Entry)**: `$11.20` (Targeting the retest of the Macro Breakout level)
*   **Hard Stop**: `$10.19` (Anchored at the Macro POC)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `247` shares
*   **Profit Target (4:1 RR)**: `$15.24`


---


# 6. RISK GUARDRAILS


*   **Psych Reset**: If the current entry is attempted and fails, revert to `0.5R` Scouts for subsequent ADTN setups.
*   **Liquidity Warning**: Current volume is sufficient but thin. Avoid market orders to prevent slippage beyond the `1.01` ATR.
*   **Kill Switch**: Close all exposure if price closes below the Macro POC of `$10.19` on a 4-hour candle, as this invalidates the Bullish CHoCH narrative.