> **Generated:** Friday, May 08, 2026 at 11:49 AM

Active Strategy: Shield Strategy


# 1. Execution Summary

**STRIKE Authorized**


**Rationale**: CYTK has undergone a fundamental structural transition from a high-volatility "Sword" to a fortified "Shield" asset following the successful pricing of its `$700M` upsized public offering at `$71.00`. This offering, coupled with positive Phase 3 ACACIA-HCM data, has established a "Fortress Floor" at the `$71` mark, significantly de-risking the downside. With a **Sortino Ratio** of `3.01`, the asset demonstrates elite risk-adjusted performance, fulfilling the Shield mandate of wealth preservation through controlled volatility. Institutional accumulation by FMR (9% stake) and aggressive price target hikes to the `$106` - `$119` range suggest that the "Smart Money" is treating the current price level as a high-conviction base for long-term stability.


---


# 2. Institutional News & Social Sentiment

*   **Cytokinetics prices 9.859M-share offering to raise $700M at $71.00/share** (Stock Titan, 4h ago) - Polarity: `Neutral`. This creates the primary structural "Shield" floor for the current trade.


*   **Truist raises Cytokinetics stock price target to $106 following ACACIA trial** (Investing.com, 6h ago) - Polarity: `Bullish`. Validates the long-term growth narrative and safety of the current entry.


*   **RBC Capital raises price target to $119 on strong Myqorzo launch** (Investing.com, 8h ago) - Polarity: `Bullish`. Reflects institutional confidence in revenue stability.


*   **FMR LLC increases beneficial ownership to 9.0%** (SEC Filing/Stock Titan, 1d ago) - Polarity: `Neutral/Institutional`. Major institutional backing provides a liquidity shield against retail panic.


*   **Sentiment Synthesis**: Social sentiment is overwhelmingly focused on the "de-risking" of the balance sheet. The `$1.1B` cash position is being viewed as a protective moat, shifting the narrative from speculative biotech to a stable growth anchor.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Trend**: **Bullish**. A clear Break of Structure (BOS) occurred at `$54.22`, confirming long-term institutional sponsorship.


*   **Volume Profile (5-Day)**:
    *   **Value Area High (VAH)**: `$76.38`
    *   **Point of Control (POC)**: `$66.24`
    *   **Analysis**: Price is currently trading above the 5-day VAH, indicating "Market Acceptance" of the new higher prices following the share offering.


*   **Institutional Zones**:
    *   **Bullish Fair Value Gap (FVG)**: `$65.29` - `$73.06`. This acts as a secondary safety net.
    *   **Bullish Order Block**: `$58.64` - `$60.59`. The ultimate structural floor.


---


# 4. Mathematical Hurdle

*   **Metric**: Sortino Ratio ($S_{DR}$)
*   **Hurdle**: $\ge$ `2.0`
*   **Result**: **PASS** (`3.01`)
*   **Shield Commentary**: The downside deviation is a remarkably low `0.53%`, confirming that CYTK is currently exhibiting the "Shield" characteristic of minimal negative volatility despite its recent price appreciation.


---


# 5. Execution Parameters

*   **Strategy**: Shield (Long Only)
*   **Risk Unit (R)**: `$250`
*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$77.52`
*   **Hard Stop**: `$75.80` (Placed below the 5-day VAH to protect against minor mean reversion)
*   **Share Quantity**: `145 Shares`
*   **Tactical Formula**: `Shares = $250 / ($77.52 - $75.80)`


---


# 6. Risk Guardrails

*   **Daily Stop**: If the total account drawdown hits `3R` (`$750`), all trading must halt.


*   **Shield Kill-Switch**: If the price invalidates the institutional offering floor of `$71.00`, the Shield narrative is considered broken, and the position must be liquidated immediately regardless of the Hard Stop.


*   **Psychological Note**: Maintain a "Grinder" mindset. While CYTK has significant upside, our role as Shield managers is to prioritize the maintenance of the `$75.80` level. Scale-in is only authorized if the first unit reaches a `1:1` RR and the stop is moved to Break-Even.