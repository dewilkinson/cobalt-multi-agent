> **Generated:** Friday, May 08, 2026 at 02:14 PM

Active Strategy: Shield Strategy


# 1. Execution Summary


**WAIT (Capital Preservation Authorized)**


The analysis of **AMPX** concludes with a **WAIT** directive. While the macro structure has undergone a bullish Change of Character (`CHoCH`) at `$12.57`, the current tactical environment does not meet the "Shield" criteria for low-volatility wealth preservation. The current **Sortino Ratio** of `0.00` fails our institutional hurdle of `2.0`, indicating that current price action offers no risk-adjusted efficiency. 


Price is currently trapped in a volumetric "No-Man's Land," trading significantly below the **Macro Point of Control (POC)** of `$18.08` and the **Tactical POC** of `$21.10`. Under the Shield Protocol, we do not deploy capital into assets trading beneath heavy institutional supply anchors. We will wait for a reclaim of tactical structural levels to transform this from a speculative "Sword" attempt into a protected "Shield" position.


***


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


***


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish (Macro)** / **Neutral-Bearish (Tactical)**.


*   **Macro Map (1D)**: Confirmed `CHoCH` at `$12.57`. The long-term institutional trend has shifted from distribution to accumulation, but the "Shield" is not yet ready to be raised.


*   **Tactical Displacement**: Price is currently testing the top of a **Bullish Order Block** between `$14.50` and `$16.30`.


*   **Supply Gaps**: A significant **Bearish Fair Value Gaps (FVG)** exists between `$17.15` and `$20.70`. This acts as a gravitational pull that is currently resisting upward expansion.


*   **Volume Shelves**:
    *   **Macro POC**: `$18.08`
    *   **Tactical POC**: `$21.10`
    *   **Value Area Low (60d)**: `$10.22`


***


# 4. Mathematical Hurdle (Sortino)


*   **Hurdle Metric**: Sortino Ratio ($\ge$ `2.0`)
*   **Current Value**: `0.00`
*   **Status**: **FAIL**


*   **Risk Analysis**: The lack of a positive Sortino ratio suggests that recent volatility is skewed heavily to the downside or lacks sufficient reward-to-risk symmetry. This violates the core tenet of the Shield strategy, which prioritizes capital stability.


***


# 5. Execution Parameters (Contingent Authorization)


If price reclaims the tactical displacement pivot, the following **SCOUT (0.5R)** parameters are authorized to begin scaling into a position:


*   **Trigger (Strike Zone)**: `$17.20` – `$17.50`
*   **Hard Stop**: `$16.10`
*   **Risk Unit (R)**: `$250`
*   **Allocation**: `0.5R` (Scout)
*   **Share Quantity**: `227 Shares`


***


# 6. Risk Guardrails


*   **Shield Invalidation**: A break below `$14.50` represents a full structural failure of the local Order Block and requires an immediate thesis reset.


*   **Tactical Mandate**: Do not attempt to "Sword" this position via an aggressive entry. As a Shield strategy, we require confirmation of price acceptance above the `$17.15` pivot. Until that level is reclaimed and held as support, the probability of a "falling knife" scenario remains elevated. 


*   **VIX Correlation**: Monitor VIX levels; if VIX remains above `24`, the `0.5R` Scout sizing is mandatory regardless of price action.