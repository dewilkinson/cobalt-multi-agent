> **Generated:** Friday, May 08, 2026 at 01:46 PM

Active Strategy: Sword Strategy


# 1. Execution Summary


- **Recommendation**: **STRIKE Authorized** (High-Conviction Momentum)


- **Sword Logic**: CLPT is currently unsheathing a significant momentum breakout, clearing the tactical displacement pivot with high velocity. Despite a bearish macro anchor (cycle high at `$14.16`), the intraday tape is showing aggressive institutional accumulation with price currently accepting above today's Session POC. The Sortino Ratio of `3.46` confirms that this **Sword** is cutting through downside volatility with extreme efficiency. We are positioning for a fast-growth "Sword" expansion into the earnings catalyst.


---


# 2. Institutional News & Social Sentiment


- **Headline 1**: "Discipline and Rules-Based Execution in CLPT Response" (Stock Traders Daily | 3d ago) — Bullish AI-driven sentiment identifying mid-channel oscillation.
- **Headline 2**: "ClearPoint Neuro to Announce First Quarter 2026 Results May 13, 2026" (ACCESS Newswire | 2h ago) — Neutral/Anticipatory; setting the stage for high-volatility price discovery.
- **Headline 3**: "ClearPoint Neuro Announces FDA Clearance of the Velocity Alpha MR High Speed Surgical Drill System" (Weatherford Democrat | 4h ago) — Strongly Bullish; tangible operational expansion.
- **Headline 4**: "ClearPoint Neuro plunges as FY26 guidance falls below analysts' estimates" (MSN | 6h ago) — Bearish; providing the initial liquidity sweep and "wall of worry" for the current recovery.
- **Headline 5**: "ClearPoint Neuro Announces Canadian Approval for its Navigation System" (News-Press NOW | 12h ago) — Bullish; confirming global footprint expansion.


**Narrative Synthesis**: The sentiment is a "Battlefield" between trailing guidance disappointment and a series of fresh regulatory "Sword-strikes" (FDA and Health Canada approvals). Institutional tape suggests the market is choosing to prioritize the new product clearances over the guidance lag, creating a classic momentum trap for shorts.


---


# 3. Structural Audit (SMC)


- **Institutional Bias**: **Bullish** (Intraday Shift) | **Neutral-Bearish** (Macro Cycle)


- **Market Structure Details**:
  - **Change of Character (CHoCH)**: Triggered at `$12.37`, invalidating the immediate macro bearish trend.
  - **Macro Ceiling**: `$14.16` (60d Value Area High).
  - **Tactical DP (Displacement Pivot)**: `$11.64` (Previous liquidity sweep high).
  - **Demand Zone (Bullish OB)**: `$10.15` – `$11.02` (Deep institutional support).


- **Institutional Footprint**:
  - **Fair Value Gap (FVG)**: `$11.02` – `$11.07` (Bullish imbalance).
  - **Liquidity Target**: `$13.11` – `$14.16` (Major sell-side liquidity pool).


---


# 4. Sword Efficiency Metrics


- **Sortino Ratio**: `3.46` (**PASS**; Hurdle $\ge$ 2.0).
- **Daily Performance**: `+6.15%` intraday expansion.
- **Volatility (ATR)**: `0.24` (5m timeframe).
- **RVOL**: `> 1.2` (Confirmed institutional participation).


---


# 5. Execution Parameters


- **Execution State**: **STRIKE**
- **Strike Zone (Entry)**: `$12.43` – `$12.55`
- **Hard Stop**: `$12.19`
- **Risk Unit (R)**: `$250`
- **Share Quantity**: `1,041` Shares


---


# 6. Risk Guardrails & Tactical Narrative


- **The Sword Narrative**: This is a high-velocity play on the regulatory clearance news cycle. The "Sword" is currently sharpened by the `3.46` Sortino efficiency, indicating that for every unit of downside risk, the asset is providing outsized upward momentum. 


- **Kill Switch**: If the price closes below the Session VAH of `$11.89`, the momentum is considered "blunted," and the trade must be neutralized.


- **Exit Strategy**: We are targeting a move into the `$13.11` liquidity pocket prior to the May 13th earnings event. Trail the stop to break-even once the price touches `$12.91` (2R).