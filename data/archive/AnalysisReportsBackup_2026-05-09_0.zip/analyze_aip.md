> **Generated:** Friday, May 08, 2026 at 09:36 AM

Active Strategy: Sniper Strategy

# 1. Execution Summary

**Execution Authorization: SCOUT Authorized**

AIP (Arteris Inc.) is currently exhibiting high-velocity "Sword" behavior, having cleared a major institutional Break of Structure (BOS) at `$15.92`. The asset is currently in a parabolic price discovery phase, recently hitting all-time highs near `$29.58`. While the macro trend is unequivocally bullish, the current 5-minute tape indicates a liquidity sweep at `$29.50`, suggesting institutional distribution is occurring as price probes into "thin air" above established volume clusters.

The technical setup is supported by a significant narrative tailwind regarding expanded RISC-V AI partnerships with MIPS, though this is tempered by heavy insider selling under 10b5-1 plans. Given the extreme premium and the proximity to the Tactical POC at `$26.86`, we are initiating a **SCOUT** position (0.5R) to probe for further expansion toward the `$31.00` psychological level, maintaining a tight "Sniper" stop to mitigate the risk of a parabolic blow-off.

---

# 2. Institutional News & Social Sentiment

*   **Arteris (AIP) Up 8.8% After Deepening MIPS RISC-V AI Collaboration** (Simply Wall Street) - `2h ago`
*   **Arteris Inc stock hits all-time high at 29.58 USD** (Investing.com) - `3h ago`
*   **Director Raza sells 90,000 shares via 10b5-1 trading plan** (Stock Titan) - `5h ago`
*   **Arteris, Inc. grows Poland engineering hub to strengthen European semiconductor ties** (Traders Union) - `8h ago`
*   **Arteris (AIP) Lowered to Hold Rating by Wall Street Zen** (MarketBeat) - `1d ago`

**Synthesis**: Sentiment is highly polarized. Institutional news focuses on the "Sword" growth potential of RISC-V AI architecture, while internal corporate actions (insider sales) signal a potential local top or tactical distribution phase. Social sentiment remains aggressively bullish as retail momentum chasers target the `$30.00` breakout.

---

# 3. Structural Audit & Tape Reading

*   **Institutional Trend**: Bullish (BOS at `$15.92`)
*   **Market Structure**:
    *   **Macro Ceiling**: `$30.13` (Current Price Discovery)
    *   **Tactical POC**: `$26.86` (5-Day Volume Anchor)
    *   **Macro POC**: `$15.46` (Foundational Support)
*   **Institutional Footprint**:
    *   **Bullish FVG**: `$29.15` - `$30.12` (Immediate support zone)
    *   **Liquidity Sweep**: Bearish sweep detected at `$29.50` (5m timeframe)
    *   **Order Block**: Bullish OB identified at `$13.69` - `$14.68` (Deep Value)

---

# 4. Mathematical Hurdles

*   **Sortino Ratio**: `5.11` (**PASS**; Sniper Hurdle `> 2.0`)
*   **Volatility (ATR)**: `0.35` (5m)
*   **Institutional Accumulation (RVOL)**: High (Trending above `2.0` during the morning session)

---

# 5. Tactical Execution: The Sniper Path

Following the **CMA RISK MANAGEMENT PROTOCOL**, this trade is classified as a **SCOUT** entry due to the extreme price premium and the need to probe the current liquidity sweep.

**Execution Parameters**:
*   **Strike Zone (Entry)**: `$30.13`
*   **Hard Stop**: `$29.13`
*   **Risk Unit (0.5R)**: `$125`
*   **Share Quantity**: `125 Shares`
*   **Target (4:1 RR)**: `$34.13`

---

# 6. Risk Guardrails & Performance Metrics

*   **Daily Stop (3R)**: If account drawdown exceeds `-$750`, halt all activity.
*   **Kill Switch**: If AIP loses the Tactical POC of `$26.86`, the bull thesis for a momentum sniper trade is invalidated; exit all units immediately.
*   **Scale-In**: Authorization to scale to a full **STRIKE** (1R) only if the initial unit is at Break-Even and price prints a 15-minute close above `$30.50`.
*   **MOC Exit**: If the VIX remains `> 25`, close all laggards at `3:55 PM ET`.

**Analyst Note**: Dave, AIP is a classic "Sword." It has the velocity we want, but the volume profile shows we are trading in a low-density zone. Use the `125 Shares` to test the waters. If the RISC-V narrative holds, this has `10R` potential, but we must respect the tight stop given the insider distribution noted in the tape.