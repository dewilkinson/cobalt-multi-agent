> **Generated:** Friday, May 08, 2026 at 10:00 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


The structural audit for **CODI** confirms a high-conviction institutional markup phase. Following a confirmed Macro Change of Character (**CHoCH**) at `$7.75`, the asset has transitioned from a defensive "Shield" profile into an aggressive "Sword" expansion. With a **Sortino Ratio of 3.01**, the risk-adjusted returns significantly exceed our institutional hurdle of `2.0`, indicating that downside volatility is being effectively suppressed by institutional bid support. Price is currently consolidating above a critical cluster of Bullish Fair Value Gaps (**FVG**), suggesting a high-probability "Sniper" entry on the next tactical retest of the `$11.85` zone.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit (SMC Analysis)


**Market Bias**: **Bullish** (Institutional Accumulation)


*   **Macro CHoCH**: Confirmed at `$7.75`. This marks the pivot from long-term distribution to a new institutional markup cycle.
*   **Institutional Order Blocks**:
    *   **Bullish Floor**: `$5.52` - `$5.74` (Primary Liquidity Driver).
    *   **Bearish Ceiling**: `$8.07` - `$8.42` (Previously breached; now acting as structural support).
*   **Fair Value Gaps (FVG)**:
    *   **Tactical Support**: `$11.74` - `$11.82` (Immediate target for entry).
    *   **Macro Support**: `$10.42` - `$10.51` (Deep discount zone).
*   **Liquidity Targets**: Internal buy-side liquidity is pooling near the `$12.64` level, which serves as our primary profit objective for this Sniper execution.


---


# 4. Volume Profile & Volatility


*   **Macro Point of Control (POC)**: `$4.75` (Long-term value area).
*   **Tactical POC (5-Day)**: `$11.42` (The "Smart Money" defense line).
*   **Value Area High (VAH)**: `$12.50`.
*   **Value Area Low (VAL)**: `$10.49`.
*   **ATR (5m)**: `$0.18` (Indicates tight intraday range; ideal for high-precision entries).


---


# 5. Performance Metrics (Ground Truth)


*   **Sortino Ratio**: `3.01` (Status: **PASS**).
*   **Downside Deviation**: `0.86%`.
*   **RVOL (Relative Volume)**: Accumulation nodes are thickening near the tactical POC, confirming institutional absorption.


---


# 6. Execution Parameters: The Sniper Path


**STRIKE** authorization is granted based on the 4:1 Reward-to-Risk requirement of the Sniper Strategy. 


*   **Execution State**: **STRIKE Authorized** (Full Deployment)
*   **Strike Zone (Entry)**: `$11.85`
*   **Hard Stop**: `$11.35` (Placed below the Tactical POC defense zone)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `500` Shares
*   **Profit Target (Initial)**: `$13.85` (Maintains the `4:1` RR requirement)


---


# 7. Risk Guardrails


*   **Daily Stop (3R)**: Total account halt if drawdown reaches `-$750`.
*   **Kill Switch**: Close position immediately if price closes below the Tactical POC of `$11.42` on a 1H candle.
*   **Scale-In Protocol**: No additions allowed unless the first unit is at Break-Even. CODI is exhibiting "Sword" characteristics; prioritize the `$12.64` breakout but exit laggards by `3:55 PM` if volatility spikes.