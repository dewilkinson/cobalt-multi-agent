> **Generated:** Thursday, May 07, 2026 at 06:07 AM

Active Strategy: Shield Strategy


# 1. Execution Summary


**STRIKE Authorized**


Healthpeak Properties (`DOC`) has successfully transitioned into a premier **Shield** asset within the Blueshell War Barbell. The authorization is driven by a powerful structural re-rating following the successful `$880M` Janus Living IPO and a subsequent lift in `2026` earnings guidance. This fundamental "shielding" is confirmed by a **Sortino Ratio of `2.97`**, indicating that the recent price appreciation is characterized by extremely low downside deviation (`0.25%`).


The tape shows institutional accumulation absorbing supply at the `$17.95` level, leading to a daily Change of Character (**CHoCH**). While currently in a **Premium Zone**, the liquidity sweep at `$19.50` suggests institutional players are now defending this higher plateau as the new value floor. We are deploying a **STRIKE** execution to lock in this low-volatility growth as a hedge against broader market instability.


***


# 2. Institutional News & Social Sentiment


*   **Healthpeak Properties Raises 2026 Earnings Guidance Following Completion of the Janus Living IPO** (Business Wire | 2d ago) 
    > Narrative: The completion of the Janus Living IPO generated `$880 million` in net proceeds, significantly de-leveraging the balance sheet and allowing for accretive capital allocation. 


*   **Janus IPO brings in $880M as Healthpeak lifts 2026 earnings view** (Stock Titan | 2d ago) 
    > Narrative: Positive revision of full-year `2026` earnings guidance following the capital infusion, creating a fundamental floor for the stock.


*   **Public Storage Stock (PSA) Moved Up by 3.45% on May 6: Key Drivers Unveiled** (TradingKey | 1d ago) 
    > Narrative: Broader REIT sector strength, particularly in high-quality medical and storage assets, provides a supportive macro tailwind for `DOC`.


*   **M&T Bank Corp Cuts Stake in Healthpeak Properties, Inc.** (MarketBeat | 4d ago) 
    > Narrative: A significant reduction in stake (`96.6%`) by M&T Bank serves as a lagging indicator of previous positioning, now being offset by fresh institutional "Smart Money" following the guidance lift.


*   **3 Healthcare Stocks Paying the Highest Dividends in the Sector Right Now** (The Globe and Mail | 3d ago) 
    > Narrative: `DOC` is being highlighted as a top-tier yield provider, increasing its attractiveness to income-focused institutional funds during periods of volatility.


**Sentiment Synthesis**: Social and institutional sentiment is **Somewhat-Bullish to Bullish**. The market is actively digesting the transition of `DOC` from a value-trap into a growth-oriented REIT. The primary narrative is centered on "Balance Sheet Strength" and "Guidance Alpha."


***


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: `Strongly Bullish`


*   **Market Structure**:
    *   **Daily CHoCH**: `$17.95` (Confirmed trend shift)
    *   **Macro Ceiling**: `$19.63`
    *   **Tactical Displacement**: `$17.95`


*   **Volume Profile (SMC Focus)**:
    *   **Point of Control (POC)**: `$17.09`
    *   **Value Area High (VAH)**: `$17.50`
    *   **Value Area Low (VAL)**: `$16.19`
    *   **Note**: Price is currently trading significantly above the high-volume nodes, indicating a momentum-driven expansion phase.


*   **Institutional Footprint**:
    *   **Primary Order Block**: `$15.70` - `$16.34` (Deep Support)
    *   **Bullish FVG**: `$16.93` - `$17.05` (Liquidity Magnet)
    *   **Liquidity Sweep**: Bullish sweep identified at `$19.50`.


***


# 4. Mathematical Hurdle (Sortino)


*   **Sortino Ratio**: `2.97`
*   **Hurdle Status**: **PASS** (Threshold >= `2.0`)
*   **Downside Deviation**: `0.25%`


**Analysis**: The efficiency of this move is elite. A Sortino nearly touching `3.0` during a breakout phase confirms that institutional "Shield" buyers are providing a persistent bid, preventing the "Sword-like" drawdowns typical of speculative assets.


***


# 5. Execution Parameters


*   **Execution State**: **STRIKE Authorized**


*   **Position Type**: Shield (Swing)


*   **Strike Zone (Entry)**: `$19.50` - `$19.25`


*   **Hard Stop**: `$18.50`


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `250` Shares


*   **Profit Target (Initial)**: `$22.50` (`3:1` RR)


***


# 6. Risk Guardrails


*   **Tactical Kill Switch**: A daily close below `$17.85` invalidates the current structural breakout and necessitates an immediate exit.


*   **Shield Maintenance**: If the Sortino Ratio drops below `1.8` on a rolling `5-day` basis, the position will be re-evaluated for a size reduction (reverting to **PROBE** status).


*   **Volatility Warning**: Monitor scheduled healthcare sector updates and interest rate volatility, as REITs maintain sensitivity to the long-end of the curve. However, the `$880M` cash injection provides a unique idiosyncratic buffer for `DOC` against sector-wide headwinds.