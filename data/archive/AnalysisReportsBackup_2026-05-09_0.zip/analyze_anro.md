> **Generated:** Friday, May 08, 2026 at 09:41 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**WAIT (Retain Cash)**


The authorization for a **STRIKE** is currently withheld. While **ANRO** exhibits a clean institutional bullish trend with a confirmed Break of Structure (**BOS**) at `20.9075`, the internal mathematical hurdle has not been cleared. The **Sortino Ratio** currently sits at `1.88`, failing to meet the **Sniper Strategy** requirement of `2.0` or higher. 


Furthermore, a bearish liquidity sweep at `23.33` on the **5m** execution map indicates that "Smart Money" has likely harvested short-term buy-side liquidity, suggesting a high probability of a mean-reversion move toward the discount zone. We will remain disciplined and wait for price to retraced into the high-confluence Bullish Order Block and the Macro Point of Control (**POC**) before deploying capital.


***


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Headline**: BofA Securities Initiates Alto Neuroscience (ANRO) With Buy Rating, Announces Target Price `$35` (Source: Moomoo, 4h ago)
*   **Headline**: Alto Neuroscience Initiates Phase 2b Trial of **ALTO-207** in Treatment-Resistant Depression (Source: BioSpace, 6h ago)
*   **Headline**: Alto Neuroscience (NYSE: ANRO) registers `6M` resale shares from private placement (Source: Stock Titan, 1d ago)
*   **Headline**: California Biotech Co. Advances Depression Drug Breakthrough (Source: Streetwise Reports, 1d ago)
*   **Headline**: **ANRO** stock on investors radar after failed schizophrenia study results (Source: MSN, 2d ago)


**Synthesis**: The narrative is shifting from "recovery" (after previous study failures) to "aggressive expansion." The initiation of Phase 2b trials and the heavy-weight backing from BofA Securities provides a strong fundamental tailwind. Social sentiment is cautiously optimistic, though "scar tissue" from the failed schizophrenia data remains a point of friction in the order flow.


***


# 3. STRUCTURAL AUDIT & TAPE READING


*   **Institutional Bias**: Bullish (MTF Alignment Scan: **PASS**)
*   **Macro Structure**: Confirmed **BOS** at `20.9075`. The macro trend is undeniably controlled by institutional accumulation.
*   **Tactical Zones**:
    *   **Premium POC (5d)**: `25.42` (Currently acting as overhead resistance).
    *   **Discount POC (60d)**: `22.08` (Our high-probability target entry).
    *   **Order Block (Bullish)**: `19.4129` — `20.4600`.
    *   **Fair Value Gap (Bullish)**: `22.78` — `25.60`. Price is currently oscillating within this imbalance.


***


# 4. QUANTITATIVE METRICS & HURDLE TEST


*   **Current Price**: `$23.87`
*   **5m ATR**: `0.37` (Expected volatility range).
*   **Day Trading Sortino**: `1.88` (**FAIL**; Hurdle: `2.0`).
*   **Downside Deviation**: `0.66%`.
*   **Macro POC Volume**: `2,088,071` shares at the `22.08` level.


***


# 5. EXECUTION PARAMETERS (PROSPECTIVE)


Should price retraced into our identified "Value Area" and the Sortino ratio stabilizes above the hurdle, the following parameters are authorized for a **PROBE** or **STRIKE**:


*   **Execution State**: **WAIT**
*   **Strike Zone (Entry)**: `$22.10`
*   **Hard Stop**: `$21.10`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Profit Target 1 (4R)**: `$26.10`


***


# 6. RISK MANAGEMENT & GUARDRAILS


*   **Kill Switch**: A daily close below `20.90` invalidates the bullish **SMC** thesis and triggers a total exit.
*   **Sword Asset Management**: This is a high-growth "Sword" asset. Given the failed hurdle, we do not chase the current price of `$23.87`. 
*   **VIX Correlation**: If **VIX** remains below `24`, we will look for a **STRIKE** at the entry target. If **VIX** spikes, we will downgrade the entry to a **SCOUT** (`0.5R`).


**Status: OK. Cache verified.**