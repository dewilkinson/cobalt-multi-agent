> **Generated:** Friday, May 08, 2026 at 10:12 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY

**WAIT (Institutional Displacement)**


The current technical architecture for **EPC** fails to meet the high-precision requirements of the **Sniper Strategy**. While the asset maintains a healthy **Sortino Ratio** of `2.67` for general trading, it falls significantly short of the `20.0` hurdle required for a low-frequency, high-fidelity **Sniper** strike. 


Price action has effectively broken down from the tactical high-volume node at `$22.50` (5-day POC), indicating institutional displacement. Despite a fundamental beat in earnings, the "Sell the News" narrative is dominating the tape. We are observing a lack of institutional sponsorship at current levels, with the stock underperforming the broader market by approximately `-2.5%`. We will remain flat until price recaptures the institutional pivot or reaches the primary demand zone.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

*   **MarketScreener (2h ago)**: Earnings Flash: Edgewell Personal Care posts Fiscal Q2 Adjusted EPS `$0.60`, significantly beating the FactSet estimate of `$0.44`.
*   **StockStory (3h ago)**: Why Edgewell Personal Care (EPC) shares are sliding today despite earnings beat; market citing potential "Sell the News" dynamics and forward guidance caution.
*   **Simply Wall Street (5h ago)**: Assessing Edgewell Personal Care valuation as revenue challenges and leverage concerns draw institutional attention.
*   **PR Newswire (1d ago)**: Schick debuts "Do Right By Your Skin" campaign featuring Nick Jonas to boost brand visibility in the skin-first shave segment.
*   **Stock Titan (2d ago)**: Vanguard Portfolio Management discloses a increased stake of `3,065,063` shares, representing a `6.56%` institutional position.


**Social Sentiment**: **BEARISH/CAUTIOUS**. Social sentiment is currently dominated by the intraday price rejection following the earnings release. Traders are focused on the "gap and trap" behavior, with the primary narrative centered on whether the `$21.00` macro floor will hold.


---


# 3. STRUCTURAL AUDIT & TAPE READING

*   **Institutional Trend**: **BULLISH MACRO** (Confirmed Break of Structure at `$18.50`).
*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$22.50` (The level where sellers overwhelmed buyers today).
    *   **Macro POC (Point of Control)**: `$21.04` (The ultimate high-volume support anchor).
    *   **Institutional Magnet (FVG)**: `$22.40` - `$23.23` (Bullish imbalance remains unfilled above).
*   **Order Block Analysis**:
    *   **Bullish Demand Zone**: `$18.54` - `$19.67`.
*   **Liquidity Mapping**: Internal sell-side liquidity is currently being hunted near the `$21.20` level.


---


# 4. MATHEMATICAL HURDLE (SORTINO)

*   **Hurdle Status**: **FAIL**
*   **Asset Sortino**: `2.67`
*   **Sniper Target**: `20.00`
*   **Volatility Analysis**: **ATR (5m)** is currently `0.14`. While downside deviation is relatively low at `0.63%`, the lack of immediate positive momentum prevents the expansion of the Sortino Ratio to the levels required for a high-WR Sniper entry.


---


# 5. EXECUTION PARAMETERS (CONTINGENT)

*In the event of a technical recovery and Sortino expansion, the following parameters are authorized for a **SCOUT** probe:*


*   **Strike Zone (Entry)**: `$21.55` (Requires 5m close above intraday VAL)
*   **Hard Stop**: `$21.24` (Defense of the 60d Macro POC)
*   **Share Quantity**: `806 Shares`
*   **Risk Unit (R)**: `$250` (0.5R initial exposure recommended due to VIX volatility)
*   **Profit Target (4:1 RR)**: `$22.79`


---


# 6. RISK GUARDRAILS

*   **Daily Stop**: `3R` limit remains in effect.
*   **Kill Switch**: A violation and hold below the **Macro POC** of `$21.04` invalidates the bullish thesis entirely.
*   **Strategy Note**: EPC is currently acting as a "Falling Sword." Per the **Blueshell Tactical Protocol**, we do not catch knives. We wait for the "Shield" (stability at support) to form. Maintain cash position and monitor for a recapture of the `$21.65` level before initiating any **Scout** units.