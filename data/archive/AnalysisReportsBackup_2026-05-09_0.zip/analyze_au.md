> **Generated:** Friday, May 08, 2026 at 11:26 AM

Active Strategy: Shield Strategy


# 1. Execution Summary


- **Recommendation**: **WAIT (Authorization Withheld)**


- **Rationale**: Despite a confirmed daily Bullish Break of Structure (**BOS**) at `$79.94`, AngloGold Ashanti (**AU**) currently fails the mandatory **Shield Strategy** mathematical hurdle. The asset exhibits a **Sortino Ratio** of `0.30`, which is significantly below the institutional floor of `2.0` required for defensive capital deployment. While the intraday momentum is strong at `+5.13%`, the price is currently compressed between the macro **Point of Control (POC)** at `$105.59` and the tactical 5-day **POC** at `$108.78`. This creates a high-friction environment unsuitable for a low-volatility "Shield" allocation.


---


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Quantitative Analysis & Market Structure


**Institutional Footprint (SMC)**:
- **Macro Trend**: Bullish (Daily **BOS** confirmed at `$79.94`)
- **Primary Supply Zone (Order Block)**: `$123.13` — `$129.14`
- **Bearish Imbalance (FVG)**: `$95.39` — `$97.30` (Acting as a magnet for mean reversion)
- **Bullish Guardrail (FVG)**: `$93.63` — `$99.68`


**Volatility & Efficiency**:
- **Current Price**: `$105.67`
- **Sortino Ratio**: `0.30` (Status: **CRITICAL FAIL**)
- **ATR (5m)**: `$0.72`
- **RVOL**: Institutional accumulation baseline is currently neutral relative to the tactical pivot.


**Volume Profile Topology**:
- **Macro VAH (60d)**: `$110.71`
- **Macro POC (60d)**: `$105.59`
- **Macro VAL (60d)**: `$88.18`
- **Tactical POC (5d)**: `$108.78`


---


# 4. Execution Parameters


If technical conditions improve and the **Sortino Ratio** scales toward `2.0`, the following "Sniper Path" is authorized for a **SCOUT** probe:


- **Execution Tier**: **SCOUT** (`0.5R`)
- **Risk Unit (R)**: `$125.00` (Reduced risk due to efficiency fail)
- **Strike Zone (Entry)**: `$103.50` — `$104.50`
- **Hard Stop**: `$102.78`
- **Share Quantity**: `347` shares
- **Target (3:1 RR)**: `$106.66`


---


# 5. Risk Management & Shield Mandate


- **The Shield Status**: Currently **INACTIVE**. The strategy requires assets that protect the portfolio via high risk-adjusted returns. **AU**’s high downside deviation relative to its current reward profile categorizes it as a "broken shield" at this specific price discovery phase.
- **Kill Switch**: A breach of the Bullish FVG at `$99.68` invalidates the current technical thesis and would require a total reset of the long-bias framework.
- **MOC Exit**: If a position were active, a mandatory close would be triggered at 3:55 PM ET if the **VIX** exceeds `25`.


**Status**: **WAIT**. No institutional entry authorized until mathematical efficiency aligns with structural bias.