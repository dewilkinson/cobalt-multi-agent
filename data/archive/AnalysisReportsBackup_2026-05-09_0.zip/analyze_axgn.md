> **Generated:** Friday, May 08, 2026 at 09:49 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


AXGN has triggered a high-fidelity Sniper setup following a confirmed institutional structural shift (CHoCH) at `$35.99`. Despite a minor intraday cooling of `-1.66%`, the asset is displaying elite efficiency metrics with a Sortino Ratio of `4.87`, significantly exceeding the institutional hurdle of `2.0`. This indicates a "Sword" profile with high-velocity upside potential and tightly controlled downside volatility.


The technical tape shows the price is currently being accepted above the 5-day Tactical Value Area High (VAH) of `$42.91`, suggesting that previous resistance is now acting as a floor for institutional accumulation. With a bullish liquidity sweep confirmed at `$43.96`, the path of least resistance remains upward toward price discovery.


---


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Execution Parameters


*   **Position Type**: Long (IRA Compliant)
*   **Execution State**: **STRIKE**
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$42.50` - `$42.70`
*   **Hard Stop**: `$41.50`
*   **Share Quantity**: `250` shares
*   **Target RR**: `3:1` Minimum


---


# 4. Institutional Structural Audit


**MTF Alignment Scan**

*   **Macro Trend (1d)**: Bullish. Institutional regime shift confirmed at `$35.99`.
*   **Tactical Bias (1h)**: Aggressively Bullish. Price is holding significantly above the primary Bullish Order Block located at `$30.00` - `$32.02`.
*   **Efficiency Metric**: Sortino Ratio of `4.87`. This signifies extreme relative strength and a high probability of momentum continuation.


**Volume Profile Landmarks**

*   **Macro POC (60d)**: `$32.49`
*   **Tactical VAH (5d)**: `$42.91`
*   **Value Area Width**: The migration of the Point of Control from `$32.49` to the tactical `$37.68` confirms a massive re-pricing event driven by "Smart Money" demand.


---


# 5. Risk Guardrails & Tape Reading


*   **Liquidity Mapping**: A bullish liquidity sweep was identified at `$43.96`. This move cleaned out buy-side liquidity, often a precursor to a secondary expansion phase once the current minor pull-back consolidates.
*   **Volatility Guardrail**: Current ATR (5m) is `0.25`. The proposed Hard Stop at `$41.50` provides a buffer of 4x ATR, protecting the position from "noise" while exiting if the structural integrity of the breakout is compromised.
*   **Kill Switch**: Immediate liquidation required if price closes below `$41.50` on a 15m timeframe, as this would invalidate the current Sniper expansion narrative.


---


**Status: STRIKE Authorized. Logic Gated Environment verified.**