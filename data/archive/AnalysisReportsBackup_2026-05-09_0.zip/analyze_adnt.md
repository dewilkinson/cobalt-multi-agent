> **Generated:** Friday, May 08, 2026 at 04:30 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**SCOUT Authorized**


**Rationale**: ADNT has triggered a **Macro CHoCH** (Change of Character) to the upside, signaling a high-fidelity trend reversal following a dominant earnings beat and raised guidance. The stock is currently exhibiting a **Value Breakout** with a `+5.46%` gap, trading well above its 5-day Value Area High (`$21.94`). While institutional accumulation is evident, a recent liquidity sweep at `$22.34` suggests a "Tactical DP" (Displacement Pivot) where sellers are briefly defending. Given the **Sortino Ratio** of `2.03` (barely clearing the Sniper hurdle of `2.0`), we are initiating a **SCOUT** position at `0.5R` to probe this "Sword" momentum while maintaining a "Shield" against potential mean reversion to the Fair Value Gap (FVG) below.


---


# 2. Institutional News & Social Sentiment

**Headlines & Synthesis**:
*   **Stifel raises Adient stock price target to $28 on guidance boost** (Investing.com) - *3h ago*
*   **Deutsche Bank Adjusts Adient Price Target to $31 From $30; Maintains Buy** (MarketScreener) - *4h ago*
*   **Adient Q2 2026 Earnings: EPS beat of $0.08, Revenue +7.03% YoY** (Seeking Alpha) - *6h ago*
*   **Adient expands with Romulus plant and massage tech acquisition** (PlasticsToday) - *8h ago*
*   **Morningstar: Adient shows significant potential for margin expansion** (Morningstar) - *Current*


**Sentiment Analysis**: 
The prevailing institutional narrative is **Bullish**. The combination of an earnings beat, upgraded guidance, and price target raises from Stifel and Deutsche Bank has created a "Sword" profile for the stock. Social sentiment on Reddit and Twitter mirrors this, focusing on the "gap-and-go" potential and the Romulus plant acquisition as a fundamental catalyst for margin improvement.


---


# 3. Execution Parameters

*   **Execution State**: **SCOUT** (0.5R)
*   **Share Quantity**: `125` Shares
*   **Risk Unit (R)**: `$125.00`
*   **Strike Zone (Entry)**: `$22.78`
*   **Hard Stop**: `$21.78`
*   **Target (4:1 RR)**: `$26.78`


---


# 4. Structural Audit & Tactical Findings

**Market Structure (SMC Analysis)**:
*   **Institutional Trend**: **Bullish** (CHoCH at `26.1600`)
*   **Liquidity Sweep**: **YES** (Bearish) at `$22.34` — This level must be reclaimed for a full "Strike" deployment.
*   **Key Order Blocks**:
    *   **Bearish Resistance**: `$26.27` - `$27.32`
*   **Fair Value Gaps (FVG)**:
    *   **Bullish Support**: `$21.25` - `$21.52` (Unfilled magnet for potential retests).


**Volume Profile Intelligence**:
*   **Session POC**: `$20.57` (High volume support node).
*   **60d Value Area**: VAH `$22.63` | VAL `$19.03`.
*   **5d Value Area**: VAH `$21.94` | VAL `$20.25`.
*   **Observation**: Price is currently trading outside the 5-day and 60-day Value Areas, confirming a **High-Intensity Breakout**.


**Quantitative Metrics**:
*   **Sortino Ratio**: `2.03` (Sniper Hurdle: **PASS**)
*   **Volatility (ATR)**: `0.07` (5m timeframe)
*   **RVOL**: Significant institutional presence noted with over `1,000,000` shares traded pre-market.


---


# 5. Risk Guardrails

*   **Daily Kill Switch**: A breach of the 5-day Value Area Low at `$20.25` invalidates the bullish thesis.
*   **Trade Management**: Close laggards at `3:55 PM` if the VIX exceeds `25`.
*   **Psychological Pivot**: This is a **SCOUT** position. Do not scale to a full `1R` (Strike) unless the initial entry reaches Break-Even and clears the tactical resistance at `$22.34`.
*   **Performance Note**: Adherence to the `2:1` to `3:1` running RR ratio is mandatory; however, the Sniper strategy targets a `4:1` extension toward the `$26.78` macro resistance zone.