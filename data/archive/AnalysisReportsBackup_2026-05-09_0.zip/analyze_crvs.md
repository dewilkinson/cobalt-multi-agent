> **Generated:** Friday, May 08, 2026 at 10:02 AM

Active Strategy: Sniper Strategy

# 1. EXECUTION SUMMARY

**WAIT AUTHORIZED**

The mathematical profile for `CRVS` currently fails the institutional grade requirement for a Sniper-style execution. While the macro trend is strictly bullish with a Break of Structure (**BOS**) established at `$9.60`, the tactical layer is fragmented. The primary inhibitor is the **Sortino Ratio** of `1.41`, which falls significantly short of our `2.0` hurdle. 

The narrative is a "tug-of-war" between strong fundamental backing (Goldman Sachs `$40` target and a cash runway extending to 2028) and the immediate technical overhead created by a `-$13.7M` Q1 loss. Price is currently oscillating in a high-volatility "No Man's Land" between the **Macro POC** at `$15.38` and the **Tactical POC** at `$16.14`. Under the Sniper mandate, we do not fire into a Bearish Fair Value Gap (**FVG**) without a confirmed Change of Character (**CHoCH**). We remain in cash, awaiting a high-volume breach of tactical resistance.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

**News Headlines:**

*   **Corvus: Q1 Earnings Snapshot** | The Herald Review | 14h ago
    > Reported a loss of `-$13.7 million` in Q1, amounting to `-$0.15` per share.
*   **Cash runway to 2028 as Corvus (NASDAQ: CRVS) advances soquelitinib** | Stock Titan | 15h ago
    > Significant increase in liquidity to `$236.7 million` following successful financing.
*   **Corvus to show eczema data backing drug-free remission potential** | Stock Titan | 16h ago
    > Highlighting progress in clinical trials for soquelitinib in atopic dermatitis.
*   **Corvus Pharmaceuticals (CRVS.US) earnings release update** | Moomoo | May 07
    > Post-market earnings release confirmed for Thursday close.
*   **A Look At CRVS Valuation After Adding Dr. Andrew C. Chan To Board** | Sahm | May 02
    > Strategic board appointment signals focus on research-driven immunology growth.

**Social Sentiment Synthesis (Reddit/Twitter):**
Sentiment is cautiously bullish on the "Sword" potential of the clinical pipeline. High-frequency traders on Twitter are focusing on the Goldman Sachs "Buy" initiation, while Reddit biotech communities are debating the impact of the Q1 cash burn versus the extended runway. The prevailing narrative is one of "accumulation on dips," but the tape remains heavy following the earnings print.


---


# 3. EXECUTION PARAMETERS (CONTINGENT)

If structural alignment occurs (Price > `$16.20` on volume), the following parameters apply:

*   **Strike Zone (Entry)**: `$16.25`
*   **Hard Stop**: `$15.25`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Target (4:1 RR)**: `$20.25`


---


# 4. STRUCTURAL AUDIT: SMC ALIGNMENT

*   **Macro Bias**: **BULLISH** (Daily BOS at `$9.60`)
*   **Tactical Bias**: **NEUTRAL** (Trapped between POCs)
*   **Order Blocks**: 
    *   Bearish: `$8.20` - `$8.55` (Deep Discount)
*   **Fair Value Gaps (FVG)**: 
    *   Bearish: `$15.55` - `$15.75` (Active Overhead Resistance)
    *   Bearish: `$16.45` - `$17.63` (Macro Tactical Ceiling)
*   **Liquidity Profile**: 
    *   **Sweep Detected**: Bearish sweep at `$14.75`. 
    *   **Institutional POC**: `$15.38` (High-volume anchor)


---


# 5. MATHEMATICAL RISK & VOLATILITY

*   **Sortino Ratio**: `1.41` (**FAIL**)
*   **ATR (5m)**: `0.25`
*   **RVOL**: `1.2` (Institutional baseline met)
*   **Downside Deviation**: `0.62%`
*   **Risk Tier**: **SCOUT (0.5R)** if Sortino improves; currently **WAIT**.


---


# 6. RISK GUARDRAILS & NARRATIVE

The "Sniper" protocol requires precision. Current tape reading shows a bearish liquidity sweep at `$14.75` that has not yet been reclaimed by a bullish impulse. 

*   **Kill Switch**: A 5-minute candle close below `$15.10` (60d Macro VAL) invalidates the long-term "Sword" setup for the current session.
*   **Final Assessment**: CRVS is a high-potential "Sword" asset given its clinical catalysts, but it is currently "swinging wildly" post-earnings. We wait for the volatility to compress at the `$16.14` level. Do not front-run the breakout. We authorize capital only when the mathematical probability aligns with the structural breakout.