> **Generated:** Friday, May 08, 2026 at 01:37 PM

Active Strategy: Sniper Strategy


---


### 1. Execution Summary


**SCOUT Authorized** (Strategic Probe)


BOBS has executed a high-velocity technical breakout of `+4.73%`, successfully breaching the tactical Bearish Order Block at `$13.22`. While the Macro institutional trend remains in a Neutral/Accumulation phase, the price action has cleared the 5-day Value Area High (`$12.65`) and is now operating in a "Low Volume Node." This indicates a lack of overhead resistance until the next major institutional supply zone. 


Given the distance from the 5-day Point of Control (POC) of `$11.47`, a full Strike is withheld in favor of a **SCOUT** probe. This aligns with our "Sword" methodology—capturing high-momentum expansion while protecting the principal against a potential mean-reversion retest of the breakout flip zone at `$13.25`.


---


### 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


### 3. Structural Audit & Tape Reading


*   **Market Structure**: Bullish Tactical / Neutral Macro.
*   **CHoCH (Change of Character)**: Confirmed on the 1H timeframe following the breach of the `$13.17` - `$13.22` supply cluster.
*   **Institutional Footprint**:
    *   **Displacement Pivot (DP)**: `$13.22` (Former Bearish OB now acting as potential support).
    *   **External Liquidity Target**: `$17.75` (Previous cycle high).
    *   **Fair Value Gap (FVG)**: A massive bullish imbalance exists between `$10.30` and `$12.26`.
*   **Volumetric Anchors**:
    *   **60d Macro POC**: `$11.74`
    *   **5d Tactical POC**: `$11.47`
    *   **Session POC**: `$11.39`


---


### 4. Mathematical Hurdle (Sortino)


*   **Sortino Ratio**: `3.11`
*   **Status**: **PASS** (Hurdle `> 2.0`)
*   **Risk Efficiency**: The downside deviation is constrained to `0.71%`, suggesting that the current upward expansion is well-supported by institutional limit orders rather than retail FOMO.


---


### 5. Execution Parameters


*   **Execution State**: **SCOUT** (0.5R)
*   **Strike Zone (Entry)**: `$13.35` - `$13.61`
*   **Hard Stop**: `$12.50`
*   **Risk Unit (R)**: `$125`
*   **Share Quantity**: `112` Shares
*   **Target (1R)**: `$14.72`
*   **Stretch Target (Sniper 4:1)**: `$18.05` (Targeting the Macro Bearish OB)


---


### 6. Risk Guardrails


*   **The Kill Switch**: An hourly close below `$12.10` (the base of the previous liquidity sweep) invalidates the long thesis and mandates an immediate exit.
*   **Scale-In Plan**: If the `$13.25` level is tested and defended with a high-volume "hammer" or "wick" rejection, we will authorize a scale-in to a full 1R **STRIKE** position.
*   **Sword/Shield Balance**: This is a "Sword" position. Total exposure is limited to `0.5%` of the total account equity given the "Scout" tiering, ensuring drawdowns are minimized if the breakout fails to find follow-through.