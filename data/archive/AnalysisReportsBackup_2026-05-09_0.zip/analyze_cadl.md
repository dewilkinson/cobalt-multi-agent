> **Generated:** Friday, May 08, 2026 at 12:04 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**WAIT Authorized**


Candel Therapeutics (`CADL`) demonstrates a strong institutional footprint with a bullish Macro CHoCH confirmed at `6.62`. However, the asset is currently overextended into "Thin Air," trading at `$7.99`, well above its 5-day Tactical POC of `6.30` and Value Area High (VAH) of `7.68`. 


A bearish liquidity sweep at `7.77` indicates local exhaustion and potential profit-taking by smart money. Under the **Sniper Strategy** (40% WR | 4:1 RR), we do not chase price into premium zones. We require a precise retest of the Tactical VAH and the massive FVG (Fair Value Gap) sitting between `6.52` and `7.49` to secure the necessary Reward-to-Risk ratio. Purity of entry is paramount; we wait for the retracement to the high-confluence strike zone.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish** (Multi-Timeframe Alignment)


*   **Market Structure**:
    *   **Macro Trend**: Shifted Bullish via CHoCH at `6.62`.
    *   **Liquidity State**: Bearish External Sweep completed at `7.77`.
    *   **Institutional Zones**:
        *   **Primary Order Block**: `6.11` — `6.52` (High-confluence demand).
        *   **Major Imbalance (FVG)**: `6.52` — `7.49` (Magnet for mean reversion).


*   **Volume Profile Analysis**:
    *   **Macro POC**: `$5.00`
    *   **5-Day Tactical POC**: `$6.30`
    *   **5-Day Value Area High (VAH)**: `$7.68`
    *   **Current Price State**: Trading at an extreme premium to value.


---


# 4. Mathematical Hurdle (Sortino)


*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `6.19`
*   **Threshold**: `2.0`
*   **Status**: **PASS**


*Note: While the risk-adjusted efficiency is elite, the high Sortino is driven by vertical price action that now risks a sharp corrective move (downside deviation).*


---


# 5. Execution Parameters (Sniper Protocol)


If price retraces to the structural displacement pivot, the following parameters are authorized:


*   **Strike Zone (Entry)**: `$7.65`
*   **Hard Stop**: `$7.55`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `2,500` Shares
*   **Target (4:1 RR)**: `$8.05`


---


# 6. Risk Guardrails


*   **Sword Classification**: CADL is a high-velocity **Sword**. It provides aggressive growth potential but requires strict adherence to the stop-loss due to its `0.06` 5-minute ATR and potential for rapid mean reversion.


*   **Kill Switch**: A session close below `$7.49` invalidates the bullish FVG support and mandates an immediate exit of any speculative positions.


*   ** sniper Discipline**: We are currently in "Patience Mode." Entering at the current market price of `$7.99` would result in a sub-optimal RR and violate the Blueshell Securities risk mandate. We await the `$7.65` trigger.