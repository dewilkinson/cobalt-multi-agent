> **Generated:** Friday, May 08, 2026 at 09:57 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**Execution Authorization: WAIT**


The current technical setup for `CAPR` fails the mandatory mathematical hurdles required for a Sniper deployment. While the institutional macro trend remains bullish (validated by a CHoCH at `$8.06`), tactical volatility has decoupled from price stability following the HOPE-3 data release and the initiation of legal proceedings against NS Pharma.


The primary driver for the **WAIT** status is the **Sortino Ratio of `0.19`**, which sits significantly below the institutional floor of `2.0`. This indicates that the current reward-to-risk profile is dominated by uncompensated downside volatility. Until the volatility curve flattens and price clears the bearish Fair Value Gaps (FVG) between `$30.88` and `$32.88`, capital preservation is the priority.


***


# 2. Institutional News & Social Sentiment


*   **CAPR Stock Sinks After-Hours: Capricor Launches Legal Fight Over DMD Therapy Rollout**
    *Source: Stocktwits | Timestamp: Recent*
*   **Capricor Sues NS Pharma Over Deramiocel Launch Issues**
    *Source: Intellectia AI | Timestamp: Recent*
*   **Capricor Therapeutics (CAPR) Is Down -12.4% After New HOPE-3 Deramiocel Phase 3 Data Release**
    *Source: Simply Wall Street | Timestamp: Recent*
*   **Capricor Therapeutics to Report Q1 2026 Financial Results and Corporate Update on May 12**
    *Source: GlobeNewswire | Timestamp: Scheduled*
*   **Short Interest in Capricor Therapeutics (CAPR) Increases By `34.6%`**
    *Source: MarketBeat | Timestamp: Recent*


**Synthesis**: The narrative is currently high-friction. The "Sword" growth thesis is being challenged by a legal "Shield" conflict with NS Pharma. Social sentiment is fragmented, with significant bearish pressure mounting via a spike in short interest. The market is in a "wait-and-see" mode ahead of the May 12th update.


***


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish Macro / Neutral Tactical**
*   **Macro POC (Point of Control)**: `$24.67` (60-day Baseline)
*   **Tactical POC**: `$34.82` (Heavy distribution zone)
*   **Value Area High (VAH)**: `$31.57`
*   **Value Area Low (VAL)**: `$23.03`
*   **Liquidity Void**: A significant bearish FVG exists between `$30.88` and `$32.88`. This acts as institutional overhead supply.
*   **Order Block (OB)**: Bullish demand is concentrated between `$25.07` and `$28.89`.


***


# 4. Execution Parameters


*Note: These parameters are authorized ONLY upon a confirmed trigger.*


*   **Strategy**: Sniper (High-Frequency/Precision)
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: **WAIT** for close above `$33.32`
*   **Hard Stop**: `$28.00` (Structural invalidation)
*   **Share Quantity**: `125` Shares (Calculated at full 1R)
*   **Initial Probe**: `62` Shares (0.5R Scout sizing recommended for biotech)


***


# 5. Mathematical Hurdles


*   **Sortino Ratio ($S_{DR}$)**: `0.19` (**FAIL**; Hurdle is `2.0`)
*   **Volatility (ATR 5m)**: `0.56`
*   **Daily Drawdown Target**: Minimize to `< 1R`
*   **RVOL (Relative Volume)**: Currently accumulating; requires `> 2.0` for breakout authorization.


***


# 6. Risk Guardrails


*   **Sword/Shield Balance**: The portfolio is currently "Sword" heavy for this ticker. Caution is advised given the `-12.4%` volatility spike.
*   **Event Risk**: High volatility expected on **May 12, 2026**, due to the Q1 Financial Results and corporate update.
*   **Kill Switch**: A daily close below the Macro POC of `$24.67` invalidates the long-term bullish structural thesis and triggers a full exit of all tracking positions.
*   **Psych Reset**: If any attempted scout takes a `-1R` loss, revert to `0.5R` sizing for all subsequent biotech probes for 5 sessions.