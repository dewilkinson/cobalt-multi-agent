> **Generated:** Saturday, May 02, 2026 at 01:21 PM

# 1. Execution Summary

**STRIKE Authorized**


VIAV is currently exhibiting a high-velocity "Sword" profile, perfectly aligned with the institutional "Grinder" mandate. The primary catalyst for this authorization is a massive **Sortino Ratio of `5.27`**, indicating that the asset’s recent volatility is overwhelmingly skewed to the upside, far exceeding our `2.0` risk hurdle. Technical confirmation is provided by a successful bullish liquidity sweep at `$55.88`, followed by a consolidation base above the tactical Value Area.


The institutional narrative is bolstered by a significant Q3 earnings beat (EPS `$0.27`) and a subsequent price target hike from Needham to `$68`. While the price is technically extended from the macro Point of Control, the combination of strong relative strength (+`5.41%` vs $SPY) and a verified SMC liquidity grab justifies a full `1.0R` strike toward the cycle high.


---


# 2. Institutional News & Social Sentiment

*   **Needham & Company LLC (2d ago)**: Raised price target to `$68` from `$53`, maintaining a "Buy" rating. Analysts cite strong Q3 earnings and roughly `50%` projected upside.


*   **StockStory (3d ago)**: VIAV shares jumped over `14%` following a robust Q1 earnings report that beat estimates and provided optimistic forward guidance.


*   **Investing.com (3d ago)**: Stock hit a 52-week high, trading as high as `$56.47`. Market cap has expanded to approximately `$10B` amid a `330%` one-year return.


*   **Stock Titan (4d ago)**: CEO Oleg Khaykin donated `5,600` shares to Carnegie Mellon University. Notably, he retains over `1.58M` shares, signaling continued long-term alignment.


*   **Social Sentiment**: Strong bullish consensus on Twitter/X and Reddit following the earnings gap-up. Retail sentiment is high, but the move is supported by institutional accumulation evidenced by the `1.2x` RVOL.


---


# 3. Execution Parameters

*   **Strike Zone (Entry)**: `$55.33` (Current Market Price)


*   **Hard Stop**: `$54.33` (Placed strictly below the 5-minute consolidation wick)


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `250` **Shares**


*   **Primary Target**: `$60.43` (Macro Cycle Ceiling)


*   **Trailing Anchor**: Engage a 1R trailing stop once price reaches `$56.33`


---


# 4. Technical Structural Audit

**Bias**: Bullish (MTF Alignment)


*   **Macro Ceiling**: `$60.43` (Highest wick of the current cycle; primary take-profit zone)


*   **Tactical Displacement Pivot (DP)**: `$19.75` (The structural origin of the current macro bullish expansion)


*   **Liquidity Sweep**: **YES** (Bullish sweep completed at `$55.88`)


*   **Market Structure**: Bullish Break of Structure (**BOS**) confirmed at `$19.75`


*   **Volatility (ATR 5m)**: `$0.29` (Provides room for the `$1.00` hard stop)


---


# 5. Institutional Footprint & Volume Profile

*   **Macro Point of Control (POC)**: `$17.82` (Long-term value area)


*   **Tactical POC (5-Day)**: `$41.15`


*   **Value Area High (VAH)**: `$46.70`


*   **Order Block (OB)**: `$26.87` — `$29.28` (Major institutional floor)


*   **Fair Value Gap (FVG)**: `$46.06` — `$49.26` (Significant upside imbalance acting as a magnet for mean reversion if momentum fails)


---


# 6. Risk Management & Guardrails

*   **Sortino Pass**: **YES** (`5.27` Actual vs `2.0` Goal)


*   **Relative Strength**: VIAV is outperforming the S&P 500 by `5.41%` intraday.


*   **Kill Switch**: `$53.17` (Full liquidation required if price closes below this tactical support level on the 5-minute chart)


*   **Execution Logic**: This is a "Sword" momentum trade. We are entering the "Thin Air" zone above the VAH. Because the asset is extended, the risk is managed via a tight momentum stop rather than a structural stop at the FVG. Trail aggressively to secure the Risk Unit at the first `1R` expansion.