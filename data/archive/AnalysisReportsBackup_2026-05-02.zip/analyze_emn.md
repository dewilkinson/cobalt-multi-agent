> **Generated:** Saturday, May 02, 2026 at 01:11 PM

# 1. Execution Summary

**WAIT (Retain Cash)**

The institutional audit for **EMN** (Eastman Chemical Company) mandates a strictly defensive posture. While the asset has printed a significant bullish displacement of `+4.00%` to reach `$77.53`, it fundamentally fails the CMA Persona's primary mathematical gate. 

The **Sortino Ratio** currently sits at `0.71`, which is drastically below the mandatory `2.0` threshold required for Dave Wilkinson’s high-fidelity Sniper entries. This indicates that despite the aggressive upward move, the historical downside deviation (`0.39%`) remains too high relative to the reward, suggesting an elevated risk of "structural ghosting" or deep stop-hunts. Furthermore, the higher timeframe institutional trend remains **Neutral**, and the asset is trading in **Premium** relative to its 60-day Point of Control (`$68.44`). No **STRIKE** or **SCOUT** execution is authorized at this level.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading

*   **Tactical Bias**: **Bullish (Short-Term)** / **Neutral (Macro)**


*   **Market Structure (Dual-Anchor Protocol)**:
    *   **Macro Ceiling (Absolute High)**: `$83.47` — This remains the primary structural objective and cycle resistance.
    *   **Tactical DP (Displacement Pivot)**: `$74.11` — Successfully reclaimed; this level is now the vital support floor for the current impulse.
    *   **CHoCH Status**: **Confirmed** on the 1-hour timeframe via the displacement above the `$74.00` zone.


*   **Institutional Footprint**:
    *   **High-Probability FVG**: `$73.96` – `$75.77` — This Fair Value Gap represents the "Smart Money" entry zone. We do not chase the extension; we await the retracement.
    *   **Value Profile (60-Day)**: Current price is testing the Macro **Value Area High (VAH)** of `$77.65`. Rejection here is likely without a fresh fundamental catalyst.
    *   **RVOL & Liquidity**: Volume is healthy at `2,628,000` shares, but the tape lacks a clean **Liquidity Sweep** at the current highs, suggesting the move may be overextended in the immediate term.


---


# 4. Mathematical Hurdle (Sortino Sniper)

| Metric | Value | Status |
| :--- | :--- | :--- |
| **Current Price** | `$77.53` | **PASS** |
| **Intraday Change** | `+4.00%` | **PASS** |
| **Sortino Ratio (20d)** | `0.71` | **FAIL (Hurdle: 2.0)** |
| **ATR (5m)** | `1.04` | **STABLE** |


*   **Risk Evaluation**: The current **Sortino** profile suggests that the "Shield" properties of **EMN** are compromised by recent volatility. Under the **Blueshell Securities** mandate, we preserve capital until risk-adjusted efficiency aligns with structural intent.


---


# 5. Execution Parameters

*   **Execution Authorization**: **NONE**
*   **Strike Zone (Entry)**: `N/A`
*   **Hard Stop**: `N/A`
*   **Risk Unit (R)**: `$0`
*   **Share Quantity**: `0`


---


# 6. Risk Guardrails & Tactical Path

*   **Tactical Path**: We are monitoring for a "Return to FVG" between `$73.96` and `$75.77`. An entry may be considered only if the **Sortino Ratio** expands toward `2.0` during the consolidation phase.


*   **Kill Switch**: A daily close below the **Tactical DP** of `$74.11` invalidates the bullish recovery thesis and resets the scan.


*   **War Barbell Allocation**: As a Materials/Industrial play, **EMN** is classified as a **Shield** asset. In the current macro context of a **Neutral** trend, we prioritize the protection of the `$100k` base over chasing unconfirmed momentum thrusts into supply. 


*   **Portfolio Note**: Notify the desk if **EMN** maintains current levels for 3+ sessions, as time-decay in volatility may lead to a mathematical upgrade.