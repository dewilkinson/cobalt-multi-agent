> **Generated:** Saturday, May 02, 2026 at 01:17 PM

# 1. Execution Summary

**STRIKE Authorized**

**ADEA** is exhibiting high-velocity institutional alignment following a macro Change of Character (CHoCH) at `$18.25`. The asset is currently in a momentum breakout phase, trading significantly above the 60-day Value Area High of `$26.38`. With a **Sortino Ratio of 5.07**, the mathematical downside parity is exceptional, authorizing a full **1R Strike** deployment. 

The structural footprint confirms that "Smart Money" is defending higher price tiers, evidenced by the recent liquidity sweep at `$33.50`. While the price is in a "Premium" zone, the lack of overhead supply and the high Sortino value suggest a high probability of continuation toward the macro cycle peak.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading

*   **Bias / Trend**: **Bullish** (Multi-Timeframe Alignment).
*   **Relative Strength**: **ADEA** is significantly outperforming the **$SPY**, gapping away from its macro POC while maintaining vertical trajectory.

**Dual-Anchor Protocol Levels**:
*   **Macro Ceiling (Absolute High)**: `$34.80` (Primary cycle resistance and Take Profit target).
*   **Tactical DP (Displacement Pivot)**: `$31.75` (The structural floor for the current momentum leg).

**Institutional Footprint**:
*   **BOS/CHoCH**: Bullish CHoCH confirmed at `$18.25`.
*   **Imbalance (FVG)**: `$31.04` – `$31.75` (1h Bullish Fair Value Gap) acts as a primary magnet/safety net.
*   **Liquidity**: Recent Bullish Sweep at `$33.50` confirms active participation.
*   **Volume Profile**: Trading above Tactical POC `$30.14` and VAH `$33.10`.


---


# 4. Mathematical Hurdle (Sortino)

*   **Hurdle Result**: **PASS**
*   **Sortino Value**: `5.07`
*   **Downside Deviation**: `0.41%`
*   **Analysis**: The ratio is far above the `2.0` requirement. The minimal downside deviation proves that intraday dips are shallow and recover with high efficiency, fitting the "Sword" profile for asymmetric growth.


---


# 5. Execution Parameters

*   **Strategy**: **STRIKE Authorized** (1.0R Deployment)
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$32.85` – `$33.15`
*   **Hard Stop**: `$32.15` (Anchored below 5m structural low + 2x ATR buffer)
*   **Share Quantity**: `294 Shares`
*   **Volatility (ATR)**: `0.31`


---


# 6. Risk Guardrails & Exit Strategy

*   **Kill Switch**: **$31.70**. A close below the **Tactical DP** invalidates the momentum thesis; exit the position immediately.
*   **Profit Taking**:
    *   **Target 1**: `$34.80` (Macro Ceiling).
    *   **Trailing Anchor**: Engage a 1R trailing stop once price hits `$33.85`.
*   **Momo Exit**: Trail the final `25%` of the position using the 5-min `9 EMA`.
*   **MOC Rule**: If **VIX** exceeds `25` near the close, exit laggards at `3:55 PM ET`.