> **Generated:** Saturday, May 02, 2026 at 01:27 PM

# 1. Execution Summary


**STRIKE Authorized**


CRWV is exhibiting elite institutional accumulation and is a premier candidate for our "Sword" strategy. The asset has cleared the institutional hurdle with a **STRIKE** authorization due to total confluence between the multi-timeframe (MTF) SMC trend—notably the Bullish CHoCH at `$103.44`—and the Tri-Mandate Volume Profile. 


The stock is currently trading above its Macro POC of `$80.36` and its Tactical/Session POCs of `$117.50`, confirming that higher prices are being accepted by "Smart Money." With a current price of `$119.01` and a gain of `6.64%` on significant volume of `27,336,100` shares, the tape confirms aggressive participation. The **Sortino Ratio** of `5.91` is nearly triple our internal requirement, indicating that downside volatility is being systematically absorbed by institutional buy-walls.


---


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Quantitative Analysis & Metrics


*   **Current Price**: `$119.01`


*   **Session Change**: `+6.64%`


*   **Sortino Ratio**: `5.91` (Status: **PASS**)


*   **Volatility (ATR 5m)**: `0.24`


*   **Relative Strength**: Extremely High (Gapping significantly higher than the benchmark indices).


---


# 4. SMC Structural Audit (Dual-Anchor Protocol)


*   **Macro Ceiling (Absolute High)**: `$124.96` (The primary cycle resistance target).


*   **Tactical DP (Displacement Pivot)**: `$112.91` (Top of the primary Bullish FVG).


*   **Institutional Trend**: Bullish (Confirmed via CHoCH at `$103.44`).


*   **Liquidity Sweep**: Bullish Sweep confirmed at `$119.32`.


*   **Key Imbalance (FVG)**: `$110.00` – `$111.18` (Primary institutional magnet on pullbacks).


*   **Order Block (OB)**: `$67.15` – `$75.46` (Deep structural macro floor).


---


# 5. Execution Parameters


*   **Execution State**: **STRIKE** (1.0R Deployment)


*   **Risk Unit (R)**: `$250`


*   **Strike Zone (Entry)**: `$118.50` – `$119.10`


*   **Hard Stop**: `$117.20` (Positioned below the 5m/1d POC support floor).


*   **Share Quantity**: `131` Shares.


---


# 6. Risk Guardrails & Exit Strategy


*   **Kill Switch**: `$116.43` (Close all positions if price breaches the Session Value Area Low).


*   **Trailing Anchor**: Engage a trailing stop immediately when price hits `$121.00` (1R profit).


*   **Momentum Exit**: Trail the final `25%` of the position using the 5-min `9 EMA`. Close the remaining position if price closes below this EMA or reaches the Macro Ceiling of `$124.96`.


*   **Note**: The alignment of the `$117.50` POC across both tactical and session profiles provides a high-conviction support floor for this momentum move. Avoid holding through any unannounced binary events.