> **Generated:** Saturday, May 02, 2026 at 01:13 PM

# 1. Execution Summary


**STRIKE Authorized** (Full Deployment)


RIOT is demonstrating high-conviction institutional displacement, having successfully completed a **Bullish Change of Character (CHoCH)** on the `1d` timeframe at `$17.40`. The asset has cleared its **Macro POC** of `$14.66` and is currently consolidating near the session **VAH** of `$18.84`. 


The move is characterized by massive institutional volume (`32.8M` shares) and the reclamation of a significant bearish **Fair Value Gap (FVG)** between `$17.57` and `$18.26`, which now serves as a foundational support zone. With a tactical **Sortino Ratio** of `5.65`, RIOT is exhibiting the high-efficiency upside required for a "Sword" position, with minimal downside deviation during intraday micro-dips.


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading


*   **Bias / Trend**: **Bullish** 


*   **Market Structure (Dual-Anchor Protocol)**:
    *   **Macro Ceiling (Absolute High)**: `$19.49` (Primary Institutional Target).
    *   **Tactical DP (Displacement Pivot)**: `$17.40` (Structural reclaim level).
    *   **BOS/CHoCH**: Bullish CHoCH confirmed on `1d` at `$17.408`.
    *   **Zone**: Premium (Trading above Macro POC; anchored to tactical support).


*   **Institutional Footprint**:
    *   **Imbalance (FVG)**: `$17.57` - `$18.26` (Reclaimed as support).
    *   **Order Block (OB)**: `$11.50` - `$13.06` (Macro accumulation floor).
    *   **Liquidity Sweep**: `$18.345` (Bearish sweep reclaimed; price stabilized above high).


---


# 4. Mathematical Hurdle (Sortino)


*   **Hurdle Result**: **PASS** 


*   **Sortino Value**: `5.65` 


*   **Analysis**: Exceptional risk-adjusted performance. The downside deviation of `0.28%` indicates that institutional "Smart Money" is aggressively defending pullbacks, keeping the asset well above our `2.0` Sortino requirement.


---


# 5. Execution Parameters


*   **Execution State**: **STRIKE Authorized** 


*   **Risk Unit (R)**: `$250` 


*   **Strike Zone (Entry)**: `$18.20` - `$18.50` 


*   **Hard Stop**: `$17.50` (Placed strictly below the Tactical DP and reclaimed FVG).


*   **Share Quantity**: `250` Shares 


*   **Trailing Anchor**: Engage a `1R` trailing stop immediately upon price touching `$19.50`.


---


# 6. Risk Guardrails & Narrative


*   **Sword Classification**: RIOT is behaving as a high-beta "Sword" asset. Its performance is currently tethered to broader crypto-liquidity expansion and yield decompression.


*   **Kill Switch**: Close the position immediately if the price breaks back below the **Tactical Displacement Pivot** at `$17.40`.


*   **Momo Exit**: If the trade hits `1R` profit and becomes "Free," trail the remaining 25% of the position using the `5-min` `9 EMA`.


*   **Volatility Warning**: The current `5m` **ATR** is `0.06`. In the event that the **VIX** spikes above `24`, shift to the **MOC Exit Protocol** at `3:55 PM ET` to eliminate overnight gap risk.