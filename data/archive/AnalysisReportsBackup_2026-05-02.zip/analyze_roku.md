> **Generated:** Saturday, May 02, 2026 at 01:09 PM

# 1. Execution Summary


**WAIT (Retain Cash)**


The execution authorization for **ROKU** is currently withheld. While the asset demonstrates exceptional risk-adjusted efficiency with a **Sortino Ratio** of `4.79` (well above our `2.0` hurdle), the current price action at `$123.58` represents a **Bearish Liquidity Sweep** on the 5-minute timeframe. Entering at this level would constitute "buying the wick" into institutional supply.


ROKU is a high-performance "Sword" asset, but it is currently detached from its **Macro Value Area** (VAH `$110.84`) and is showing signs of momentum exhaustion near the **Tactical VAH** of `$125.04`. To maintain our asymmetric 3:1 RR mandate, we must wait for a mean reversion toward the **Tactical Displacement Pivot** at `$115.47` before deploying capital.


---


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Quantitative Metrics (Ground Truth)


*   **Current Price**: `$123.58`
*   **Daily Change**: `-1.01%`
*   **Sortino Ratio**: `4.79` (Mandate: $\ge 2.0$ — **PASS**)
*   **5-Minute ATR**: `0.15`
*   **Total Volume**: `8,097,500`
*   **Macro POC (60d)**: `$95.70`
*   **Tactical POC (5d)**: `$115.47`
*   **Macro VAH (60d)**: `$110.84`


---


# 4. Structural Audit & SMC Mapping


**Market Structure (Dual-Anchor Protocol)**:
*   **Macro Ceiling (Absolute High)**: `$132.00` (Cycle resistance tail).
*   **Tactical DP (Displacement Pivot)**: `$115.47` (Local Point of Control and high-volume node).
*   **Macro CHoCH**: `$91.10` (Long-term structural floor).


**Institutional Footprint**:
*   **Liquidity Sweep**: Bearish sweep identified at `$123.58`.
*   **Bullish Fair Value Gap (FVG)**: `$109.88` – `$112.33` (Institutional magnet for a potential pull-back).
*   **Primary Order Block (OB)**: `$84.90` – `$88.24` (Deep discount accumulation zone).
*   **Positioning**: Price is currently in the **Premium Zone**, trading well above both the 5-day and 60-day Value Areas.


---


# 5. Execution Parameters


In accordance with the **Sortino Sniper** framework, we await the following setup for a high-probability entry:


*   **Strike Zone (Entry)**: `$115.50` – `$116.50` (Return to Tactical Value).
*   **Hard Stop**: `$114.50` (Strict momentum stop placed below the Tactical POC).
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares.
*   **Target 1 (1R Trailing)**: `$118.50`
*   **Macro Target (The Ceiling)**: `$132.00`


---


# 6. Risk Guardrails & War Barbell


*   **Asset Classification**: **Sword** (High Beta / Growth-oriented).
*   **Kill Switch**: A daily close below the **Macro VAH** of `$110.84` invalidates the current bullish thesis.
*   **VIX Alignment**: If the **VIX** remains below `24`, we will authorize a **1.0R STRIKE** once the price enters the designated Strike Zone. 
*   **Tactical Narrative**: Do not succumb to FOMO at the `$123.00` handle. Professional "Smart Money" enters at the **POC**, not during the sweep of the highs. We prioritize the preservation of the **Sortino Ratio** by avoiding high-volatility entries at tactical cycle peaks.