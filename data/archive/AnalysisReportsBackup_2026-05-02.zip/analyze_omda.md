> **Generated:** Saturday, May 02, 2026 at 01:08 PM

# 1. Execution Summary


**STRIKE Authorized**


$OMDA$ has transitioned into a high-conviction "Sword" phase following a definitive **Break of Structure (BOS)** at `15.10`. The technical narrative is exceptionally strong, characterized by a **Liquidity Sweep** at `15.45` which has neutralized local sell-side pressure, clearing the path for an expansion leg toward the **Macro Ceiling** at `17.47`. 


Mathematically, the asset is performing at an elite level with a **Sortino Ratio** of `3.40`, far exceeding our institutional hurdle of `2.0`. This indicates that volatility is overwhelmingly skewed toward the upside, with a minimal downside deviation of only `0.54%`. The reclamation and defense of the `15.10` tactical displacement pivot transforms prior resistance into a structural floor, providing an asymmetric entry opportunity with a high R-multiple potential.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Execution Parameters


*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `15.15` – `15.30` (Optimal on retest of the BOS level)
*   **Hard Stop**: `14.95` (Placed strictly below the structural pivot and psychological `15.00` level)
*   **Share Quantity**: `1,250` Shares
*   **Target 1 (1R Trim)**: `15.50` (Take 50% profit and engage Trailing Anchor)
*   **Target 2 (Macro Objective)**: `17.47` (Final Exit)
*   **Trailing Mechanism**: Once `1R` is achieved, trail the remaining `25%` of the position using the **5-min 9 EMA**. Exit on the first 5-minute candle close below the EMA.


---


# 4. Quantitative Findings & SMC Audit


### **Market Structure (Dual-Anchor Protocol)**
*   **Macro Ceiling (Cycle High)**: `17.47`
*   **Tactical DP (Displacement Pivot)**: `15.10`
*   **Institutional Trend**: **Bullish** (Confirmed MTF Alignment)
*   **BOS/CHoCH**: **BOS** at `15.10`
*   **Zone Status**: **Premium** (Price accepted above the 60d Value Area)


### **Institutional Footprint**
*   **Liquidity Sweep**: **YES** (Bullish sweep of `15.45`)
*   **Order Block (Bullish)**: `11.20` – `11.99` (Primary Macro Origin)
*   **Fair Value Gaps (FVG)**:
    *   `14.41` – `14.44` (Immediate Structural Support)
    *   `13.64` – `13.90` (Secondary Liquidity Void)


### **Risk Metrics & Volatility**
*   **Sortino Ratio**: `3.40` (**PASS**)
*   **Downside Deviation**: `0.54%`
*   **ATR (5m)**: `0.17`
*   **Daily Change**: `+4.37%`


---


# 5. Volumetric Triangulation


*   **Macro POC (60d)**: `14.02`
*   **Macro VAH**: `15.97`
*   **Macro VAL**: `12.38`
*   **Tactical POC (5d)**: `14.06`
*   **Current Volume**: `1,567,300` shares (Institutional Accumulation Profile)


---


# 6. Risk Guardrails


*   **Kill Switch**: A daily close below `14.50` (Upper FVG) invalidates the current institutional markup thesis.
*   **War Barbell Allocation**: This is a **Sword** position. Per the CMA Protocol, maintain this for fast growth, but ensure **Shield** assets are allocated if the VIX exceeds `24`.
*   **IRA Compliance**: This is a long-only equity execution. No margin is utilized. Total risk is strictly capped at `0.25%` of the total `$100k` account value.