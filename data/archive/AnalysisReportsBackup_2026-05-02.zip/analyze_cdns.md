> **Generated:** Saturday, May 02, 2026 at 01:34 PM

### 1. Execution Summary


**STRIKE Authorized**


**Cadence Design Systems (CDNS)** is demonstrating a high-probability institutional breakout, perfectly aligning with our **Sword** criteria for high-growth momentum. The setup is anchored by a Bullish Change of Character (**CHoCH**) on the Daily timeframe at `$328.64` and reinforced by a crystal-clear 5-minute Liquidity Sweep at `$340.57`. 


With a Day Trading **Sortino Ratio** of `2.85`, the mathematical hurdle for downside protection is effectively cleared, indicating that "Smart Money" is actively defending dips. Volume profile confluence shows price has moved into a "Low Volume Node" above the `$330.15` Point of Control (**POC**), suggesting a momentum expansion toward the cycle high is imminent.


---


### 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


### 3. Execution Parameters


*   **Execution State**: **STRIKE** (1.0R Deployment)


*   **Share Quantity**: `92` Shares


*   **Risk Unit (R)**: `$250`


*   **Strike Zone (Entry)**: `$340.50` - `$340.95`


*   **Hard Stop**: `$338.25` (Set strictly below the ATR-adjusted volatility floor)


*   **Trailing Exit**: Engage **1R Trailing Anchor** at `$343.65`; trail remaining `25%` via 5-min `9 EMA`.


---


### 4. Structural Audit & Tape Reading


**Bias / Trend**: **Bullish** (MTF Alignment)


**Market Structure (Dual-Anchor Protocol)**:
*   **Macro Ceiling (Absolute High)**: `$350.00` (Primary Profit Target / Psychological Resistance).


*   **Tactical DP (Displacement Pivot)**: `$328.64` (The structural origin of the current bullish shift).


*   **Institutional Footprint**: Fresh Bullish Fair Value Gap (**FVG**) identified between `$331.36` and `$334.00`.


*   **Liquidity Profile**: Recent 5-minute sweep at `$340.57` has flushed retail stops, clearing the path for an institutional "run" into premium pricing.


---


### 5. Quantitative Metrics (Ground Truth)


*   **Current Price**: `$340.94`


*   **Intraday Change**: `+2.31%`


*   **Sortino Ratio**: `2.85` (Passes `>= 2.0` Hurdle)


*   **Downside Deviation**: `-0.32%`


*   **Volatility (ATR 5m)**: `2.25`


*   **Volume Profile POC**: `$330.15`


*   **Value Area High (VAH)**: `$342.78`


---


### 6. Risk Guardrails & Portfolio Fit


*   **Kill Switch**: Close position immediately if price fails to hold the intraday floor of `$337.50`.


*   **War Barbell Context**: This position serves as a **Sword**. It is optimized for an environment where treasury yields are stabilizing, allowing high-multiple EDA (Electronic Design Automation) leaders like **CDNS** to expand their structural range.


*   **IRA Compliance**: Long-only equity execution. No margin required. Total risk strictly capped at `0.25%` of the `$100k` account.


**Execution Grade**: **A-Tier** (Technicals, Sortino, and Volume Profile in total confluence).