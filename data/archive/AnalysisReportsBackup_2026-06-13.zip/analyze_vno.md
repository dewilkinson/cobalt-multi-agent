1. Execution Summary
**WAIT (Retain Cash)**. VNO presents a compelling bullish macro structure and strong fundamental catalysts, including the recent `90%` lease-up of PENN 2 and a new `$300` million share repurchase program. However, the current price of `$38.68` is significantly extended above key volume value areas and fair value gaps, indicating an overbought condition. Furthermore, while the Sortino Ratio of `8.40` is acceptable for swing trading, it does not meet the stringent `20.0` threshold required for high-frequency day trading. A patient approach, waiting for a retracement into established support zones, is prudent to optimize the risk-reward profile.

---

2. Institutional News & Social Sentiment

Vornado Realty Trust (VNO) has seen significant positive institutional developments and a notable lack of retail attention.

*   **PENN 2 Leasing Milestone (June 9, 2026 - *StockTitan, 8:30 AM ET*)**: Vornado announced its PENN 2 office tower is `90%` leased. Key leases include Veeva (`62,223` SF for `12` years) and Altana (`62,309` SF for `10` years). This is a major positive catalyst, indicating successful monetization of a flagship development.
*   **Meta Flagship Lease (May 2026 - *StockTitan*)**: VNO secured a `10`-year lease with Meta for its first Manhattan flagship retail location at `697` Fifth Avenue (`15,000` SF). This highlights the quality of VNO's prime real estate assets.
*   **Share Buyback Authorization (April 29, 2026 - *StockTitan*)**: A new `$300` million share repurchase program was authorized. The previous program saw `6.93` million shares bought back at an average price of `$25.80`, demonstrating strong management confidence.
*   **Q1 2026 Earnings & Guidance (May 4, 2026 - *MarketBeat, Yahoo Finance*)**: Reported Q1 FFO of `$0.52`/share (missing consensus of `-$0.05` by `-$0.07`), but revenue beat estimates at `$459.11` million vs. `$431.72` million. Management projects FY 2026 FFO to slightly exceed 2025, with **significant exponential growth in 2027** as PENN 1 and PENN 2 leases fully contribute.

**Social Sentiment**:
*   **Reddit (AltIndex)**: **Zero retail mentions** over the last `30` days, ranking VNO last among peers. This indicates a complete absence of retail "hype."
*   **Stocktwits**: Sentiment is **Neutral** with exceptionally low message volume.
*   **Overall**: The lack of retail engagement, coupled with strong fundamental news and institutional actions (buybacks, major leases), suggests VNO's price action is driven by institutional capital and fundamental turnaround, aligning with a **pure institutional tape** environment.

---

3. SMC & Structural Analysis

*   **Current Price**: `$38.68`
*   **Institutional Trend (1d)**: **Bullish** (Change of Character (CHoCH) confirmed at `$26.80`).
*   **Tactical Zones (1h)**:
    *   **Bullish Order Block**: `$30.02` - `$31.63` (Significant support zone).
    *   **Fair Value Gaps (FVGs)**:
        *   `$34.28` - `$34.55` (Potential retracement target)
        *   `$35.07` - `$35.38` (Potential retracement target)
        *   `$35.48` - `$36.68` (Potential retracement target)
*   **Execution Trigger (5m)**: **NO Liquidity Sweep (Accumulating)**. This suggests the current upward move is a continuation of accumulation rather than a reversal from a liquidity grab.
*   **Apex Authorization Matrix**: **[PASS]** Execution trigger aligns with MTF Institutional Macro trend.

---

4. Volume Profile (60-Day & 5-Day)

*   **60-Day Volume Profile**:
    *   **Point of Control (POC)**: `$26.04` (Highest traded volume price)
    *   **Value Area High (VAH)**: `$31.64`
    *   **Value Area Low (VAL)**: `$25.16`
    *   **Analysis**: The current price of `$38.68` is significantly above the `60`-day Value Area, indicating an extended move beyond the primary concentration of historical trading activity.
*   **5-Day Volume Profile**:
    *   **Point of Control (POC)**: `$33.82`
    *   **Value Area High (VAH)**: `$34.37`
    *   **Value Area Low (VAL)**: `$30.74`
    *   **Analysis**: Similar to the `60`-day profile, the current price is well above the `5`-day Value Area, reinforcing the extended nature of the recent price action.

---

5. Performance Metrics

*   **Sortino Ratio**: `8.40`
    *   **Analysis**: This value indicates a favorable risk-adjusted return for swing trading, as it heavily penalizes downside volatility. However, it **fails** to meet the `20.0` threshold for high-frequency day trading.
*   **Volatility (ATR - 5m)**: `0.10` (Current range expectation)

---

6. Portfolio Classification: 'Sword' vs. 'Shield'

VNO is classified as a **Tactical SWORD** due to its high sensitivity to interest rate movements and its aggressive growth potential tied to the successful lease-up of its major development projects. This classification is contrary to the traditional "Shield" stereotype of REITs, as VNO offers `+5R` potential on cyclical recoveries and is an offensive vehicle to capture institutional rotation in a favorable macro environment.

---

7. Risk Guardrails

*   **Status**: **WAIT (Retain Cash)**
*   **Narrative**: While VNO exhibits a robust bullish macro trend and strong fundamental tailwinds, its current price is extended. The Sortino Ratio for day trading is not met, and the price is trading significantly above established volume profile value areas and institutional imbalances. Deploying capital at current levels carries elevated risk.
*   **Trigger**: A clear retracement into one of the identified Fair Value Gaps (e.g., `$34.28` - `$34.55`, `$35.07` - `$35.38`, or `$35.48` - `$36.68`), coupled with a strong bullish catalyst or a higher Sortino Ratio for day trading, would provide a more favorable entry.
*   **Execution Parameters**: Not applicable (WAIT status).