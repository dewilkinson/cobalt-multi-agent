> **Generated:** Wednesday, May 06, 2026 at 12:02 PM

Active Strategy: Shield Strategy


# 1. Execution Summary


Execution Authorization: **WAIT**


IAG is currently exhibiting high-velocity expansion that has decoupled the asset from its structural "Shield" protection zones. While the institutional trend remains bullish, the asset has entered a "Thin Air" phase, trading significantly above its established volume anchors. 


The primary mathematical hurdle for a Shield allocation—the Sortino Ratio—is currently `$0.05$`, which fails our institutional requirement of `$2.0$`. This indicates that the current price action is driven by high-volatility "Sword" characteristics without the defensive stability required for wealth preservation. We are authorizing a **WAIT** state until the price mean-reverts to the institutional accumulation cluster.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: Bullish Expansion.
*   **Price Discovery State**: Extreme Premium. The current price of `$18.61` is over `$1.80` above the Macro Point of Control (POC).


**Market Structure (SMC Framework)**:
*   **Macro Ceiling**: `$24.87` (Major Bearish Order Block).
*   **Tactical Displacement Pivot**: `$16.73`.
*   **Institutional Floor**: `$15.47` – `$16.27` (Bullish Order Block).
*   **Liquidity Void**: An Imbalance exists between `$16.42` and `$16.73` that likely acts as a magnet for a corrective move.


**Volume Profile Metrics**:
*   **60d Macro POC**: `$16.70`
*   **5d Tactical POC**: `$17.12`
*   **Value Area High (VAH)**: `$16.89` (Macro)
*   **Current Price**: `$18.61`


---


# 4. Mathematical Risk Metrics


*   **Sortino Ratio**: `$0.05` (**FAIL**)
*   **Volatility (ATR)**: `$0.10`
*   **Downside Deviation**: `0.29%`
*   **RVOL**: `1.2` (Institutional baseline met, but price is overextended).


---


# 5. Execution Parameters (Contingent)


If price retraces to the structural "Shield" zone, the following parameters are authorized for a **PROBE** entry:


*   **Strike Zone (Entry)**: `$16.75` - `$17.15`
*   **Hard Stop**: `$15.75`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` shares
*   **Target (Min RR 3:1)**: `$20.15`


---


# 6. Risk Guardrails & Narrative


The "War Barbell" is currently tilted too far toward uncompensated risk. Entering IAG at `$18.61` for a Shield position violates our core philosophy of using low-volatility assets to protect the portfolio from "Sword" crashes. 


**Kill Switch**: A daily close below `$15.30` invalidates the structural floor and requires immediate liquidation.


**Narrative**: We remain patient. The goal of the Shield is safety. Chasing a `9.50%` move into a "Thin Air" zone without a mathematical margin of safety (Sortino) is a retail error. We await the retest of the `$17.12` Tactical POC to deploy capital with a proper risk-to-reward profile.