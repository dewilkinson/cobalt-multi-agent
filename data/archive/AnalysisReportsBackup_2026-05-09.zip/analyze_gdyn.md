> **Generated:** Wednesday, May 06, 2026 at 09:42 AM

Active Strategy: Sniper Strategy

# 1. Execution Summary

**Execution Authorization**: **WAIT (Retain Cash)**

The analysis of **GDYN** results in a definitive **WAIT** status. The asset has failed three critical "Sniper" filters: the **Sortino Ratio** hurdle, the **Morning Scan** volume threshold, and **Institutional Trend** alignment. Specifically, the Sortino Ratio of `0.83` is well below our mandated `2.0` minimum, indicating poor risk-adjusted performance and high downside deviation. Furthermore, the pre-market volume of `64,500` shares did not meet the institutional intent floor of `100,000` shares. 

Structurally, the stock is in a confirmed **Bearish** state following a Change of Character (**CHoCH**) at `$7.4004$`. Price is currently trapped within a Bearish Fair Value Gap (**FVG**) between `$5.7900$` and `$5.8600$`, with no evidence of institutional accumulation or a liquidity sweep to justify an entry.


---


# 2. Institutional News & Social Sentiment

**[DATA_UNAVAILABLE]**


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bearish**
*   **Macro Ceiling (Absolute High)**: `$10.18$`
*   **Tactical DP (Displacement Pivot)**: `$7.4004$` (Bearish CHoCH point)
*   **Relative Strength (RS)**: Failed (Down `-6.27%` while identifying bearish structural shifts)

**SMC CONFLUENCE NODES:**
*   **CHoCH Status**: Confirmed Bearish at `$7.4004$`.
*   **Bearish Order Block (OB)**: `$7.1200$` – `$7.5400$` (Heavy overhead supply).
*   **Fair Value Gaps (FVG)**:
    *   Current Price `$5.83$` is interacting with a Bearish FVG: `$5.7900$` – `$5.8600$`.
    *   Bullish FVG support sits lower at: `$5.3650$` – `$5.4650$`.

**VOLUME PROFILE (60-DAY):**
*   **POC (Point of Control)**: `$5.65$`
*   **VAH (Value Area High)**: `$7.23$`
*   **VAL (Value Area Low)**: `$5.34$`
*   **Analysis**: Price is currently trading just above the 60-day **POC**, but below the 1-day/5-day **VAH** of `$5.93$`. The lack of volume at these levels suggests a "No Man's Land" scenario.


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: **Sortino Ratio**
*   **Current Value**: `0.83`
*   **Required Hurdle**: `2.0`
*   **Status**: **FAIL**
*   **Volatility (ATR 5m)**: `$0.08$`


---


# 5. Execution Parameters

*   **Status**: **WAIT**
*   **Strike Zone (Entry)**: `N/A`
*   **Hard Stop**: `N/A`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `0`


---


# 6. Risk Guardrails & Narrative

**GDYN** is currently showing significant structural weakness. Under the **Sniper Strategy**, we require a **CHoCH** to the upside and a reclaim of the **Tactical DP** or a clear **Liquidity Grab** followed by displacement. Currently, the tape shows price being rejected by the Bearish FVG. 

With an **RVOL** that does not signal institutional accumulation and a **Sortino Ratio** that suggests excessive downside risk for the potential reward, this ticker is disqualified from active trading. No **STRIKE** is authorized. We will monitor for a reclaim of the `$7.4004$` level before re-evaluating for long-side potential.