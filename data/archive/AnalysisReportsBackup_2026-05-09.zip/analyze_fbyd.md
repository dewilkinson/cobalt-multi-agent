> **Generated:** Friday, May 08, 2026 at 10:16 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**WAIT Authorized**


The technical and institutional setup for `FBYD` currently fails the **Sniper Strategy** mathematical hurdles. While the asset is sitting within a tactical bullish Order Block, the macro institutional trend has shifted to **Bearish** following a Change of Character (`CHoCH`) at `9.00`. The most significant headwind is a massive institutional distribution event: a 10% owner recently offloaded `3,950,000` shares at `$13.40`, creating a structural "glass ceiling" that the current low-volume buying pressure cannot penetrate. 


With a **Sortino Ratio** of `1.66`, the asset fails our mandated `2.0` hurdle for risk-adjusted efficiency. The downside deviation of `1.34%` remains too high relative to the decaying price action. We are observing a "Heavy Tape" where every minor bounce is being met with institutional sell orders. No long-side entry is authorized under the current regime.


***


# 2. Institutional News & Social Sentiment


*   **Infinite Acquisitions trims Falcon's Beyond (FBYD) stake with 3.95M-share sale** | *Stock Titan (2026-04-14)* 
    > A 10% owner reported an open-market sale of `3,950,000` Class A shares at `$13.40` each, totaling approximately `$52.83M`.


*   **Falcon's Beyond Global (NASDAQ:FBYD) Shares Gap Down** | *MarketBeat (2026-04-07)*
    > Shares gapped down pre-market and continued to decline, trading around `$11.34`, an `8.0%` intraday loss following earnings reporting `($0.01)` EPS on `$6.59M` revenue.


*   **Major Falcon's Beyond (FBYD) holder trims stake, still owns 31%** | *Stock Titan (2026-04-14)*
    > Infinite Acquisitions Partners LLC and Erudite Cria, Inc. updated their beneficial ownership, maintaining a `31.28%` stake but continuing the trend of reducing exposure.


*   **Falcon's Beyond Global Trading Down 7.1% - Time to Sell?** | *MarketBeat (2026-04-01)*
    > Analyst sentiment remains negative, with multiple "Sell" ratings cited due to strained financial metrics and reduced trading volume.


**Sentiment Synthesis**: The narrative is dominated by **Institutional Liquidation**. The massive insider sale at `$13.40` acts as a primary supply zone. Social sentiment is negligible given the low volume, but institutional flow is clearly exiting.


***


# 3. Technical Structural Audit


**Market Structure & SMC Alignment**

*   **Institutional Trend**: **Bearish** (Confirmed `CHoCH` at `9.00`)
*   **Current Price**: `$11.60`
*   **Daily Change**: `-8.16%`
*   **ATR (5m)**: `0.28`


**Volume Profile & Liquidity Map**

*   **Tactical POC (Point of Control)**: `$13.65` (Price is currently trading in a "Value Void" below this level).
*   **Macro POC**: `$6.53` (The ultimate magnet if the `$9.00` floor fails).
*   **VAH (Value Area High)**: `$13.75`
*   **VAL (Value Area Low)**: `$3.71`


**Institutional Zones (Supply/Demand)**

*   **Bearish FVG (Imbalance)**: `$13.07` - `$13.51` (This area will act as heavy resistance on any retracement).
*   **Bullish Order Block**: `$9.83` - `$12.85` (Current price is residing here, but lack of buy-side volume makes it a high-risk "Sponge" zone rather than a "Trampoline").


***


# 4. Mathematical Hurdle: Sortino


*   **Current Sortino Ratio**: `1.66`
*   **Strategy Hurdle**: `2.0`
*   **Status**: **[FAIL]**


The risk-to-reward profile for a Sniper execution is not present. To reach our `4:1` RR target, we would require a move back toward the high `$14.00`s, which is currently blocked by massive institutional supply and two Bearish Fair Value Gaps.


***


# 5. Execution Parameters


*   **Authorization State**: **WAIT**
*   **Risk Unit (R)**: `$0`
*   **Share Quantity**: `0`
*   **Strike Zone (Entry)**: `N/A`
*   **Hard Stop**: `N/A`
*   **Sniper Target**: `N/A`


***


# 6. Risk Guardrails & Narrative


The "Sword" is currently blunt. We are staying in cash to protect the **Shield** (Portfolio Capital). The primary risk is a "Liquidity Seek" down to the Macro POC at `$6.53` if the current structural support at `$11.00` fails to hold.


**Institutional Tape Reading**: Watch for a high-volume "Sweep" of the `$9.83` level followed by a rapid recovery above `$12.00` to reconsider a Scout entry. Until that displacement occurs, we remain observers. Adhere to the **Daily Stop (3R)** and do not attempt to catch this falling knife while insiders are still selling the ribs.