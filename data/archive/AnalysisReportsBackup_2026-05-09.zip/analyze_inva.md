> **Generated:** Friday, May 08, 2026 at 10:25 AM

Active Strategy: Sniper Strategy


---


# 1. Execution Summary


**WAIT (Execution Unauthorized)**


**Execution Rationale**: While `INVA` exhibits a technically bullish structural alignment following a Daily Break of Structure (BOS) at `$22.76`, the trade fails our primary quantitative hurdle. The **Sortino Ratio** of `0.37` is significantly below the institutional requirement of `2.0`, indicating that the asset's current returns are not efficiently compensating for downside volatility. Furthermore, current volume of `77,034` fails to meet our liquidity floor for a high-conviction **Sniper** entry. We remain in a "Shield" posture, preserving capital until the mathematical efficiency aligns with the technical structure.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish**.
    *   The macro trend is confirmed by a recent Break of Structure (BOS) at `$22.76`. 


*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$22.76`.
    *   **Fair Value Gaps (FVG)**: A bullish imbalance exists between `$23.39` and `$23.55`, which may act as a magnetic draw for a mean-reversion move before further expansion.
    *   **Order Block (OB)**: High-interest institutional demand is anchored between `$19.00` and `$19.62`.


*   **Volume Profile Analysis**:
    *   **POC (Point of Control)**: `$19.90` (60d) and `$23.70` (Session).
    *   **Value Area**: Price is currently trading near the Session **VAL** of `$23.00`, but remains in a "Premium" zone relative to the 60d profile.


---


# 4. Mathematical Hurdles


*   **Sortino Ratio**: `0.37` (**FAIL**).
    *   *Required: $\ge$ `2.0`.*
*   **Intraday Change**: `2.59%` (**PASS**).
    *   *Required: $\ge$ `3.0%` for Value Breakout (Close, but no trigger).*
*   **Liquidity Check**: `77,034` shares (**FAIL**).
    *   *Required: `100,000` minimum for institutional participation.*


---


# 5. Execution Parameters (Conditional)


If the mathematical hurdles are cleared upon a retest of structural support, the following parameters apply for a **Sniper** deployment:


*   **Strike Zone (Entry)**: `$22.80`
*   **Hard Stop**: `$22.10`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `357` shares
*   **Risk Tier**: **SCOUT (0.5R)** (Due to Sortino efficiency failure).


---


# 6. Risk Guardrails


*   **Daily Stop**: `3R` (`$750`).
*   **Kill Switch**: A breach of `$22.10` invalidates the current bullish structure and necessitates an immediate exit.
*   **Strategy Note**: We are currently in a "War Barbell" imbalance. With `INVA` failing efficiency metrics, no "Sword" positions are authorized. We maintain the "Shield" in cash or low-volatility equivalents until a high-fidelity **STRIKE** setup emerges.


**Status**: Monitoring for retracement to `$22.80` and an increase in **RVOL** > `1.2`.