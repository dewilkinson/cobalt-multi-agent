> **Generated:** Monday, May 04, 2026 at 07:01 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Retain Cash)**

The technical audit for **EXPI** confirms a **FAIL** on the Institutional Apex Authorization Matrix. While the asset maintains a healthy **Sortino Ratio** of `2.48`, the price action is currently trapped in a "No Man's Land" between a **1h Bearish Order Block** at `9.58` and a **Bullish Order Block** at `5.69`. 

The prevailing institutional intent is **Bearish** following a **Change of Character (CHoCH)** at the `9.60` level. As Snipers, we do not attempt to "catch the falling knife" in a bearish macro environment. We require a reclaim of the **Tactical Displacement Pivot** or a definitive **Liquidity Sweep** of the discount zone before any deployment of capital. Currently, price is reacting to overhead resistance within a significant **Fair Value Gap (FVG)**.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bearish** (Confirmed by Macro CHoCH at `9.60`)
*   **Dual-Anchor Protocol**:
    *   **Macro Ceiling (Absolute High)**: `$11.02`
    *   **Tactical DP (Displacement Pivot)**: `$9.60` (The origin of the structural break)
*   **Institutional Footprint**:
    *   **Bearish Order Block (OB)**: `$9.58` – `$9.89`
    *   **Bullish Order Block (OB)**: `$5.69` – `$5.91` (The "Shield" floor)
    *   **Overhead Imbalance (FVG)**: `$6.32` – `$6.50` (Acting as a price ceiling)
*   **Volume Profile Metrics**:
    *   **Macro POC**: `$6.10`
    *   **Value Area High (VAH)**: `$9.23`
    *   **Value Area Low (VAL)**: `$5.66`


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `2.48`
*   **Status**: **PASS** (Hurdle `>= 2.0`)
*   **Risk Note**: Despite the bearish price trend, the asset exhibits a low downside deviation of `0.87%`. This indicates that when buyers do step in, the recovery is mathematically efficient. It remains on the "Sword" watchlist for a high-R reversal.


---


# 5. Tactical Execution Parameters

*Current recommendation is **WAIT**. These parameters activate only upon a 5-minute candle close above the **$6.51** trigger level.*

*   **Strike Zone (Entry)**: `$6.52` – `$6.55`
*   **Hard Stop**: `$6.32` (Placed below the imbalance midpoint)
*   **Risk Unit (R)**: `$250`
*   **Target 1 (1R)**: `$6.72` (Initiate Trailing Anchor)
*   **Target 2 (3R)**: `$7.12`
*   **Share Quantity**: `1,250 Shares`
    *   *Formula: $250 / ($6.52 - $6.32)*


---


# 6. Risk Guardrails & Kill Switch

*   **Kill Switch**: A break below the **Macro VAL** of `$5.66` immediately invalidates the long thesis and removes **EXPI** from the active "Sniper" scan.
*   **RVOL Requirement**: Do not execute a **STRIKE** (1.0R) unless **RVOL** exceeds `2.0` at the time of the trigger. If **RVOL** is between `1.2` and `1.8`, use a **SCOUT** (0.5R) entry.
*   **Momo Exit**: If the trade is "Free" (Stop at Break-Even), trail the final `25%` of the position using the **5-min 9 EMA**. Exit on the first 5-minute close below the EMA.