> **Generated:** Thursday, May 07, 2026 at 11:11 AM

Active Strategy: Sniper Strategy

# XNDU: Institutional Audit & Tactical Strategy

---

## 1. Execution Summary

**WAIT**

**Execution Authorization**: Denied. Despite a massive intraday surge of `36.19%` and an exceptional **Day Trading Sortino Ratio** of `4.08`, the **Apex Authorization Matrix** has returned a **FAIL** status. The current 5M **Liquidity Sweep** occurred at `$14.3850` (Bearish), which conflicts with the prevailing Neutral Macro (1D) trend and the aggressive retail-driven price action currently at `$18.93`.

The **Sniper Strategy** mandates a high-precision `4:1` Reward-to-Risk (RR) ratio. Currently, the price is suspended between a deep liquidity grab at `$14.3850` and overhead Fair Value Gaps (FVG) starting at `$26.94`. Entering at current levels without a confirmed 5M structural shift (MSS) above `$19.50` exposes the portfolio to unnecessary "falling knife" volatility. We will remain in a **WAIT** posture until the market provides a high-fidelity entry trigger that aligns with our structural scopes.

---

## 2. Institutional News & Social Sentiment

*   **XNDU Stock Crashed 68%, But It's Not A New Offering** (Stocktwits, 3h ago): Reports indicate the recent massive sell-off was a reaction to a prospectus filing to register existing shares, not a new dilutive offering.
*   **Retail Traders Call It An Overreaction** (Stocktwits, 2h ago): Social sentiment is heavily skewed toward a "dead cat bounce" or recovery play as retail participants digest the SEC filing.
*   **Middle East Tensions Escalate Again: XNDU In Focus** (Market News, 4h ago): Macro-geopolitical tensions are increasing volatility across speculative tech and quantum sectors.
*   **Sector Rotation Observations** (Twitter/X, 1h ago): Analysts note healthy sector rotation, though XNDU remains technically overbought on the micro-timeframe following its recovery from the lows.

**Social Sentiment**: **HIGHLY VOLATILE / BULLISH BIAS**. Reddit and Stocktwits are currently characterized by "buying the dip" behavior, which often precedes a secondary liquidity sweep of retail stops.

---

## 3. Tactical SMC Mapping (Sniper Scopes)

*   **Institutional Footprint**: `9,829,713` shares traded. This represents extreme **RVOL**, confirming institutional participation and significant re-pricing.
*   **Liquidity Voids (FVG)**: 
    *   **Bullish Target**: `$26.94` — `$27.68`. This is the primary magnet for a long-side expansion.
    *   **Bearish Resistance**: `$29.00` — `$29.50`.
*   **Liquidity Sweep**: A significant bearish sweep was identified at `$14.3850`, suggesting that "Smart Money" has already cleared out the immediate downside liquidity before the current move.
*   **Hurdle Rate**: The Sortino Ratio of `4.08` confirms that the current move, while volatile, has had a strong risk-adjusted upward drift today.

---

## 4. Execution Parameters (Contingent)

If structural alignment occurs (Market Structure Shift above `$19.50`), the following parameters apply:

*   **Risk Tier**: **SCOUT** (`0.5R`) due to VIX/Volatility context.
*   **Risk Unit (R)**: `$125` (Half-size for Scout).
*   **Strike Zone (Entry)**: `$19.50` (On 5M confirmation).
*   **Hard Stop**: `$17.50` (Calculated based on 1R volatility buffer).
*   **Share Quantity**: `62` shares.
*   **Target (4:1 RR)**: `$27.50` (Targeting the lower boundary of the 1H FVG).

---

## 5. Performance Metrics & Risk Check

*   **Account Size**: `$100,000`
*   **Daily Stop**: `$750` (`3R`)
*   **Max Single Trade Risk**: `0.25%` (Scout) to `1.0%` (Strike).
*   **Status**: Monitoring for 5M stability. **Do not market buy.** Adhere to Sniper precision; we require the market to come to our level.