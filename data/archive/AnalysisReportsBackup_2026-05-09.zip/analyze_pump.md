> **Generated:** Thursday, May 07, 2026 at 10:39 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**SCOUT Authorized**


**Execution Rationale**: $PUMP has confirmed a structural **CHoCH** (Change of Character) at `$11.65`, signaling a definitive macro bullish shift. The current `-2.82%` price action is a tactical "sell-the-news" pullback following the pricing of an upsized `$600M` convertible note offering and a Q1 EPS beat. With a **Sortino Ratio** of `2.07`, the asset clears our institutional risk hurdle. We are authorizing a **SCOUT** (0.5R) entry to capitalize on the "Discount" zone near the immediate Fair Value Gap (FVG) at `$15.11`, anticipating a reversal as institutional accumulation absorbs the temporary dilution narrative.


***


# 2. Institutional News & Social Sentiment


*   **ProPetro Prices Upsized $600 Million Convertible Senior Notes Offering** (Business Wire, 2h ago) – Institutional capital expansion signaling a long-term pivot to PROPWR.
*   **ProPetro Q1 2026 beats EPS forecast, stock dips** (Investing.com, 4h ago) – Classic post-earnings volatility despite fundamental strength.
*   **ProPetro (PUMP) Secures Major Power Agreement with Caterpillar** (GuruFocus, 1d ago) – Massive strategic framework for up to `2.1 GW` of power generation.
*   **Citigroup upgrades ProPetro Holding to Buy** (MSN, 3d ago) – Improving Permian completion market outlook cited by analysts.


**Social Sentiment**: Reddit and Twitter sentiment remains cautiously optimistic, viewing the recent 52-week high of `$18.50` as a precursor to a larger breakout once the notes offering is fully digested by the market.


***


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish (Macro)** / **Neutral-Pullback (Tactical)**


*   **Market Structure (Dual-Anchor Protocol)**:
    *   **Macro Ceiling (52-Week High)**: `$18.50`
    *   **Tactical Displacement Pivot**: `$15.11` (Immediate Bullish FVG)
    *   **BOS/CHoCH Level**: `$11.65` (Trend Reversal Floor)


*   **Volumetric Footprint**:
    *   **5-Day POC (Point of Control)**: `$16.68` (Price is currently below value, signaling a "Discount" state).
    *   **5-Day VAL (Value Area Low)**: `$14.58` (Primary Liquidity Defense).
    *   **Bullish Order Block**: `$12.92` - `$13.88` (Deep secondary support).


***


# 4. Performance Metrics


*   **Current Price**: `$15.36`
*   **Intraday Change**: `-2.82%`
*   **Sortino Ratio**: `2.07` (**PASS**)
*   **Morning Volume**: `875,942` shares (Institutional Participation High)
*   **5m ATR**: `$0.14`


***


# 5. Execution Parameters


*   **Execution Tier**: **SCOUT (0.5R)**
*   **Risk Unit (R)**: `$125`
*   **Strike Zone (Entry)**: `$15.15` - `$15.30`
*   **Hard Stop**: `$14.58`
*   **Share Quantity**: `173` shares


***


# 6. Risk Guardrails


*   **Kill Switch**: A close below `$14.40` invalidates the current momentum thesis and suggests a deeper retracement into the macro order block.
*   **Tactical Note**: $PUMP is transitioning into a power-generation entity. While the convertible notes create short-term overhead supply, the underlying framework with Caterpillar provides a significant "Shield" for the portfolio. Adhere to the `173` share limit to maintain the 0.5R risk profile during this news-driven volatility.