> **Generated:** Friday, May 08, 2026 at 10:18 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**Execution Authorization: STRIKE Authorized**


GHRS has completed a clean institutional displacement, confirming a Macro **CHoCH** (Change of Character) at `$16.48`. The price action is currently in a high-conviction "Sniper" setup following a Bullish Liquidity Sweep at `$21.11`. Despite a minor intraday pullback of `-0.33%`, the stock is maintaining structural integrity above the Tactical **VAL** of `$18.52`.


The synthesis of the **Sortino Ratio (4.28)** and the **SMC Alignment Scan** suggests that institutional "Smart Money" is actively defending the current range. The expansion from the Macro **POC** of `$15.46` toward the session **POC** of `$21.59` validates a "Sword" momentum profile. We are authorizing a full **STRIKE** (1R) deployment targeting the Macro cycle high of `$24.66`.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


`[DATA_UNAVAILABLE]`


---


# 3. STRUCTURAL AUDIT & SMC MAPPING


*   **Institutional Bias**: **Strongly Bullish** (Macro trend flip confirmed at `$16.48`).


*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$16.48` (The "Line in the Sand" for the bull case).
    *   **Macro Cycle Ceiling**: `$24.66` (Primary liquidity target for take-profit).
    *   **Order Block (Bullish)**: `$12.77` — `$13.52` (Deep discount accumulation zone).
    *   **Fair Value Gap (FVG)**: `$20.76` — `$21.00` (Immediate support magnet).


*   **Volume Profile Confluence**:
    *   **Macro POC**: `$15.46` (Base of the current expansion).
    *   **Tactical POC**: `$21.59` (Current point of high-volume commitment).
    *   **Session VAH**: `$22.20` (Immediate overhead supply resistance).


---


# 4. MATHEMATICAL HURDLE (SORTINO)


*   **Metric**: **Day Trading Sortino Ratio**
*   **Value**: `4.28`
*   **Institutional Threshold**: `2.0`
*   **Status**: **PASS**


**Analytical Insight**: The Sortino value of `4.28` indicates exceptional risk-adjusted performance. The downside deviation of `0.79%` is remarkably low compared to the upside volatility, signifying a "clean" price delivery characteristic of institutional accumulation.


---


# 5. EXECUTION PARAMETERS (SNIPER)


*   **Trade State**: **STRIKE**
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$20.94`
*   **Hard Stop**: `$19.94` (Placed below the `$20.15` Session Volume Node)
*   **Share Quantity**: `250` shares
*   **Profit Target (4:1 RR)**: `$24.94` (Aligns with Macro cycle high liquidity)


---


# 6. RISK GUARDRAILS


*   **The Sword Narrative**: This is a high-momentum "Sword" position. While it offers significant growth potential, it requires strict adherence to the **Hard Stop** at `$19.94`.


*   **Kill Switch**: A daily close below the Tactical **VAL** of `$18.52` invalidates the momentum thesis. If triggered, exit all remaining exposure immediately.


*   **Psychological Reset**: Per the **CMA Risk Protocol**, if this trade results in a loss alongside two others, revert to **0.5R SCOUT** sizing for the next session.


**Status**: **Active Monitoring Enabled**. Adhere to the `$19.94` stop-loss to protect the `$100k` principal.