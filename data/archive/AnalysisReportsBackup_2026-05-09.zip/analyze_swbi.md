> **Generated:** Thursday, May 07, 2026 at 10:52 AM

Active Strategy: Sniper Strategy

---

# 1. Execution Summary

**WAIT (Retain Cash)**


The mathematical foundation for a **Sniper Strategy** execution on `SWBI` has not been met. While the macro structural trend remains bullish with a confirmed CHoCH at `$10.33`, the tactical environment is currently unfavorable for high-conviction deployment. The primary blocker is the **Sortino Ratio**, which currently sits at `0.45`, significantly below our institutional requirement of `S >= 2.0`. 


Price is currently reacting to a bearish Fair Value Gap (FVG) between `$14.55` and `$14.61`, acting as immediate overhead supply. Furthermore, the stock is trading below the session Point of Control (POC) of `$14.87`. We will remain on the sidelines until we observe a liquidity sweep of the Session Value Area Low (VAL) at `$14.43`, followed by a volatility-backed reversal that restores our risk-adjusted return metrics.


---


# 2. Institutional News & Social Sentiment


*   **Smith & Wesson awards shares, withholds stock for taxes** (Stock Titan | 2h ago): Neutral report regarding internal equity awards for VP Kyle Tengwall and Deana McPherson; standard insider activity.
*   **Smith & Wesson Brands unveils Model 73 C-Frame revolver** (Traders Union | 4h ago): Bullish product catalyst; public debut of a new revolver line expanding the core firearm portfolio.
*   **Smith & Wesson Releases Bodyguard 38 2.0 Revolver** (Firearms News | 6h ago): Highly bullish technical update to a popular small-frame firearm, designed for personal protection.
*   **Smith & Wesson Brands launches rebate program** (Traders Union | 8h ago): Bullish incentive program targeting law enforcement and military personnel to drive volume.
*   **S&W Posts Strong Q3 Sales Gains** (International Business Times | 12h ago): Confirmation of financial recovery and strong institutional sales growth.


**Sentiment Synthesis**: Social sentiment is leaning "Somewhat-Bullish" due to a flurry of new product releases and strong quarterly sales performance. However, the market "tape" shows distribution, with price currently down `-1.61%`, suggesting that these catalysts are already priced in or being sold into by institutional laggards.


---


# 3. Structural Audit & Tape Reading


**MTF SMC ALIGNMENT**
*   **Institutional Trend**: Bullish (Macro CHoCH at `$10.33`).
*   **Order Block (Strike Zone)**: `$13.94` — `$14.80` (Primary Bullish Interest).
*   **Fair Value Gaps (Supply)**: Bearish FVG identified at `$14.55` — `$14.61`.
*   **Liquidity Draw**: Session VAL at `$14.43`.


**VOLUME PROFILE METRICS**
*   **Current Price**: `$14.59`
*   **60d POC**: `$10.72` (Major Value Anchor).
*   **5d POC**: `$14.87` (Overhead Magnet).
*   **RVOL**: `1.2` (Threshold met for institutional interest).


---


# 4. Mathematical Hurdle (Sortino)


*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `0.45`
*   **Hurdle**: `2.0`
*   **Status**: **FAIL**
*   **Analysis**: The current downside deviation of `0.49%` makes the risk-to-reward ratio inefficient for a Sniper entry. We require a consolidation period to lower volatility or a sharp reversal to increase the Sortino back to acceptable institutional levels.


---


# 5. Execution Parameters


**STRATEGY: SNIPER (4:1 RR TARGET)**

*   **Execution Authorization**: **WAIT**
*   **Strike Zone (Entry)**: `$14.45` (Trigger: Reclaim of Session VAL after liquidity sweep).
*   **Hard Stop**: `$13.90` (Placed below the Bullish Order Block).
*   **Primary Target**: `$16.65` (Targeting a `4:1` RR move).
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `454` Shares.
*   **ATR (5m)**: `0.07`


---


# 6. Risk Guardrails


*   **Daily Stop**: `3R` (`$750`).
*   **Psych Reset**: After `3` consecutive losses, all trades revert to `0.5R` Scouts.
*   **Kill Switch**: If price breaches the Macro Order Block at `$13.80`, the bullish thesis is invalidated.
*   **Narrative Note**: SWBI is currently a "Sword" candidate that is dull. We are waiting for the price to sharpen against the `$14.43` support level. Do not chase the current retracement; wait for the math to align with the structure.