> **Generated:** Friday, May 08, 2026 at 10:44 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY

**STRIKE Authorized**


Westrock Coffee (`WEST`) is exhibiting a textbook "Sword" breakout profile, characterized by massive institutional displacement and a decisive Break of Structure (**BOS**) at `$5.22`. The asset has cleared all historical high-volume nodes and is currently in a price discovery phase. With an intraday surge of `20.67%` and a Day Trading Sortino Ratio of `9.27`, the mathematical hurdle for a high-conviction **SNIPER** entry is easily cleared.


The rationale for deployment is based on the migration of the Volume Point of Control (**POC**) from `$4.13` to `$5.90`, confirming that previous resistance has transitioned into a structural floor. Current price action at `$8.02` is targeting external buy-side liquidity at `$8.61`. While in a "premium" zone, the orderly nature of the move—evidenced by a low downside deviation of `0.47%`—supports a momentum-based strike with tight risk guardrails.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

`[DATA_UNAVAILABLE]`


---


# 3. STRUCTURAL AUDIT & TAPE READING

**Bias / Trend**: Bullish MTF Alignment


*   **Institutional Break of Structure (BOS)**: Confirmed at `$5.2250`.
*   **Macro POC**: `$4.13` (Anchor for long-term value).
*   **Tactical POC**: `$5.90` (Immediate floor for the current markup phase).
*   **Bullish Order Blocks (OB)**:
    *   `$5.24` – `$5.55` (Primary institutional support).
    *   `$3.77` – `$3.92` (Deep discount zone).
*   **Fair Value Gaps (FVG)**:
    *   `$5.82` – `$5.90` (Critical magnet if momentum fails).
    *   `$5.70` – `$5.75`.
*   **Liquidity Targets**: External buy-side liquidity pool identified at `$8.61`.


---


# 4. QUANTITATIVE HURDLES

*   **Morning Scan Volume**: `2,489,211` (Heavy institutional participation).
*   **Intraday Momentum**: `20.67%` (Value breakout profile).
*   **Day Trading Sortino Ratio**: `9.27` (Target hurdle: `2.0`).
*   **Volatility (ATR 5m)**: `$0.20`.


---


# 5. EXECUTION PARAMETERS (SNIPER)

*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$8.02`
*   **Hard Stop**: `$7.80`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `1,136` shares
*   **Target (4:1 RR)**: `$8.90` (Anticipating extension past the `$8.61` liquidity level).


---


# 6. RISK GUARDRAILS

*   **Daily Stop**: Standard `3R` limit applies.
*   **Kill Switch**: Immediate MOC (Market on Close) exit if price breaches the session Value Area Low (**VAL**) at `$7.91` or the hard stop at `$7.80`.
*   **Psych Reset**: If the `$7.80` stop is triggered, revert to **SCOUT** (`0.5R`) for the remainder of the session.
*   **Tactical Note**: We are trading a "Sword" position. This is a high-velocity day trade. If the `$8.61` level is not breached with volume by `3:30 PM ET`, consider trimming `50%` of the position to lock in gains and mitigate overnight gap risk.