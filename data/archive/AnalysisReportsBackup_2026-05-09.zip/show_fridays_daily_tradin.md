> **Generated:** Saturday, May 02, 2026 at 02:17 PM

### FRIDAY DAILY TRADING POST-MORTEM: MAY 01, 2026


The trading session on Friday, May 01, 2026, was characterized by high-velocity turnover within "Sword" assets, specifically targeting Navitas Semiconductor (`NVTS`) and Riot Platforms (`RIOT`). While momentum identification remained sharp, the day's performance was significantly degraded by execution "drift"—specifically the tendency to chase price action beyond authorized **STRIKE** zones in Intel (`INTC`) and American International Group (`AIG`). 


The portfolio currently exhibits "Size-Induced Anxiety." In `NVTS`, the accumulation reached `1,050` shares, effectively quadrupling the recommended risk unit. This over-leveraging led to a premature exit, sacrificing a significant move toward the institutional target of `$18.95` in favor of capital preservation. To maintain institutional-grade fidelity, execution must return to the mathematical constraints of the **Sortino Sniper** strategy: stop buying wicks and respect the `-1%` variance rule from structural order blocks.


---


### I. CORE EXECUTION METRICS


*   **Account Identity**: Dave Wilkinson | Blueshell Securities LLC


*   **Total Executions**: `38` Filled Orders


*   **Primary Vectors**: Semiconductor (`NVTS`, `INTC`, `NXT`), Crypto-Proxy (`RIOT`, `ETH`), and Speculative Tech (`QUBT`, `LWLG`)


*   **Capital Allocation**: Heavy concentration in high-beta "Sword" assets; "Shield" (Low Vol) allocation remained neglected.


*   **Daily Sortino Impact**: Negative variance driven by top-ticking `INTC` at `$100.20`.


---


### II. SMC AUDIT & EFFICIENCY MAPPING


**NVTS (Navitas Semiconductor)**
*   **Audit Grade**: `B-`
*   **Structural Context**: High-volume accumulation between `$17.38` and `$17.87`.
*   **Efficiency Gap**: Your early fills at `$17.38` were high-fidelity, but the subsequent "chase" up to `$17.87` skewed the average cost basis. 
*   **Outcome**: Exited `1,050` shares at `$17.79`. While technically profitable on the core, the exit was premature relative to the **Target 1** of `$18.95`. Sizing at `4x` the recommended risk unit forced an emotional rather than technical exit.


**INTC (Intel)**
*   **Audit Grade**: `D` (FAIL)
*   **Structural Context**: Entered at `$100.20` and `$99.95`, representing the literal cycle peak/Macro Ceiling.
*   **Efficiency Gap**: The system-authorized **STRIKE** zone was `$98.80` – `$99.60`. By entering at `$100.20`, you engaged in a "Retail Trap" entry.
*   **Outcome**: Panic-sold at `$98.05` for a loss. You exited at the exact structural level where institutional buyers were looking for re-entry.


**RIOT (Riot Platforms)**
*   **Audit Grade**: `A-`
*   **Structural Context**: Scalp entry at `$19.47`.
*   **Efficiency Gap**: Exited `500` shares at `$19.40` into the identified Macro Ceiling of `$19.49`.
*   **Outcome**: High efficiency. This move demonstrated proper liquidity capture, selling directly into institutional supply.


**AIG (American International Group)**
*   **Audit Grade**: `C`
*   **Structural Context**: System issued a **WAIT** command due to sub-`2.0` Sortino.
*   **Efficiency Gap**: Ignored the "DO NOT CHASE" warning, buying at `$79.02` in "Thin Air" (above structural support).
*   **Outcome**: Realized churn loss of `-$0.48` per share. 


---


### III. EXECUTION PARAMETERS (SYSTEM MANDATES)


The following parameters were the authorized constraints for the session. Deviations from these levels directly correlated with the day's drawdown.


*   **NVTS Strike Zone**: `$17.20` – `$17.45`
*   **NVTS Risk Unit**: `294` Shares
*   **NVTS Hard Stop**: `$16.85`
*   **NVTS Target 1**: `$18.95`


*   **INTC Strike Zone**: `$98.80` – `$99.60`
*   **INTC Hard Stop**: `$97.70`
*   **INTC Macro Ceiling**: `$100.15`


*   **RIOT Strike Zone**: `$18.80` – `$19.10`
*   **RIOT Macro Ceiling**: `$19.49`


---


### IV. STRATEGIC PIVOTS & RECOVERY


1.  **Sizing Normalization**: The `1,050` share position in `NVTS` represents a breach of risk protocols. Future "Sword" executions must be capped at the calculated `Risk Unit` to prevent "Size-Induced" early exits.


2.  **The 1% Variance Rule**: If the ticker price exceeds the authorized **STRIKE** zone by more than `1.00%`, the trade is considered "Gone." Chasing the wick at `$100.20` on `INTC` is a mathematically terminal behavior for a long-term Sortino profile.


3.  **Order Block Discipline**: Prioritize entries within the documented Order Blocks (e.g., `INTC` `$94.99` – `$97.72`). Friday’s losses were entirely concentrated in entries that occurred in "Thin Air" above these blocks.


4.  **Status**: **Active**. Portfolio remains heavy on momentum. Immediate shift toward "Shield" assets is recommended to offset "Sword" volatility.


---
**Report Integrity**: Factual | Quantitative | Root Institutional Access.
*System Date: Sat May 02 2026*