> **Generated:** Friday, May 08, 2026 at 01:36 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


QURE has executed a definitive high-conviction breakout, triggering a structural Change of Character (`CHoCH`) at the `$28.48` level. This move is a "Sword" play, fueled by a clinical catalyst regarding AMT-130 and a massive institutional re-rating. 


The current price of `$29.07` represents a `20.42%` intraday expansion. Despite this verticality, the Day Trading Sortino Ratio of `4.81` confirms that the upside volatility is orderly and supported by heavy volume (`3.5M` shares), satisfying the Sniper strategy's requirement for high-fidelity risk-adjusted entries. We are authorizing a full `1R` deployment as the price is currently holding the displacement pivot.


***


# 2. Institutional News & Social Sentiment


*   **RBC Capital Maintains Buy Rating** | Target: `$35.00` | (2h ago)
    Analyst reiterates positive outlook based on clinical pipeline and regulatory tailwinds.


*   **H.C. Wainwright Reiterates Buy** | Target: `$50.00` | (4h ago)
    Firm maintains aggressive long-term valuation despite cutting the target from previous highs.


*   **Stifel Maintains Buy Rating** | Target: `$28.00` | (6h ago)
    Note: Price has already breached this target, suggesting a rapid institutional catch-up trade is underway.


*   **uniQure Reports Q1 2026 Results** | (1d ago)
    Reported a wider loss of `$53.5M` but highlighted a massive cash runway of `$586.6M` extending into 2029.


*   **AMT-130 Regulatory Progress** | (1d ago)
    Clinical momentum in the Huntington’s disease program is the primary fundamental driver for today's price action.


***


# 3. Structural Audit & Sniper Metrics


*   **Institutional Trend**: Bullish (`CHoCH` confirmed at `$28.48`).


*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$28.48`.
    *   **Liquidity Pool**: Target `$35.00` (Psychological level and Analyst Target).
    *   **Value Gap (FVG)**: Large Bullish FVG identified between `$21.27` and `$22.59`, though current momentum suggests this may remain unfilled in the short term.


*   **Volatility (ATR)**: `0.78` (5m timeframe).


*   **Sortino Ratio**: `4.81` (Elite efficiency).


***


# 4. Execution Parameters


*   **Execution State**: **STRIKE**


*   **Strike Zone (Entry)**: `$28.60` – `$29.10`


*   **Share Quantity**: `192` shares


*   **Risk Unit (R)**: `$250` (`1R`)


*   **Hard Stop**: `$27.80`


*   **Target (Sniper 4:1 RR)**: `$34.30`


***


# 5. Risk Guardrails


*   **Sword Logic**: As a high-growth "Sword" position, QURE is prone to rapid mean reversion if the `$28.48` level fails. The Kill Switch is set strictly at `$27.80`.


*   **Institutional Footprint**: The high `RVOL` and the fact that price is holding above the morning gap-up base indicates that "Smart Money" is defending this new price tier.


*   **MOC Exit**: If the price fails to close above `$28.50`, or if the VIX spikes above `25`, we will look to trim the position at `3:55 PM` ET to preserve capital.


**Analyst Note**: Dave, the risk-to-reward here is mathematically superior due to the low downside deviation (`0.82%`). This is a textbook Sniper entry on a clinical breakout. Maintain discipline on the stop loss.