> **Generated:** Friday, May 08, 2026 at 11:34 AM

Active Strategy: Shield Strategy


# 1. Execution Summary

**WAIT Authorized**

HBM is currently exhibiting the characteristics of a high-integrity **Shield** asset, providing structural defense through its exposure to hard commodities. While the macro institutional trend is confirmed bullish following a significant Break of Structure (`BOS`) at `$17.73`, the tactical tape suggests a period of necessary absorption. The asset is currently compressed within a bearish Fair Value Gap (`FVG`) between `$24.77` and `$25.13`, acting as a temporary ceiling for price action.

The authorization to move from a neutral stance to an active position is currently withheld due to a **Sortino Ratio** of `1.24`, which remains below our institutional requirement of `2.0`. This indicates that the current reward-to-downside-volatility profile does not yet justify a full capital deployment. We are monitoring for a definitive "Shield" reinforcement—specifically a daily close above the supply zone—to validate the next leg of institutional accumulation.


---


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


---


# 3. Execution Parameters

*   **Execution State**: **WAIT** (Monitoring for Trigger)
*   **Strike Zone (Entry)**: `$24.85` - `$25.00`
*   **Hard Stop**: `$23.85`
*   **Risk Unit**: `0.5R` (Scout Configuration)
*   **Share Quantity**: `217` Shares


---


# 4. Structural Audit & Tape Reading

**Institutional Bias**: Bullish

*   **Macro Map**: Institutional accumulation is validated by the macro trend. The primary "Shield" floor is established at the `$17.73` pivot.
*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$23.90` (Session Point of Control).
    *   **Macro Ceiling**: `$28.74` (Cycle Resistance).
*   **Institutional Footprint**:
    *   **Supply Zone (Imbalance)**: The price is currently battling a bearish `FVG` from `$24.77` to `$25.13`. 
    *   **Demand Zone (Order Block)**: Significant institutional buying interest is identified between `$22.93` and `$23.75`.


---


# 5. Volatility & Performance Metrics

*   **Current Price**: `$24.82`
*   **Intraday Change**: `3.94%`
*   **Sortino Ratio**: `1.24` (**FAIL**)
*   **ATR (5m)**: `$0.10`
*   **RVOL**: `1.2` (Threshold for breakout validation)


---


# 6. Volume Profile Analysis (Shield Integrity)

*   **Session POC**: `$23.90`
*   **Macro POC**: `$24.29`
*   **Value Area High (VAH)**: `$25.40`
*   **Value Area Low (VAL)**: `$22.80`

**Narrative**: The "Shield" is currently holding firm above the Macro Point of Control (`POC`) of `$24.29`. This level represents the "fair value" where institutions have most heavily transacted. As long as price remains above this anchor, the structural integrity of the long-term trend remains intact. We anticipate a period of "Grinder" style price action as the asset attempts to churn through the overhead supply in the `$25.00` region.


---


# 7. Risk Guardrails

*   **Kill Switch**: A violation of `$23.75` invalidates the tactical order block and requires an immediate exit of any scout positions to preserve capital.
*   **Scaling Logic**: Only authorize a scale-in to a full `1R` (Strike) if the **Sortino Ratio** prints above `2.0` and the asset secures a candle close above `$25.15`.
*   **Shield Maintenance**: Current volatility (`ATR` of `$0.10`) suggests tight intraday ranges. Avoid chasing extensions above the `VAH` of `$25.40` until new institutional volume enters the tape.