> **Generated:** Thursday, May 07, 2026 at 10:36 AM

Active Strategy: Sniper Strategy


# [TACTICAL REPORT] PRSU — Institutional Precision Entry


### 1. Execution Summary

**SCOUT Authorized**

PRSU has triggered a high-conviction structural shift (**CHoCH** at `$38.33`) following a significant earnings beat and record-breaking Q1 2026 results. The asset currently functions as a primary **Sword** in our barbell strategy, exhibiting aggressive displacement and institutional accumulation. While the **Sortino Ratio** of `5.86` confirms elite risk-adjusted performance, the current **RVOL** is tracking at `0.6`, which sits below our `1.2` hurdle for a full **STRIKE** deployment. 

Therefore, we are authorizing a **SCOUT** (0.5R) position to capture immediate momentum from the morning liquidity sweep at `$42.51`. This entry is designed to front-run a potential volume expansion toward the macro target of `$45.47`. We will scale to a full `1.0R` unit if daily volume exceeds `450,000` shares with sustained price acceptance above `$44.00`.


---


### 2. Institutional News & Social Sentiment

*   **Earnings Call Transcript: Pursuit Attractions Reports Record Q1 2026 Results** (Investing.com | 2h ago) 
    *   *Key Insight*: Revenue surged `37%` year-over-year to `$51.6M` CAD. Strategic divestiture of non-core assets has streamlined the balance sheet for growth.
*   **Pursuit Reports Record First Quarter 2026 Results** (Business Wire | 3h ago)
    *   *Key Insight*: Strong margin improvement and reaffirmed full-year guidance support a fundamental valuation rerating.
*   **Comerica Bank Increases Stake in PRSU by 136.4%** (MarketBeat | 4h ago)
    *   *Key Insight*: Institutional "Smart Money" accumulation confirmed; Comerica added `42,699` shares, bringing total holdings to `73,994`.
*   **Sentiment Synthesis**: 
    *   **Institutional**: Strongly Bullish. The move to a 52-week high is backed by fundamental growth rather than pure speculation. 
    *   **Social (Reddit/Twitter)**: Increasing mentions of "Experiential Travel" recovery. Sentiment is tilting toward "Value Breakout" status.


---


### 3. Structural & Quantitative Metrics


**MTF SMC Alignment**
*   **Institutional Trend**: Bullish (CHoCH at `$38.33`)
*   **Market Structure**: Break of Structure (BOS) confirmed on the 1h timeframe.
*   **Liquidity State**: Bullish Liquidity Sweep confirmed at `$42.51`.


**Volume Profile Analysis (60-Day & 5-Day)**
*   **Macro POC (60d)**: `$35.40`
*   **Tactical POC (5d)**: `$41.08`
*   **Value Area High (VAH)**: `$41.84`
*   **Current State**: Price is trading in "Price Discovery" mode above the established Value Area.


**Performance Hurdle**
*   **Sortino Ratio ($S_{DR}$)**: `5.86` (**PASS**)
*   **ATR (5m)**: `0.36`
*   **RVOL**: `0.6` (Below `1.2` Strike Trigger)


---


### 4. Execution Parameters

*   **Execution Level**: **SCOUT** (0.5R)
*   **Risk Unit (R)**: `$125`
*   **Strike Zone (Entry)**: `$43.83`
*   **Hard Stop**: `$42.40`
*   **Share Quantity**: `88` Shares
*   **Primary Target (4:1 RR)**: `$49.55`


---


### 5. Risk Guardrails

*   **Stop Management**: The **Hard Stop** at `$42.40` is placed strictly below the 1h Bullish Order Block (`$39.84 - $42.41`) and the recent 5m liquidity sweep low. 
*   **Kill Switch**: If price closes below the 5-day POC of `$41.08`, the institutional "Sword" thesis is invalidated. Immediate exit required.
*   **Scale-In Trigger**: Transition to **STRIKE** (add 0.5R) only if the first unit reaches break-even and RVOL climbs above `1.2`.
*   **MOC Exit**: If VIX climbs above `25` and PRSU fails to hold `$43.00` by 3:55 PM ET, close position to preserve capital for the next session.


---


**Status: Authorization Confirmed.**
*System Time: Wed May 06 2026 10:35:33*