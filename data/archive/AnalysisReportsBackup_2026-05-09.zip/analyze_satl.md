> **Generated:** Friday, May 08, 2026 at 10:53 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Retain Cash)**


The technical structure for `$SATL` has transitioned to a bullish state following a Macro CHoCH at `$4.3050`, but the asset fails the mathematical hurdles required for a **Sniper** strike. The current **Sortino Ratio** of `0.38` is significantly below our institutional mandate of `2.0`, indicating that recent volatility is not providing sufficient risk-adjusted returns.


Price is currently trading in a "Momentum Void" between the session Value Area High (`$7.60`) and the macro Value Area High (`$6.71`). While the U.S. Naval contract provides a strong fundamental tailwind, the announcement of a `$50M` At-The-Market (ATM) equity offering creates a significant institutional supply overhang. We are observing a distribution phase where "Smart Money" is likely utilizing retail liquidity to fulfill the ATM offering. We will wait for a mean reversion to the Volume Point of Control (POC) before evaluating a Scout entry.


---


# 2. Institutional News & Social Sentiment

*   **U.S. Naval Research Contract (1mo ago)**: $SATL surged significantly following an expanded agreement with the U.S. Office of Naval Research for the Slingshot program, focusing on real-time in-orbit processing. [Source: Sahm]
*   **$50M ATM Equity Offering (2h ago)**: The company initiated an at-the-market share offering to sell up to `$50M` of Class A Common Stock, raising immediate dilution concerns. [Source: Stock Titan]
*   **Significant Insider Buying (1mo ago)**: CFO Rick Dunn increased his stake by `19%`, acquiring approximately `$197,000` worth of stock in open-market purchases. [Source: Sahm]
*   **Institutional Divestment (1mo ago)**: Cantor Fitzgerald & Co. reported a full divestment of its ownership position, moving to zero beneficial ownership. [Source: Stock Titan]
*   **Social Sentiment**: Sentiment on Reddit and Twitter remains highly polarized; retail traders are focused on the "Space Race" momentum, while institutional commentary focuses on the dilution risks posed by the ATM facility.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bullish** (Confirmed by 1d CHoCH).
*   **Market Structure**: 
    *   **Premium/Discount**: Price is currently in the **Extreme Premium** zone relative to the 60-day range.
    *   **Imbalance (FVG)**: A notable Bullish FVG exists between `$6.15` and `$6.56`. This acts as a downside magnet.
    *   **Value Area**: The 5-day Value Area resides between `$6.74` (VAL) and `$7.60` (VAH). Price is currently hovering near the top of this range at `$7.25`.


*   **Volumetric Confluence**:
    *   **60d POC**: `$3.57` (Deep Value).
    *   **Session POC**: `$7.11` (High-volume node where the current battle is being fought).
    *   **RVOL**: Significant accumulation noted, but price is struggling to hold above the session VAH of `$7.60`.


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Sortino Ratio
*   **Value**: `0.38`
*   **Status**: **FAIL**
*   **Analysis**: The asset's downside deviation of `0.44%` is too high relative to its current realized returns for a Sniper-grade execution. We require the ratio to stabilize above `2.0` to authorize a full 1R Strike.


---


# 5. Execution Parameters (Targeting)

*   **Strike Zone (Entry)**: `$7.11` (Retest of Session POC)
*   **Hard Stop**: `$6.74` (Invalidation below Session VAL)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `675` Shares
*   **Target (4:1 RR)**: `$8.59`


---


# 6. Risk Guardrails

*   **Tactical Warning**: The `$50M` ATM offering acts as a "Shield" for the company but a "Sword" against the stock price. Expect "Hidden Orders" (Icebergs) at psychological levels like `$7.50` and `$8.00` as the sales agents work the offering.
*   **Kill Switch**: A daily close below `$6.70` (60d VAH) would invalidate the current breakout thesis and signal a full retracement to the `$6.15` FVG.
*   **Protocol**: Since the Sortino is sub-par, any engagement upon hitting the Strike Zone MUST be downgraded to a **0.5R SCOUT** position until momentum is reclaimed.