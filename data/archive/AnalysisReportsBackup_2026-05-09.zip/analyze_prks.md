> **Generated:** Friday, May 08, 2026 at 01:25 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**Execution Authorization: STRIKE Authorized**


PRKS has executed a high-velocity displacement move, surging `6.96%` to break out of its 60-day macro value area. The price action has successfully cleared the Macro VAH of `$37.87`, signaling a transition from institutional accumulation to active expansion. This move is supported by a Day Trading Sortino Ratio of `2.57`, which comfortably clears our institutional hurdle of `2.0`, indicating high-quality, low-variance upside momentum.


The rationale for this **STRIKE** is based on the "Sniper" profile: catching the high-momentum "Sword" expansion following a structural Change of Character (CHoCH) at `$34.20`. Despite the macro-bearish overhang, the tactical tape shows aggressive institutional buying (RVOL and displacement) ahead of the summer seasonal window and the upcoming earnings release on May 11, 2026. We are targeting the external buy-side liquidity pool sitting at the `$40.26` peak.


***


# 2. Institutional News & Social Sentiment


*   **SeaWorld Parks Unveil Coast-to-Coast Summer Spectacular Lineup** (Morningstar | 1d ago)
    SeaWorld is launching a massive summer campaign across Orlando, San Diego, and San Antonio featuring new drone shows and attractions to drive attendance.


*   **United Parks & Resorts Announces Q1 2026 Earnings Date** (Sahm | 2w ago)
    The company is set to release financial results before market open on Monday, May 11, 2026, creating a volatility catalyst for the current move.


*   **DOJ Files ADA Lawsuit Against United Parks & Resorts** (NBC26 | 2d ago)
    The Department of Justice is suing the company over alleged Americans with Disabilities Act violations at several parks, presenting a known legal headwind that the market is currently "climbing" over.


*   **SeaWorld Salutes Veterans with Free Admission** (Stock Titan | 1d ago)
    A promotional push for Military Appreciation Month offering free tickets to veterans and guests to bolster Q2 foot traffic.


*   **Sentiment Synthesis**: 
    Institutional sentiment is cautiously bullish, focused on seasonal rotation and the "Summer Spectacular" expansion. Social sentiment (Reddit/Twitter) is highlighting the stock as a "Sword" play for the reopening/summer trade, though the DOJ lawsuit remains a point of minor bearish contention that has failed to suppress the current price breakout.


***


# 3. Execution Parameters


*   **Execution State**: **STRIKE Authorized**


*   **Share Quantity**: `210 Shares`


*   **Risk Unit (R)**: `$250`


*   **Strike Zone (Entry)**: `$39.64` to `$39.20`


*   **Hard Stop**: `$38.45`


*   **Profit Target (Initial)**: `$40.83` (1:1 R/R for de-risking)


***


# 4. Quantitative Metrics & Structural Audit


**MATHEMATICAL HURDLES**
*   **Day Trading Sortino**: `2.57` (Status: **PASS**)
*   **Downside Deviation**: `0.51%`
*   **ATR (5m)**: `$0.19`


**MARKET STRUCTURE (SMC)**
*   **Macro Trend**: Bearish Overhang (CHoCH at `$34.20`)
*   **Tactical Trend**: Strong Bullish Expansion
*   **Bullish Order Block**: `$32.35` — `$34.23` (The "Origin" of the move)
*   **Institutional Imbalance (FVG)**: `$38.71` — `$39.60` (Current Friction Zone)
*   **External Liquidity Target**: `$40.26`


**VOLUME PROFILE ANALYSIS (60D)**
*   **Point of Control (POC)**: `$35.71`
*   **Value Area High (VAH)**: `$37.87`
*   **Value Area Low (VAL)**: `$33.56`


***


# 5. Risk Guardrails


*   **The "Sword" Narrative**: This is a momentum-driven trade. We are operating in the "Expansion" phase. If the price fails to hold the tactical VAH of `$36.79`, the "Sword" has snapped, and we exit.


*   **Kill Switch**: A move back inside the Macro Value Area (Close below `$37.87`) invalidates the breakout. This would signal a "Fakeout" and requires an immediate manual exit to protect the account.


*   **Volatility Warning**: With earnings scheduled for May 11, be prepared for IV crush or pre-earnings profit taking. This Sniper trade is intended to capture the pre-run liquidity sweep of the `$40.26` level before the weekend.


**Final Authorization**: Technicals and risk metrics are aligned. Proceed with the **STRIKE** at `$39.64` or on a minor dip within the zone.