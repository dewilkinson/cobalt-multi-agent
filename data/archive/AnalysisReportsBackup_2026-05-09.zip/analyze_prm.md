> **Generated:** Friday, May 08, 2026 at 03:46 PM

Active Strategy: Shield Strategy


# 1. Execution Summary


**Execution Authorization: STRIKE Authorized**


Perimeter Solutions (`PRM`) is currently displaying elite **Shield** characteristics following a massive Q1 earnings catalyst. The asset has cleared its tactical resistance at `$29.87` (CHoCH) and is currently undergoing institutional revaluation. While the `10.42%` surge typically suggests a "Sword" profile, the mathematical underlying—specifically a **Sortino Ratio of `3.42`**—confirms that volatility is heavily skewed to the upside with negligible downside deviation (`0.66%`). 


The combination of a fundamental earnings blowout (74% revenue surge) and a defensive business model (government fire safety contracts) positions `PRM` as a high-fidelity **Shield** for the current portfolio. Institutional accumulation is visible via the `1.2+` RVOL and the successful defense of the `$30.24` Point of Control (`POC`). We are authorizing a full **STRIKE** deployment on consolidation near the Value Area High.


---


# 2. Institutional News & Social Sentiment


*   **UBS Adjusts Price Target on Perimeter Solutions to `$34` From `$30`** | *Source: Marketscreener* | **2d ago**
    UBS reiterates a "Buy" rating, citing the Q1 earnings strength and improved margin outlook for the fire safety segment.


*   **Perimeter Solutions Reports 74% Revenue Surge in Q1 2026** | *Source: Investing.com* | **2d ago**
    The company significantly outperformed analyst expectations with a `146%` positive surprise in adjusted EPS, driven by major contract wins.


*   **Perimeter Solutions releases Q1 2026 Financial Results** | *Source: AlphaStreet* | **2d ago**
    Reported non-GAAP adjusted earnings of `$0.06` per share against a `$0.02` forecast, showcasing high operational efficiency.


*   **Universal Beteiligungs und Servicegesellschaft mbH increases stake by 239%** | *Source: MarketBeat* | **5d ago**
    Significant institutional inflow noted prior to earnings, confirming "Smart Money" positioning in the `$1.52 Million` range.


*   **Social Sentiment (Reddit/Twitter/StockTwits)**:
    Sentiment is overwhelmingly **Bullish**. Retail traders are primarily focused on the "all-time high" breakout and the USDA contract narrative, while institutional scanners are flagging the high Sortino and momentum scores.


---


# 3. Execution Parameters


*   **Execution State**: **STRIKE** (1R Deployment)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Strike Zone (Entry)**: `$31.50` - `$31.80`
*   **Hard Stop**: `$30.50`
*   **Profit Target (Initial)**: `$34.00` (UBS PT Alignment)


---


# 4. Quantitative Structural Audit


### **Smart Money Concepts (SMC)**
*   **Institutional Trend**: **Bullish** (Macro CHoCH at `$29.8750`)
*   **Tactical Order Block**: Bullish zone established at `$20.38` - `$21.46`
*   **Fair Value Gaps (FVG)**: Minor bearish imbalance at `$30.75` - `$30.78` (Target for entry consolidation)
*   **Authorization Matrix**: **PASS** (Trigger aligns with Institutional Macro Trend)


### **Volume Profile Analysis**
*   **1d POC (Point of Control)**: `$30.24`
*   **1d VAH (Value Area High)**: `$31.89`
*   **1d VAL (Value Area Low)**: `$27.11`
*   **60d POC**: `$27.90`
*   **Total Volume**: `1,435,719` (Confirming Institutional Accumulation)


### **Volatility & Risk Metrics**
*   **Sortino Ratio**: `3.42` (Elite Shield Filter: `> 2.0`)
*   **ATR (5m)**: `0.16`
*   **Downside Deviation**: `0.66%`
*   **Status**: High-efficiency asset with restricted downside risk.


---


# 5. Risk Guardrails


*   **Daily Kill Switch**: If price closes below `$29.80` (Structural break of the CHoCH pivot).
*   **MOC Exit**: Close position at `3:55 PM` if `VIX > 25` and the position is not at Break-Even.
*   **Scale-In Protocol**: Add second unit (up to 2R) only if the first unit is protected at a Break-Even stop and price clears the `$32.02` session high.


***
*System Date: Fri May 08 2026 15:46:19*
**Status: OK**