> **Generated:** Monday, May 04, 2026 at 06:58 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**STRIKE Authorized**


B. Riley Financial (`$RILY`) has successfully transitioned into a high-conviction "Sword" posture following a macro Change of Character (`CHoCH`) at `$7.90`. This structural pivot confirms that institutional supply has been absorbed, shifting the narrative from distribution to aggressive accumulation. 


The presence of a massive Fair Value Gap (`FVG`) between `$8.05` and `$8.58` serves as a high-probability institutional anchor. Combined with a robust Day Trading Sortino Ratio of `4.26`, the asset demonstrates the necessary asymmetric upside required for a Sniper Execution. We are targeting a move toward the macro Value Area High (`VAH`) of `$10.97` as the primary liquidity objective.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Execution Parameters

*   **Execution State**: **STRIKE** (1.0R Deployment)
*   **Strike Zone (Entry)**: `$8.95`
*   **Hard Stop**: `$7.95` (Placed below the Displacement Pivot)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Primary Target**: `$10.97`
*   **Trailing Anchor**: Engage 1R Trailing Stop once price clears `$10.00`


---


# 4. Structural Audit (SMC)

**Institutional Trend & Bias**
*   **Macro Bias**: Bullish (MTF Alignment)
*   **Change of Character (CHoCH)**: `$7.90` (Validated)
*   **Market Structure**: Currently in a "Discount" zone relative to the cycle high of `$10.97`.


**Zones of Interest**
*   **Institutional Imbalance (FVG)**: `$8.05` – `$8.58` (Primary Support/Entry Anchor)
*   **Order Block (OB)**: `$6.43` – `$7.26` (Macro Floor)
*   **Liquidity Profile**: Buy-side sweep completed at `$9.04`; path cleared for expansion.


---


# 5. Quantitative Metrics & Tape Reading

*   **Current Price**: `$8.98`
*   **Intraday Change**: `+3.02%`
*   **Day Trading Sortino**: `4.26` (Hurdle: `>= 2.0` - **PASS**)
*   **Downside Deviation**: `0.53%` (Extremely Low)
*   **Volatility (ATR 5m)**: `0.11`
*   **Volume (Session)**: `1,473,800`
*   **Point of Control (POC)**: Shifted from `$7.15` (60d) to `$7.66` (Session), indicating an upward migration of "Smart Money" support.


---


# 6. Risk Guardrails & Strategy Note

*   **Kill Switch**: A 5-minute candle close below `$7.90` invalidates the macro structure and requires an immediate exit.
*   **Sword Recovery**: This ticker shows a high historical propensity for fast recovery from intraday dips, aligning with our "War Barbell" growth requirements.
*   **Execution Grade**: **A-Tier**. The setup meets all confluence requirements: `RS > 90`, clear `SMC CHoCH`, and a `Sortino Ratio` significantly above our baseline.


---


**Status: STRIKE Authorized. Execution engine ready.**