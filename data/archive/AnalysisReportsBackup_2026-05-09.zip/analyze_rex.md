> **Generated:** Thursday, May 07, 2026 at 10:42 AM

Active Strategy: Sniper Strategy


---


### 1. Execution Summary

- **Recommendation**: **SCOUT Authorized**


- **Rationale**: REX displays a powerful institutional trend backed by a confirmed **Daily Break of Structure (BOS)** at `$36.50`. However, the current technical state requires a **SCOUT** (0.5R) deployment rather than a full STRIKE because the **Sortino Ratio** of `1.41` fails to meet the strict Sniper threshold of `2.0`. Price is currently in a "Discount" phase, retracing from 52-week highs toward the **Tactical Point of Control (POC)**. We are sniping the gap between the current market price and the primary Bullish Order Block to minimize drawdown.


---


### 2. Institutional News & Social Sentiment

- **MarketBeat (April 29, 2026 | 8d ago)**: REX American Resources Sets New 1-Year High - Weiss Ratings upgraded the ticker to a "Buy" as it touched `$48.83`.
- **MarketBeat (April 24, 2026 | 13d ago)**: M&T Bank Corp Makes New `$17.20 Million` Investment - Institutional accumulation confirmed with a purchase of `532,135` shares.
- **MarketBeat (April 12, 2026 | 25d ago)**: Tudor Investment Corp ET AL Takes Position - Paul Tudor Jones' fund acquired a new stake valued at `$2.34 Million`.
- **Investing.com (Recent)**: CFO Douglas Bruggeman Sells `$90,880` in Stock - Insider distribution noted near 52-week highs, contributing to the current pullback.


- **Social Sentiment Synthesis**: Narrative is split between "Institutional FOMO" and "Insider Profit Taking." While retail sentiment on Intellectia AI is "Somewhat-Bearish" due to technical overextension, Smart Money filings (JPM, Tudor, M&T) confirm massive institutional support for the "Sword" thesis.


---


### 3. Structural Audit (SMC Primitives)

- **Institutional Trend**: **Bullish**
- **Macro Anchor**: **BOS** at `$36.50` (Daily Expansion)
- **Point of Control (POC)**: `$42.99` (5-Day Tactical Anchor)
- **Value Area High (VAH)**: `$46.98`
- **Value Area Low (VAL)**: `$42.20`
- **Bullish Order Block (OB)**: `$41.38` to `$43.06`
- **Fair Value Gaps (FVG)**: Bullish imbalance identified at `$48.91` - `$49.49` (Target Zone)


---


### 4. Sortino Hurdle Check

- **Strategy Threshold**: `2.0`
- **Current Metric**: `1.41`
- **Verdict**: **FAIL**
- **Risk Adjustment**: Exposure downgraded from **STRIKE** (1R) to **SCOUT** (0.5R) to compensate for elevated downside deviation during this retracement.


---


### 5. Tactical Execution: The Sniper Path

**Execution Parameters**:

- **Status**: **SCOUT Authorized**
- **Risk Unit (R)**: `$125` (0.5R)
- **Share Quantity**: `18 Shares`
- **Strike Zone (Entry)**: `$47.76` (Market) scaled down to `$43.25` (POC)
- **Hard Stop**: `$41.00`
- **Primary Target**: `$53.36` (Recent High)


---


### 6. Risk Guardrails

- **Sword/Shield Protocol**: REX is a high-alpha "Sword" asset. The current pullback is viewed as healthy re-accumulation by institutional players (JPM/Tudor).
- **Kill Switch**: A daily close below `$40.50` invalidates the Bullish Order Block and the macro thesis; all positions must be liquidated immediately.
- **Scale-In Criteria**: If the price stabilizes above `$45.00` and the **Sortino Ratio** climbs above `2.0`, authorization for a second **SCOUT** unit to reach full **STRIKE** (1R) exposure is granted.