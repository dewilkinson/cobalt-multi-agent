> **Generated:** Thursday, May 07, 2026 at 04:39 PM

Active Strategy: Shield Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


**OUTFRONT Media (OUT)** is currently displaying optimal "Shield" characteristics, providing a robust defensive anchor for the portfolio. The asset has transitioned into a high-fidelity institutional accumulation phase, confirmed by a massive MTF trend shift (CHoCH at `$19.27`) and a current price action holding firmly above the session Value Area High. 


The rationale for this **STRIKE** authorization is a confluence of a superior **Sortino Ratio of 4.96** and strong institutional sponsorship. While the broader market may experience turbulence, `OUT` is grinding toward all-time highs with low internal volatility (`ATR: 0.14`), suggesting a "Sword-like" growth profile within a "Shield-like" risk framework. The technical structure shows a clear path of least resistance to the upside, supported by a significant Fair Value Gap (FVG) and rising earnings estimates.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Zacks Research Expects Stronger Earnings for OUTFRONT Media** (1h ago) | **Neutral/Bullish**  
    Analysts upgraded Q4 2026 EPS estimates to `$0.75`, signaling long-term confidence in the REIT's cash flow stability despite a recent "Hold" rating.


*   **Outfront Media stock hits all-time high at 31.9 USD** (4h ago) | **Bullish**  
    Reporting a significant `112%` increase over the past year, the stock is catching momentum as it breaches major psychological resistance levels.


*   **Gear Up for Outfront Media (OUT) Q1 Earnings: Wall Street Estimates** (1d ago) | **Bullish**  
    Market anticipates a `100%` year-over-year increase in EPS (`$0.28`) and a `7.5%` rise in revenue, providing fundamental armor to the current technical breakout.


*   **Vanguard Group Inc. Has $545.98 Million Stock Position in OUTFRONT Media Inc.** (2d ago) | **Bullish**  
    The institutional giant increased its stake by `5.3%` to over `22.6M` shares, providing a massive "Shield" of liquidity and professional floor support.


*   **Short Interest Update: 23.3% Increase in April** (6d ago) | **Somewhat-Bearish/Contrarian Bullish**  
    High short interest (`5.1M` shares) near all-time highs creates a high-probability "Short Squeeze" scenario as the trend remains stubbornly bullish.


---


# 3. STRUCTURAL AUDIT & SMC ANALYSIS


The market structure for `OUT` is in a state of **Institutional Alignment**, characterized by a series of Break of Structure (BOS) events and deep liquidity pools.


*   **Institutional Trend**: Bullish (MTF CHoCH confirmed at `$19.27`).
*   **Point of Control (POC)**: `$30.44` (5d/Session Anchor).
*   **Value Area High (VAH)**: `$31.15`.
*   **Value Area Low (VAL)**: `$28.88`.


**Gaps and Order Blocks**:
*   **Bullish FVG**: `$31.30` - `$32.24` (Current price is holding above this displacement zone).
*   **Primary Order Block**: `$25.40` - `$26.21` (Macro fortification).
*   **Liquidity Profile**: Buy Side Liquidity (BSL) is actively being hunted above `$33.10`.


---


# 4. MATHEMATICAL HURDLE (SORTINO)


*   **Day Trading Sortino**: `4.96`
*   **Downside Deviation**: `0.30%`
*   **Status**: **PASS**


A Sortino Ratio of `4.96` is exceptional for the Shield Strategy. It indicates that the vast majority of the volatility in `OUT` is positive. For every unit of "bad" (downside) risk taken, the stock is returning nearly `5x` in performance, making it a premier candidate for wealth preservation and steady growth.


---


# 5. TACTICAL EXECUTION: THE SNIPER PATH


Based on the **STRIKE** authorization, the following parameters are set for deployment:


*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$32.00` - `$32.81`
*   **Hard Stop**: `$31.50`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `190 Shares`


---


# 6. RISK GUARDRAILS


*   **Kill Switch**: A daily close below the Session POC of `$30.44` invalidates the immediate bullish thesis and suggests a return to the macro value area. 
*   **ATR Awareness**: With a 5m ATR of `0.14`, expect minor intraday noise; however, the structural stop at `$31.50` remains outside this noise threshold to prevent premature exit.
*   **Earnings Caution**: With Q1 earnings reports imminent, be prepared for increased volatility. The position size remains fixed at `1R` to manage gapping risk.