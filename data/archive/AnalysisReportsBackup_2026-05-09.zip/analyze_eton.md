> **Generated:** Friday, May 08, 2026 at 10:13 AM

Active Strategy: Sniper Strategy

# 1. EXECUTION SUMMARY

**SCOUT Authorized**

ETON is currently demonstrating high-fidelity institutional displacement, confirmed by a **Macro CHoCH** (Change of Character) at `$17.33`. The stock is a classic "Sword" asset, currently benefiting from aggressive accumulation following the relaunch of Hemangeol and anticipation of the `May 14` earnings report. 

While the macro trend is unequivocally bullish, the intraday tape shows a healthy retracement from the `$32.31` cycle peak. Under the **Sniper Protocol**, we are passing on the current price of `$30.30` and waiting for a liquidity grab within the high-density **Fair Value Gap (FVG)** located between `$29.80` and `$30.10`. A **SCOUT** entry is authorized at the `$30.10` level to probe for a structural rejection before scaling to a full **STRIKE** position.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

The fundamental narrative is acting as a tailwind for technical expansion:

*   **Eton Pharmaceuticals Relaunches HEMANGEOL With Exclusive Distribution** (TipRanks, 3h ago): This relaunch is the primary catalyst for the recent institutional "gap and go" price action.
*   **Eton Pharmaceuticals (NasdaqGM:ETON) Stock Forecast & Analyst Predictions** (Simply Wall Street, 5h ago): Sentiment remains highly optimistic regarding the specialty pharmacy distribution model.
*   **Eton Pharmaceuticals to Report First Quarter 2026 Financial Results on Thursday, May 14** (GlobeNewswire, 1d ago): This upcoming earnings event is creating a volatility magnet, likely driving the current pre-event accumulation.
*   **Social Sentiment**: Strong "Smart Money" chatter regarding the stock's inclusion in "Top Growth Stocks" lists (Insider Monkey), indicating high retail and institutional alignment.


---


# 3. STRUCTURAL AUDIT & TAPE READING

**Institutional Footprint (SMC)**

*   **Macro Bias**: Bullish. Structural pivot confirmed at `$17.33`.
*   **Premium/Discount Array**: Price is currently in a short-term premium. We are hunting for a return to the **Tactical Discount** zone near the `$23.49` Volume POC for long-term holds, but for the Sniper day-trade, we target the immediate imbalance.
*   **Imbalance (FVG)**: A significant bullish gap exists between `$29.80` and `$30.10`. This is our "Sniper Kill Zone."
*   **Order Blocks**: 
    *   Tactical OB: `$22.50` - `$23.12` (Major defense).
    *   Intraday OB: `$29.80` - `$30.10` (Entry confluence).
*   **Liquidity Targets**: Buy-side liquidity resides at the `$32.31` high.


---


# 4. QUANTITATIVE METRICS

*   **Day Trading Sortino**: `3.40` (Hurdle: `2.0`). This indicates exceptional risk-adjusted performance during upward moves.
*   **Volatility (ATR)**: `0.27`. This low intraday noise allows for a tight technical stop.
*   **Volume Profile (POC)**: 
    *   Macro POC: `$16.90`.
    *   Tactical (5d) POC: `$23.49`.
*   **Downside Deviation**: `0.52%`. Risk of a "Sword crash" is currently mitigated by heavy structural support layers.


---


# 5. EXECUTION PARAMETERS

Based on the **Sniper Strategy** (4:1 RR Target) and current morning chop (VIX/Time context), we are deploying a **SCOUT** unit.

*   **Tactic**: **SCOUT** (0.5R Deployment)
*   **Strike Zone (Entry)**: `$30.10` (Limit Order at FVG Ceiling)
*   **Hard Stop**: `$29.10` (Placed below the FVG and ATR buffer)
*   **Risk Unit (R)**: `$125`
*   **Share Quantity**: `125 Shares`
*   **Primary Target (TP1)**: `$34.10` (Targeting 4:1 RR ratio)


---


# 6. RISK GUARDRAILS

*   **Daily Kill Switch**: If ETON closes a 5m candle below `$28.90`, the momentum narrative is invalidated; exit all units immediately.
*   **Earnings Caution**: Note the `May 14` earnings date. All Sniper day-trade positions must be flattened prior to the 4:00 PM ET close on May 13 to avoid binary overnight risk.
*   **Scaling Note**: Transition from SCOUT to STRIKE (adding another `$125` risk) only if the `$30.10` level holds on the 15m timeframe and price breaks above `$30.80`.