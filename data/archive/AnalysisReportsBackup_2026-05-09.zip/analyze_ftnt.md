> **Generated:** Friday, May 08, 2026 at 11:22 AM

Active Strategy: Shield Strategy


# 1. Execution Summary

**STRIKE Authorized**


Fortinet (`FTNT`) is currently demonstrating elite institutional structural alignment and qualifies as a premier **Shield** asset within the War Barbell framework. The asset has cleared its macro ceiling with a confirmed Change of Character (`CHoCH`) at `$87.11` and is currently trading in a high-conviction expansion phase. 


The authorization is driven by a superior risk-adjusted profile, evidenced by a **Sortino Ratio** of `4.15`. This significantly exceeds our institutional hurdle of `2.0`, indicating that downside volatility is being strictly contained by institutional accumulation. With price accepted well above the **60d Macro POC** of `$80.83`, the path of least resistance remains skewed to the upside.


---


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading

**Institutional Bias**: **BULLISH** (MTF Alignment)


**Market Structure (Dual-Anchor Protocol)**:

*   **Macro Apex**: `$112.39` (Current cycle high)
*   **Displacement Pivot**: `$87.11` (Daily `CHoCH` Anchor)
*   **Structural State**: Trading in the **Premium Zone**; currently in Price Discovery.


**Institutional Footprint**:

*   **Primary Order Block (OB)**: `$76.01` – `$80.52` (The "Shield" Floor)
*   **Fair Value Gaps (FVG)**: Major bullish imbalance identified between `$90.29` and `$104.51`, serving as a secondary liquidity cushion.
*   **Liquidity Targets**: Immediate buy-side liquidity resides at `$112.40`. 


**Volumetric Confluence**:

*   **Macro POC (60d)**: `$80.83`
*   **Tactical POC (5d)**: `$85.86`
*   **Session Intraday POC**: `$110.77`


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `4.15`
*   **Downside Deviation**: `0.28%`
*   **Status**: **PASS**


The exceptionally low downside deviation confirms that `FTNT` is exhibiting the "Shield" characteristics required for capital preservation during market volatility.


---


# 5. Execution Parameters

*   **Strategy**: Grinder (Default)
*   **Strike Zone (Entry)**: `$111.71`
*   **Hard Stop**: `$110.39` (Set below the `5m ATR` floor)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `189` **Shares**
*   **Risk-Reward (RR)**: `3:1` Minimum Target


---


# 6. Risk Guardrails & Performance Metrics

*   **Daily Stop**: `3R` (`$750` total account risk)
*   **Kill Switch**: A decisive close below the Session Intraday POC at `$109.15` invalidates the immediate tactical thesis.
*   **Management**: Scale to full `1R` exposure only if the initial probe unit reaches Break-Even. Close laggards at `3:55 PM` ET if `VIX` exceeds `25`.
*   **Trailing Protocol**: Use the `5m ATR` (`0.66`) to trail stops aggressively to capture momentum while insulating the `IRA` principal.