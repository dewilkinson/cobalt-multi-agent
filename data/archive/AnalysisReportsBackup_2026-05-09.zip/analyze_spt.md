> **Generated:** Friday, May 08, 2026 at 10:48 AM

Active Strategy: Sniper Strategy

---

### **1. Execution Summary**

**SCOUT Authorized**

SPT is exhibiting a high-fidelity technical reclaim following a `+4.52%` morning gap. While the Macro Institutional Trend remains technically bearish due to a prior Break of Structure (BOS) at `$9.16`, the intraday structure has transitioned into a bullish "Change of Character" (CHoCH). The asset has successfully reclaimed the **Macro Value Area Low (VAL)** of `$4.92` and is currently attacking the `$7.17` level with significant relative strength.

The **Day Trading Sortino Ratio** of `2.81` exceeds our internal sniper hurdle of `2.0`, confirming that the current price action is driven by systematic institutional accumulation rather than high-variance retail volatility. Given the VIX environment and the counter-trend nature of this move against the macro backdrop, a **SCOUT (0.5R)** entry is authorized to test the momentum toward the **Macro Value Area High (VAH)** of `$8.19`.

---

### **2. Institutional News & Social Sentiment**

`[DATA_UNAVAILABLE]`

---

### **3. Structural Audit & SMC Analysis**

*   **Institutional Trend**: Bearish Macro (BOS at `$9.16`) / Bullish Tactical.
*   **Market Structure**:
    *   **Macro Ceiling**: `$12.06`
    *   **Tactical Decision Point**: `$9.16` (Primary target for trend neutralisation).
    *   **CHoCH Confirmation**: Reclamation of the `$6.63` - `$7.06` Bullish Fair Value Gap (FVG).
*   **Institutional Footprint**:
    *   **Order Block (Supply)**: `$10.50` - `$11.13`.
    *   **Imbalance (Demand)**: Bullish FVG identified between `$6.63` and `$7.06`.
    *   **Liquidity Pools**: External buy-side liquidity resting at the Macro VAH of `$8.19`.

---

### **4. Volumetric Mapping**

*   **Macro Point of Control (POC)**: `$5.66` (High-volume base).
*   **Macro Value Area**: `$4.92` (VAL) to `$8.19` (VAH).
*   **Session Profile**: The session is currently trading in a "thin-air" node above the tactical VAH of `$6.23`, suggesting high-velocity potential if support holds.
*   **Volatility (ATR)**: `0.41` (Hourly range expectation).

---

### **5. Mathematical Hurdle (Sortino)**

*   **Metric**: Day Trading Sortino Ratio.
*   **Value**: `2.81`.
*   **Status**: **PASS** (Hurdle $\ge$ `2.0`).
*   **Note**: Downside deviation is constrained at `0.68%`, indicating stable upward delivery.

---

### **6. Execution Parameters**

*   **Execution Tier**: **SCOUT** (0.5R Tier)
*   **Risk Unit (R)**: `$125`
*   **Strike Zone (Entry)**: `$7.10` - `$7.17`
*   **Hard Stop**: `$6.76`
*   **Share Quantity**: `304 Shares`
*   **Target 1 (VAH)**: `$8.19` (`2.5:1` RR)
*   **Target 2 (BOS)**: `$9.16` (`4.8:1` RR)

---

### **7. Risk Guardrails**

*   **Kill Switch**: If SPT closes below `$6.63` on the 1-hour timeframe, the bullish FVG is invalidated, and the trade must be liquidated immediately.
*   **Tactical Management**: This is a "Sword" asset position. We are sniping the gap-and-go momentum. If the price fails to sustain the `$7.00` psychological handle, the position will be closed at breakeven or small loss to preserve the `$100k` account core.
*   **Scale-In**: Authorization for a full **STRIKE (1R)** position only if price clears the `$7.30` resistance node and the first unit is at break-even.