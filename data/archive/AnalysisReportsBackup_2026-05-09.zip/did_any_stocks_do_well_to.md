> **Generated:** Thursday, May 07, 2026 at 04:27 PM

While the broader indices remained under pressure from rising yields, today's session featured extreme idiosyncratic volatility driven by first-quarter earnings and guidance revisions. High-growth technology and infrastructure names significantly decoupled from the **CHOP / MILD RISK-OFF** regime seen in the **SPY** and **QQQ**, with several mid-cap stocks recording gains exceeding `30%`.


The primary theme for outperformers today was "Guidance Acceleration." Companies that not only beat earnings but raised full-year revenue outlooks—most notably **Datadog (DDOG)**—were rewarded with massive institutional accumulation despite the `-1.58%` decline in the small-cap **IWM** index.


---


I. TOP EQUITY GAINERS & RELATIVE STRENGTH


| Asset | Ticker | Price | Change % | Volume vs. Avg |
| :--- | :--- | :--- | :--- | :--- |
| **Fluence Energy, Inc.** | **FLNC** | `$18.97` | `+39.90%` | `~9.5x` |
| **Xometry, Inc.** | **XMTR** | `$78.50` | `+39.18%` | `~3.2x` |
| **AAON, Inc.** | **AAON** | `$129.25` | `+31.49%` | `~8.2x` |
| **Datadog, Inc.** | **DDOG** | `$188.73` | `+31.33%` | `~4.4x` |
| **HawkEye 360, Inc.** | **HAWK** | `$34.00` | `+30.77%` | `~3.4x` |
| **Qualcomm** | **QCOM** | `$202.55` | `+5.13%` | `N/A` |


---


II. KEY EARNINGS BREAKOUTS & NARRATIVE DRIVERS


*   **Datadog (DDOG) Cloud Momentum**: The stock surged `+31.33%` after management raised its full-year revenue outlook. This move signals a potential bottoming out of cloud-spend optimization concerns and a pivot back toward aggressive scaling in the observability sector.


*   **Sunrun (RUN) Profitability Pivot**: **RUN** jumped over `11%` after reporting a Q1 earnings surprise of `$0.62` per share. This significantly outperformed the analyst consensus, which had forecasted a net loss, suggesting improved operational efficiency in the solar sector despite the high-interest-rate environment.


*   **Sterling Infrastructure (STRL) Growth**: Reported a `92%` year-over-year revenue increase, reaching `$825.7M`. The resulting `143%` jump in net income highlights a robust demand for industrial and data center infrastructure, allowing the stock to ignore the broader macro weakness in the industrial sector.


*   **Qualcomm (QCOM) Tech Rotation**: Gaining `+5.13%` to close at `$202.55`, **QCOM** acted as a relative strength leader within the mega-cap tech space, benefiting from a rotation out of struggling software names and into established semiconductor hardware providers with AI-exposure.


---


III. SECTOR-SPECIFIC TRENDS & ANOMALIES


*   **Infrastructure & Energy Resilience**: Despite the **10-Year Yield** hitting `4.39%`, infrastructure names like **AAON** and **STRL** showed extreme strength. This suggests institutional buyers are prioritizing companies with locked-in backlogs and direct ties to the AI-driven data center build-out.


*   **Massive Volume Anomalies**: **Fluence Energy (FLNC)** traded `44.5M` shares against a 3-month average of `4.7M`. Such a significant volume spike (approx. `946%` of average) indicates a high-conviction "valuation reset" by institutional desks.


*   **Semiconductor Divergence**: While **QCOM** performed well, other sub-sectors faced pressure. **Lam Research (LRCX)** dropped `-3.60%` and **Applied Materials (AMAT)** fell `-4.04%`, illustrating a selective "picking-of-winners" within the semiconductor space rather than a broad-based industry rally.


---


IV. STRATEGIC CONTEXT: ALPHA VS. BETA


The day was a "Stock Picker's Market." While the **Beta** (market return) was negative—with **SPY** down `-0.31%` and **IWM** down `-1.58%`—the **Alpha** (individual stock performance) was exceptionally high for those positioned in specific earnings-momentum names. The sharp contrast between the top gainers and laggards like **Fastly (FSLY)** at `-38.23%` emphasizes that the current market regime is punishing execution misses and rewarding guidance raises with extreme prejudice.