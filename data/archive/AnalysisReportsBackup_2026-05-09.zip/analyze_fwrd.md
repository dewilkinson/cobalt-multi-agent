> **Generated:** Wednesday, May 06, 2026 at 09:37 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**Recommendation: WAIT (Retain Cash)**


**Execution Authorization**: **VETOED**. $FWRD$ is currently exhibiting a "Dead Cat Bounce" within a larger institutional distribution phase. While the asset shows an intraday gain of `+5.01%`, it fails to meet the **Sortino Sniper Hurdle** ($S \ge 2.0$) and remains structurally broken on the macro timeframe. The price is currently trapped beneath a massive "Wall of Supply" represented by a Bearish Fair Value Gap (FVG) starting at `$17.13`. 


The institutional tape suggests this gap-up is being used for liquidity exit rather than accumulation. Until the asset reclaims the **60-day Value Area Low (VAL)** at `$18.91`, the risk-to-reward ratio remains mathematically unfavorable for a long-only Sniper execution.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading

**Market Structure (Dual-Anchor Protocol)**:
*   **Macro Ceiling (Cycle High)**: `$31.17` — The point of origin for the current structural collapse.
*   **Tactical DP (Displacement Pivot)**: `$22.79` — High-volume pivot where institutional selling maximized.
*   **Macro Trend**: **BEARISH**. Institutional CHoCH (Change of Character) confirmed at `$15.75`.
*   **Institutional Alignment**: **FAIL**. The 5-minute execution trigger is fighting against the 1-day Macro bearish trend.

**The Tape (SMC Analysis)**:
*   **Liquidity Pools**: Internal liquidity residing at `$14.81` (60-day low). Smart money is likely to target this "Sell Side Liquidity" before a sustained reversal.
*   **Supply Zones**: A massive Bearish FVG exists between `$17.13` and `$21.19`. This acts as a gravitational ceiling for the current price action.
*   **Volume Profile (RVOL)**: Price is currently trading in a "High Volatility Void" below the 60-day POC of `$25.38`.


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Day Trading Sortino Ratio
*   **Current Value**: `0.76`
*   **Target Hurdle**: `2.0`
*   **Status**: **FAIL**
*   **Analyst Note**: A Sortino of `0.76` indicates that the stock's downside deviation (`0.48%`) is significantly higher than its risk-adjusted return potential. This volatility profile violates the "Shield" component of our Barbell strategy, posing an unacceptable risk to capital preservation.


---


# 5. Tactical Execution Parameters

*If the "Sniper Trigger" is met (Price > `$18.91` with high volume), use the following:*

*   **Strike Zone (Entry)**: `$18.95` – `$19.10`
*   **Hard Stop**: `$17.95`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250 shares`
*   **Target (3R)**: `$22.00` (Aligned with Tactical Supply)


---


# 6. Risk Guardrails

*   **Kill Switch**: A breach of `$16.86` (Session Low) invalidates all long-side hypotheses.
*   **Performance Note**: $FWRD$ is currently a "Sword" with a dull edge. The lack of a Liquidity Sweep on the 5-minute chart indicates that institutional "Intent" has not yet shifted from distribution to accumulation. 
*   **Portfolio Balance**: This asset currently carries too much "Tail Risk" for the Blueshell Securities mandate. **Retain cash and wait for high-probability structural reclamation.**