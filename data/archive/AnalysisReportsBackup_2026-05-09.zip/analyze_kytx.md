> **Generated:** Friday, May 08, 2026 at 10:31 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Retain Cash)**


KYTX currently presents a technical contradiction that precludes a high-conviction **SNIPER** entry. While the **Macro Structure** remains historically Bullish following a daily **Break of Structure (BOS)** at `$8.44`, the immediate tactical environment is inefficient. The asset has failed the **Mathematical Hurdle** with a **Sortino Ratio** of `0.68`, significantly below our institutional requirement of `2.0`. 


Price action is currently compressing within a high-volume node near the **Point of Control (POC)** of `$9.32`, indicating a "Battleground Zone" where institutional accumulation and distribution are in a state of equilibrium. Without a **Liquidity Sweep** of the lower value areas or a high-velocity displacement above tactical resistance, there is no mathematical edge for a strike. We remain in a state of observation, awaiting a "Deep Discount" entry or a volatility catalyst.


---


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading

**Market Structure (Dual-Anchor Protocol)**

*   **Institutional Trend**: Bullish (Confirmed **BOS** at `$8.44`).
*   **Macro Ceiling (Absolute High)**: `$13.67` — The cycle resistance peak established within the Bearish Order Block.
*   **Tactical Displacement Pivot**: `$10.40` — The local hurdle required to ignite a momentum breakout.
*   **Current Zone**: **Premium** (Relative to the institutional accumulation zone).


**Institutional Footprint (SMC)**

*   **Bullish Order Block**: `$7.34` - `$8.16` — Primary zone of interest for institutional long-side defense.
*   **Bullish Fair Value Gap (FVG)**: `$9.58` - `$10.10` — Acting as temporary overhead resistance and a magnet for mean reversion.
*   **Liquidity Pool**: `$8.25` — Significant Sell-Side Liquidity sitting just below the 5-day **Value Area Low (VAL)**.


---


# 4. Mathematical Hurdle (Sortino)

*   **Day Trading Sortino**: `0.68`
*   **Status**: **FAIL** (Hurdle: $\ge$ `2.0`)
*   **Downside Deviation**: `0.71%`
*   **Metric Analysis**: The risk-adjusted return profile is currently toxic for a Sniper execution. The downside volatility is outpacing reward potential within the current compressed range.


---


# 5. Execution Parameters (The Sniper Path)

Should the technical structure shift to align with a **STRIKE** authorization, the following parameters are pre-defined:

*   **Execution State**: **WAIT** (Pending Liquidity Sweep)
*   **Strike Zone (Entry)**: `$8.45` - `$8.75` (Deep Discount near 5d **VAL**)
*   **Hard Stop**: `$8.15` (Structural invalidation below the Bullish Order Block)
*   **Risk Unit (R)**: `0.5R` (Scout sizing authorized due to low Sortino)
*   **Share Quantity**: `833` Shares
*   **Target (Initial)**: `$10.40` (Tactical Pivot)


---


# 6. Risk Guardrails

*   **Daily Stop (Account Level)**: `3R`
*   **Kill Switch (Ticker Level)**: `$8.15` — A breach of this level invalidates the Bullish Macro thesis.
*   **RVOL Baseline**: `1.2` (Institutional Accumulation Requirement).
*   **Tactical Note**: KYTX is "trading in the middle" of its 5-day range. For a **SNIPER**, entering at the **POC** (`$9.32`) represents poor trade location. We wait for the "Sweep and Recover" at the `$8.25` liquidity level or a definitive break above the macro ceiling. **Patience is the weapon.**