> **Generated:** Monday, May 04, 2026 at 09:48 AM

Active Strategy: War barbell Strategy

# 1. EXECUTION SUMMARY

**STRIKE AUTHORIZED**

MOV (Movado Group) is currently presenting as a high-conviction **Sword** position within our War Barbell framework. The ticker has successfully transition from a value accumulation phase into an institutional expansion, confirmed by a Macro Break of Structure (BOS) at `$25.85` and a reclamation of its 200-day moving average. The technical tape shows a "Return to Value" pullback today, offering an asymmetric entry point near the tactical displacement pivot.

The mathematical profile is exceptionally strong for an equity in the retail/luxury sector. With a **Sortino Ratio** of `3.03`, the asset demonstrates that its volatility is overwhelmingly positive, providing the **Shield** characteristics required for our IRA-constrained risk mandate. Despite minor sector-wide headwinds, MOV's specific institutional footprints—including insider confidence and licensing strength—suggest a high probability of a run toward the `$29.24` macro ceiling.

---

# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

The fundamental narrative for MOV is shifting from "Undervalued Retail" to "Growth Rebound," supported by the following institutional catalysts:

*   **MarketBeat (7d ago)**: "Movado Group (NYSE:MOV) Stock Price Passes Above 200 Day Moving Average." Analysts note a "Moderate Buy" consensus as technical momentum shifts bullish.
*   **Ad Hoc News (6d ago)**: "Why its luxury watch positioning matters more now." Synthesis suggests MOV's focus on "accessible high-end" products is capturing market share during the current economic pivot.
*   **Stock Titan (8d ago)**: "CEO Efraim Grinberg exercises 100,000 options." A significant insider signal, resulting in a net share increase despite tax-withholding disposals.
*   **Ad Hoc News (10d ago)**: "Licensing Strength Powers Movado Amid Luxury Watch Slowdown." Strength in the Tommy Hilfiger licensing model provides a stable revenue floor.
*   **Social Sentiment**: Sentiment on professional boards is cautiously bullish, focusing on the `$26.00` support level as a key institutional floor. There is negligible retail "meme" noise, indicating the current move is driven by "Smart Money" accumulation.

---

# 3. STRUCTURAL AUDIT & SMC TAPE READING

**Bias: Bullish (Multi-Timeframe Alignment)**

*   **Macro Map (1d)**: Institutional Trend is confirmed **Bullish** following the BOS at `$25.85`.
*   **Tactical Map (1h)**: Price is currently respecting a Bullish Order Block (OB) between `$23.21` and `$24.10`. 
*   **The Gap**: A Bullish Fair Value Gap (FVG) exists between `$28.46` and `$28.64`, acting as a price magnet for the next expansion leg.
*   **Liquidity Profile**: A successful **Liquidity Sweep** occurred at `$27.59`. Today's price action at `$27.12` represents a search for internal liquidity before the next "Strike" upward.

---

# 4. MATHEMATICAL METRICS (GROUND TRUTH)

*   **Sortino Ratio**: `3.03` (Exceeds `2.0` Hurdle)
*   **Day Trading Downside Deviation**: `0.42%`
*   **Volatility (ATR 5m)**: `$0.10`
*   **Relative Strength**: Outperforming the broader luxury index; trading above the Macro POC of `$24.63`.

---

# 5. EXECUTION PARAMETERS

**STRIKE Authorization Details**

*   **Strike Zone (Entry)**: `$26.85` – `$27.15`
*   **Hard Stop**: `$26.15` (Placed strictly below the 5-day VAL and internal structural low).
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` shares
*   **Primary Target (Macro Ceiling)**: `$29.24`
*   **Trailing Mechanism**: Once price hits `1R` profit (`$28.10`), engage a trailing stop based on the 5-minute 9 EMA.

---

# 6. RISK GUARDRAILS & PORTFOLIO BALANCE

*   **The Sword**: MOV is allocated as a momentum "Sword" with a `3:1` RR potential.
*   **The Shield**: The high Sortino Ratio serves as the "Shield," ensuring that we are not entering a "falling knife" but rather a controlled institutional pullback.
*   **Kill Switch**: A daily close below `$25.85` (the Tactical Displacement Pivot) invalidates the setup. 
*   **Profit Taking**: Scale `50%` of the position at `$29.00` to lock in gains before the macro resistance at `$29.24`. Keep the remainder "Free" to ride the trend using the 5-min EMA anchor.