> **Generated:** Thursday, May 07, 2026 at 11:00 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**SCOUT Authorized**

TSSI is exhibiting a high-velocity recovery profile, currently trading at `$16.47`, which is notably above the institutional Change of Character (`CHoCH`) level of `$15.51`. While the macro-trend was flagged as bearish due to that structural pivot, the fact that price has reclaimed and held above the `$15.51` mark suggests a "Failed Bearish Expansion"—a high-probability setup for Snipers looking for a squeeze back toward cycle highs.

The decision to authorize a **SCOUT** entry rather than a full **STRIKE** is dictated by the fragmented alignment between the daily bearish structure and the intraday bullish momentum. We are entering a "Probing Zone" to test institutional demand at the Tactical Value Area High (`VAH`). With a **Sortino Ratio** of `2.84`, the stock comfortably clears our internal risk-adjusted hurdle of `2.0`, confirming that recent volatility has been skewed heavily toward the upside.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: Neutral-Bullish (Reclaiming structural pivots).


*   **Market Structure**: 
    *   **Macro Pivot**: `$15.51` (Previous CHoCH, now acting as polarized support).
    *   **Tactical Ceiling**: `$17.38` (External buy-side liquidity).
    *   **Value Area (Tactical)**: High (`$15.89`) / Low (`$13.84`).


*   **Volume Profile Footprint**:
    *   **Macro POC**: `$11.91` (Heavy accumulation floor).
    *   **Tactical POC**: `$14.64` (High-frequency institutional fair value).
    *   **Efficiency**: The gap between `$16.47` and the Tactical `VAH` of `$15.89` represents a "Low Volume Node" that must be tested before further expansion.


*   **Asset Classification**: **SWORD**. This is a high-alpha growth equity requiring precision timing and active management.


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Day Trading Sortino Ratio.
*   **Result**: `2.84` (**PASS**).
*   **Insight**: The downside deviation is remarkably low at `0.52%`. This indicates that the current price action is orderly; institutions are not "dumping" into the bid, but rather providing liquidity for a measured move higher.


---


# 5. Execution Parameters (SNIPER)

*   **Strategy Mode**: Sniper (Precision Probe).


*   **Strike Zone (Entry)**: `$16.15` (Wait for a 5m pull-back to test the upper edge of the Value Area).


*   **Hard Stop**: `$15.40` (Placed strictly below the Bullish `FVG` and the `$15.51` structural level).


*   **Risk Unit (R)**: `$125` (Reduced 0.5R for Scout deployment).


*   **Share Quantity**: `166` Shares.


*   **Target (4:1 RR)**: `$19.15` (Initial expansion target).


---


# 6. Risk Guardrails

*   **Daily Stop-Loss**: If the session loss exceeds `$750` (`3R`), all TSSI positions must be liquidated and the terminal locked.


*   **Psych Reset**: This is a Scout trade. If the stop at `$15.40` is hit, do not re-enter. Revert to observation until a new institutional accumulation block forms.


*   **Scale-In Protocol**: Authorized to add another `0.5R` (to reach a full `1R` Strike) only if the first unit is at break-even and price clears `$16.80` with `RVOL > 2.0`.