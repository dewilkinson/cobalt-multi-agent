> **Generated:** Friday, May 08, 2026 at 10:27 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**Execution Authorization**: **SCOUT Authorized** `(0.5R)`


**JBIO** (Jade Biosciences) has successfully transitioned into a post-merger "Price Discovery" phase following its merger with Aerovate Therapeutics and a significant `$300M` private placement. The asset has definitively cleared its Macro Structural Ceiling of `17.50`, confirming a high-conviction Break of Structure (**BOS**). 


While the **Sortino Ratio** of `5.34` comfortably clears our institutional hurdle of `2.0`, the current volatility and proximity to the recent reverse split necessitate a **SCOUT** entry. We are probing the momentum with a half-sized unit to mitigate "gap-and-crap" risk common in biotech corporate actions, looking to scale into a full **STRIKE** if the `$25.30` Point of Control (**POC**) holds on a retest.


---


# 2. Institutional News & Social Sentiment


*   **Jade Biosciences Completes Merger with Aerovate & $300M Private Placement** (GlobeNewswire, 4h ago): The combined entity now operates under the ticker **JBIO** with significant capital reserves to fund its biologics pipeline.
*   **Timothy Noyes Appointed as CEO** (GlobeNewswire, 5h ago): Appointment of a veteran biotech executive signals a shift toward professional clinical execution.
*   **Aerovate Stockholders Approve 1-for-35 Reverse Stock Split** (Investing.com, 8h ago): The split has effectively tightened the float, increasing the stock's sensitivity to institutional buy-side pressure.
*   **RTW Biotech Opportunities Highlights Jade Merger** (QuotedData, 6h ago): Strong backing from RTW Biotech reinforces institutional "Smart Money" commitment to the asset.


**Social Sentiment Synthesis**: Sentiment is predominantly Bullish across Twitter and Reddit's biotech communities, centered on the `$300M` cash infusion which effectively provides a "fundamental floor" significantly higher than the previous shell value.


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish** (Confirmed via Apex 500 Scanner).
*   **Macro Structure**: **BOS** at `17.5050` (Reclaiming levels prior to the Phase 2 trial failure).
*   **Value Area Metrics**:
    *   **VAH (Value Area High)**: `28.05`
    *   **POC (Point of Control)**: `25.30`
    *   **VAL (Value Area Low)**: `21.32`
*   **Order Blocks**: 
    *   **Bullish Accumulation Zone**: `12.91` - `13.99`
    *   **Immediate Support (FVG)**: `25.05` - `25.50` (Reclaimed/Mitigated).
*   **Institutional Footprint**: The high concentration of volume at `25.30` indicates the level where private placement participants and post-merger institutions are anchoring their cost basis.


---


# 4. Mathematical Hurdle (Sortino)


*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `5.34`
*   **Status**: **PASS**
*   **Rationale**: The downside deviation is remarkably low at `0.84%` relative to the current `+9.37%` intraday gain. This indicates that the current move is driven by steady accumulation rather than erratic retail volatility.


---


# 5. Tactical Execution: The Sniper Path


*   **Execution State**: **SCOUT Authorized**
*   **Execution Parameters**:
    *   **Risk Unit (0.5R)**: `$125`
    *   **Strike Zone (Entry)**: `$26.61`
    *   **Hard Stop**: `$25.00` (Placed below the session POC and FVG magnet)
    *   **Share Quantity**: `77 Shares`
    *   **Sniper Target**: `$33.05` (`4:1` RR)


---


# 6. Risk Guardrails


*   **Daily Risk Limit**: Do not exceed `3R` total drawdown.
*   **Kill Switch**: A 5-minute candle close below `$24.38` (Session VAL) invalidates the momentum narrative and requires an immediate exit.
*   **Scale-In Protocol**: Add remaining `0.5R` (to reach full **STRIKE** status) only if price retests `$25.50` and shows a "Spring" or aggressive buy-back on the 1-minute tape.
*   **Volatility Warning**: Be advised of the tightened float due to the `1-for-35` split; spreads may widen during low-volume mid-day periods. Close laggards by `3:55 PM ET` if price is hovering near entry.