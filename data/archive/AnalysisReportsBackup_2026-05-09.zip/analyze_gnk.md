> **Generated:** Friday, May 08, 2026 at 10:21 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


Genco Shipping & Trading (**GNK**) has cleared the tactical Sniper hurdle with a Sortino Ratio of `2.25`, confirming high risk-adjusted momentum efficiency. The technical structure confirms institutional accumulation, characterized by a clean Break of Structure (**BOS**) at `24.81` on the Macro map. Price action is currently sustaining above the `25.24` liquidity sweep, indicating strong buy-side absorption. 


The fundamental landscape provides a significant "Sword" catalyst through a high-stakes proxy battle and an unsolicited tender offer from Diana Shipping at `$23.50`, effectively establishing a hard floor for institutional valuation. Combined with a Q1 earnings beat and a dividend doubling to `$0.70`, the stock is positioned for a high-probability volatility expansion toward the `$28.00` psychological level.


---


# 2. Institutional News & Social Sentiment


*   **Genco Shipping (GNK) backs $23.50 tender, nominates six directors** (Source: Stock Titan - Recent)
*   **Earnings call transcript: Genco Shipping beats Q1 2026 forecasts** (Source: Investing.com - Recent)
*   **Genco doubles dividend, projects $0.70 next payout as fleet grows** (Source: Stock Titan - Recent)
*   **Genco Shipping & Trading (NYSE:GNK) to Issue $0.35 Quarterly Dividend** (Source: MarketBeat - Recent)
*   **Genco Faces Intensified Control Contest As Diana Pushes Cash Offer** (Source: Sahm - Recent)


**Sentiment Synthesis**: 
The prevailing institutional narrative is highly aggressive. The intersection of a "value backstop" (tender offer) and "growth momentum" (earnings beat/dividend hike) has created a rare consensus among smart money participants. Social sentiment reflects a "buy-and-hold" interest for the dividend yield, while institutional desks are focused on the fleet renewal strategy and governance contest.


---


# 3. Execution Parameters


*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$25.50` - `$25.65`
*   **Share Quantity**: `238 Shares`
*   **Hard Stop**: `$24.60`
*   **Target 1 (3R)**: `$28.80`
*   **Sortino Hurdle**: `2.25` (PASS)


---


# 4. Structural Audit & Tape Reading


**Bias**: **Bullish (Structural Expansion)**


*   **Institutional Footprint**:
    *   **Macro POC (60d)**: `$23.94` (Primary Support)
    *   **Macro VAH (60d)**: `$24.45` (Breakout Validation)
    *   **Tactical POC (5d)**: `$24.35`
*   **SMC Technicals**:
    *   **Break of Structure (BOS)**: Confirmed at `24.81`.
    *   **Bullish FVG**: Identified between `24.64` and `24.90`. This acts as the "safety net" for the current move.
    *   **Liquidity Sweep**: Internal sell-side liquidity at `25.24` was successfully swept and reclaimed, confirming buyer dominance.
*   **Volatility (ATR)**: `0.81`. The current stop-loss at `$24.60` provides over `1.2x` ATR protection, aligning with institutional noise-filtering protocols.


---


# 5. Mathematical Hurdle (Sortino)


| Metric | Value | Status |
| :--- | :--- | :--- |
| **Day Trading Sortino** | `2.25` | **PASS** |
| **Downside Deviation** | `0.48%` | **STABLE** |
| **RVOL** | `1.2` (Estimated) | **ACTIVE** |


The Sortino Ratio of `2.25` exceeds the institutional Sniper requirement of `2.0`. This indicates that for every unit of "bad" volatility (downside risk), the stock is generating more than double that in upside performance, justifying a **STRIKE** authorization.


---


# 6. Risk Guardrails


*   **Kill Switch**: A daily close below `$24.45` (Macro VAH) invalidates the breakout thesis. If this occurs, the position must be liquidated immediately to preserve capital.
*   **Sword/Shield Balance**: **GNK** currently acts as a "Sword" due to its momentum profile. In the event of a VIX spike above `26`, this position should be reduced to a **SCOUT (0.5R)** size of `119 Shares`.
*   **Profit Protection**: If price reaches `2R` (`$27.75`), move the Hard Stop to Break-Even (`$25.65`).