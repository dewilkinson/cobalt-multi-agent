> **Generated:** Thursday, May 07, 2026 at 10:40 AM

Active Strategy: Sniper Strategy

# 1. Execution Summary

**Execution Authorization**: **STRIKE Authorized**

The analysis of **RAPP** (Rapport Therapeutics, Inc.) confirms a high-velocity **"Sword"** setup characterized by institutional accumulation and a definitive structural breakout. The primary catalyst is the robust Phase 2a clinical data for RAP-219, which has shifted the market narrative from speculative to value-expansion. Technically, the ticker has completed a Change of Character (**CHoCH**) at `$29.49`, transitioning from a range-bound environment to a bullish trend.

Current price action at `$38.04` shows the stock is holding above the tactical Point of Control (**POC**), suggesting that "Smart Money" is defending recent gains. With a **Sortino Ratio** of `2.73`, the risk-adjusted return profile meets our institutional hurdle of `2.0`. We are authorizing a **Sniper** entry to capture the impending liquidity sweep above the `$40.92` cycle high, utilizing a tight momentum stop to maintain a high Reward-to-Risk ratio.


---


# 2. Institutional News & Social Sentiment

*   **Rapport Therapeutics (RAPP) Receives Consensus "Buy" Rating** (MarketBeat) – *8d ago*
    Brokerage consensus remains overwhelmingly bullish with an average 12-month price target of `$54.83`, implying significant upside from current levels.


*   **BTIG Research Reaffirms "Buy" Rating, Target $53** (MarketBeat) – *14d ago*
    Institutional analysts point to the sustained seizure control results (90% reduction) as a primary driver for mid-term valuation expansion.


*   **Rapport Therapeutics Advances RAP-219 Post Phase 2a Success** (The Globe and Mail) – *Recent*
    Clinical follow-up data demonstrates a favorable tolerability profile, solidifying the fundamental "Sword" thesis for growth-oriented portfolios.


*   **Third Rock Ventures Executes Rule 10b5-1 Sale of $17.1M** (Investing.com) – *20d ago*
    While insider selling of `426,005` shares occurred, the price action has absorbed this liquidity without breaking structural support, indicating strong underlying demand.


**Social Sentiment Synthesis**:
Sentiment on specialized clinical forums and financial social media remains **Bullish**. The narrative is focused on the "best-in-class" potential of RAP-219. Retail "shakeouts" following a slight EPS miss have been aggressively bought by institutional participants, as evidenced by the rising Value Area.


---


# 3. Execution Parameters

*   **Execution State**: **STRIKE** (Standard 1R Deployment)
*   **Share Quantity**: `250`
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$38.04`
*   **Hard Stop**: `$37.04`
*   **Target (Liquidity Sweep)**: `$41.00`+


---


# 4. Quantitative Analysis & Structural Audit

### **MARKET STRUCTURE (SMC)**

*   **Macro Bias**: **Bullish** (Confirmed by **CHoCH** at `$29.49`).
*   **Institutional Order Block**: Deep support sits between `$26.01` and `$27.95`.
*   **Fair Value Gaps (FVG)**: A previously bearish FVG at `$33.71` – `$34.94` has been reclaimed and is now acting as a support shelf.
*   **Liquidity Pools**: Major buy-side liquidity resides at `$40.92` (Session High).


### **VOLUMETRIC CONFLUENCE**

*   **Macro POC (60d)**: `$29.46` (The base of the current institutional move).
*   **Tactical POC (5d)**: `$36.29` (Value has migrated significantly higher).
*   **Value Area High (VAH)**: `$37.70`.
*   **Value Area Low (VAL)**: `$32.87`.
*   **Analysis**: Price is currently trading above both the Macro and Tactical POCs. Trading above the Tactical **VAH** of `$37.70` indicates a state of "Price Discovery" or momentum expansion.


### **RISK & VOLATILITY METRICS**

*   **Sortino Ratio**: `2.73` (Institutional Pass; Hurdle `2.0`).
*   **ATR (5m)**: `0.76` (Used to calibrate the tight momentum stop).
*   **RVOL**: Higher than `1.2` (Institutional participation confirmed).


---


# 5. Risk Guardrails

*   **Primary Kill Switch**: A daily close below `$36.29` (Tactical POC) invalidates the momentum thesis and requires an immediate exit.
*   **Sword Management**: As a high-alpha "Sword" position, RAPP is sensitive to macro biotech volatility (XBI). If the VIX exceeds `26`, revert to a **Scout** (0.5R) sizing for any additions.
*   **Profit Taking**: Scale out `50%` of the position at `$40.90` (just below the cycle high) and move the stop to Breakeven for the remainder to target the consensus objective of `$53.00`.