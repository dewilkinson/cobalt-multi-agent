> **Generated:** Monday, May 04, 2026 at 06:55 AM

Active Strategy: Sniper Strategy


# SNIPER EXECUTION REPORT: OMDA (Omada Health, Inc.)

**DATE**: `May 04, 2026`  
**STATUS**: **STRIKE AUTHORIZED**


---


### 1. Execution Summary

**STRIKE Authorized**. **OMDA** has cleared the institutional **Sniper Strategy** hurdles with a dominant **Sortino Ratio** of `3.90` and a confirmed Bullish **CHoCH** (Change of Character) on the 5-minute scope. Price has successfully reclaimed the **Tactical Displacement Pivot** at `$15.10` and performed a clean Liquidity Sweep at `$15.45`, signaling that "Smart Money" has cleared out retail stops before the next leg up. 

The rationale for this strike is a high-confluence intersection of technical structure and fundamental "wind." With multiple analyst upgrades (Citizens at `$18`, Morgan Stanley at `$30`) and a positive study regarding GLP-1 weight loss preservation, the stock is exhibiting superior **Relative Strength (RS)**. We are entering this "Sword" position to capture momentum leading up to the May 7 earnings event, while maintaining a strict exit protocol to preserve the portfolio's Sortino integrity.


---


### 2. Institutional News & Social Sentiment

*   **Omada Health outlines 2026 proxy and director elections** (Stock Titan) | `3h ago`
    > Details released for the June 16 Annual Meeting; re-election of Sean Duffy and Trevor Fetter confirmed. Institutional stability remains a key narrative.
*   **On GLP-1s, Omada members lost more fat and preserved muscle** (Stock Titan) | `8h ago`
    > A 12-week study shows members lost `1.8x` more weight than controls. This "Sword" catalyst is driving digital health outperformance.
*   **Digital Therapeutics Market to Reach $39.52 Billion by 2033** (openPR.com) | `12h ago`
    > Macro tailwinds for the sector are strengthening with a `21.6%` CAGR projected, supporting OMDA's long-term valuation floor.
*   **Omada Health schedules May 7 earnings call** (The Globe and Mail) | `1d ago`
    > First quarter 2026 financial results to be released after market close on May 7. Note: This creates a **Binary Veto** for the swing strategy.
*   **Citizens initiates Omada Health with "Market Outperform"** (Seeking Alpha) | `2d ago`
    > Analyst Constantine Davides set an `$18` price target, citing a "compelling risk-reward profile."

**Social Sentiment**: Highly Bullish. Conversations on Twitter/X and Reddit indicate retail is following the institutional lead on the "GLP-1 companion" narrative, increasing liquidity for our exit.


---


### 3. Structural Audit & Tape Reading

*   **Macro Bias**: Bullish (MTF Alignment with BOS at `$15.10`).
*   **Market Structure (Dual-Anchor Protocol)**:
    *   **Macro Ceiling (Absolute High)**: `$17.47` (Target for Cycle Expansion).
    *   **Tactical DP (Displacement Pivot)**: `$15.10` (Reclaimed/Support).
*   **Institutional Footprint**:
    *   **Bullish Order Block (OB)**: `$11.19` – `$11.99` (Macro Anchor).
    *   **Execution Order Block (5m)**: `$15.07` – `$15.37` (The Sniper Nest).
    *   **Fair Value Gaps (FVG)**: Bullish gaps reside at `$14.41` and `$14.37`, acting as structural magnets if the pivot fails.
*   **Volume Profile**: 
    *   **POC (Point of Control)**: `$14.02`.
    *   **VAH (Value Area High)**: `$15.97`.
    *   **RVOL**: `> 1.5` (Institutional Intent Confirmed).


---


### 4. Mathematical Hurdle

*   **Metric**: Day Trading Sortino Ratio.
*   **Hurdle**: `S >= 2.0`.
*   **Current Result**: `3.90` (**PASS**).
*   **Risk Note**: Downside deviation is remarkably low at `0.54%`, allowing for higher confidence in tight stop placement.


---


### 5. Execution Parameters

*   **Execution State**: **STRIKE** (Full Deployment).
*   **Strike Zone (Entry)**: `$15.15` – `$15.30`.
*   **Hard Stop**: `$14.95` (Below the Tactical DP and 5m OB).
*   **Primary Target**: `$16.35` (`3:1` RR initial).
*   **Risk Unit (R)**: `$250`.
*   **Share Quantity**: `714` Shares.


---


### 6. Risk Guardrails & Safety Protocol

*   **Earnings Veto**: **MANDATORY**. This is a "Sword" position. You must close the full position by **3:55 PM ET on Wednesday, May 6**, regardless of P/L, to avoid the binary risk of the May 7 earnings report.
*   **Trailing Anchor**: Once price reaches `$15.65` (`1R` Profit), move the Hard Stop to **Break-Even**. 
*   **Momo Exit**: Trail the remaining runner using the 5-minute **9 EMA**. Exit on the first full 5-minute candle close below the EMA.
*   **Kill Switch**: If a 5-minute candle closes below `$14.90`, the institutional thesis is invalidated. Exit immediately.


---

**Analyst Note**: OMDA is a high-conviction setup. The reclamation of the `$15.10` Displacement Pivot combined with a `3.90` Sortino Ratio represents an elite institutional entry point. Stick to the stop and honor the Earnings Veto.