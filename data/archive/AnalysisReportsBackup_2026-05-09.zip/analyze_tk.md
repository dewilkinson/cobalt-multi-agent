> **Generated:** Thursday, May 07, 2026 at 10:58 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**SCOUT Authorized**


TK has confirmed institutional bullish intent following a clean Break of Structure (BOS) at `$13.76` on the daily timeframe. The current price of `$13.93` represents a `2.31%` intraday gain, placing the ticker in a "Premium" zone relative to its recent value areas. While the Sortino Ratio of `2.01` meets our institutional hurdle for risk-adjusted returns, the Sniper protocol demands a more disciplined entry to maintain the required `4:1` Reward-to-Risk ratio. 


The lack of a liquidity sweep on the lower timeframes suggests the stock is in a state of institutional accumulation rather than a terminal expansion. Therefore, we authorize a **SCOUT** position (0.5R) to probe for entry on a mean-reversion move toward the 5-day Value Area High (VAH) and the nearest Fair Value Gaps.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


[DATA_UNAVAILABLE]


---


# 3. STRUCTURAL AUDIT & TAPE READING


**INSTITUTIONAL FOOTPRINT**


*   **Institutional Trend**: Bullish (Confirmed by Daily BOS at `$13.76`).
*   **Order Block (Bullish)**: `$10.78` — `$11.11` (Deep structural support).
*   **Fair Value Gaps (FVG)**: 
    *   `$12.96` — `$13.25` (Immediate Magnet)
    *   `$12.66` — `$12.88`
    *   `$12.42` — `$12.57`
*   **Liquidity Sweep**: None detected on 5m; price is currently trending without a "Stop Run," increasing the probability of a corrective pullback before further expansion.


**TECHNICAL METRICS**


*   **ATR (5m)**: `$0.08` (Indicating low-to-moderate tactical volatility).
*   **RVOL**: Current volume of `49,447` is below the Morning Scan requirement of `100,000`, supporting the decision for a reduced-size **SCOUT** entry rather than a full **STRIKE**.
*   **Sortino Ratio**: `2.01` (Hurdle: PASS).


---


# 4. VOLUME PROFILE ANALYSIS


**60-DAY COMPOSITE**
*   **POC (Point of Control)**: `$12.49`
*   **VAH (Value Area High)**: `$13.53`
*   **VAL (Value Area Low)**: `$9.83`


**5-DAY TACTICAL**
*   **POC**: `$12.57`
*   **VAH**: `$13.35`
*   **VAL**: `$12.21`


*Analysis*: Price is currently trading outside the 5-day Value Area, suggesting an "imbalance" phase. Snipers do not chase imbalances; we wait for the retest of the Value Area boundary.


---


# 5. EXECUTION PARAMETERS


*   **Execution State**: **SCOUT** (0.5R Deployment)
*   **Risk Unit (R)**: `$250` (Scout Size: `$125`)
*   **Strike Zone (Entry)**: `$13.35` — `$13.50` (VAH Retest Zone)
*   **Hard Stop**: `$13.25` (Placed below the nearest FVG and 5d VAH)
*   **Share Quantity**: `1,250` shares (Calculated for 0.5R risk: `$125` / `$0.10` risk per share)
*   **Profit Target (Minimum 4:1)**: `$13.90` (Initial Scale)


---


# 6. RISK GUARDRAILS


*   **Daily Stop**: `3R` ($750).
*   **Kill Switch**: Close position immediately if price closes below `$13.25` on a 5m candle.
*   **Slippage Warning**: Given the current session volume of `49,447`, use limit orders exclusively. Do not use market orders to avoid excessive slippage in a low-liquidity environment.