> **Generated:** Friday, May 08, 2026 at 10:16 AM

The institutional scanner has successfully isolated 14 equities clearing the **RVOL > 1.2** and **Phase 2 Sentiment Pulse** thresholds. Current market structure indicates a clear bifurcation between high-efficiency cybersecurity assets and speculative high-volume outliers. The session is characterized by aggressive institutional displacement in **CRWD** and **FSLY**, which currently serve as the primary conviction drivers for the session.


While several assets like **MARA** exhibit extreme relative volume (2.8x), they remain relegated to the **SCOUT** tier due to high downside deviation and poor risk-adjusted return profiles. Conversely, the "F" grade cluster—including **CELH** and **MDB**—has cleared the liquidity and volume hurdles but failed the Sortino efficiency metrics, necessitating a **WAIT** status until price action stabilizes within established value areas.


---


### QUANTITATIVE SCANNER RESULTS


| Symbol | Grade | RVOL | Price | Status |
| :--- | :--- | :--- | :--- | :--- |
| **CRWD** | `A` | `2.4x` | `$509.12` | **STRIKE** |
| **FSLY** | `A` | `2.1x` | `$20.34` | **STRIKE** |
| **PLTR** | `A` | `1.9x` | `$134.36` | **SCOUT** |
| **MARA** | `B` | `2.8x` | `$12.53` | **SCOUT** |
| **IOT** | `B` | `1.6x` | `$29.24` | **SCOUT** |
| **NVDA** | `B` | `1.5x` | `$215.90` | **HOLD** |
| **AMD** | `B` | `1.4x` | `$435.87` | **HOLD** |
| **SOFI** | `C` | `1.4x` | `$15.78` | **HOLD** |
| **TSLA** | `C` | `1.1x` | `$426.22` | **HOLD** |
| **CELH** | `F` | `1.3x` | `$33.46` | **WAIT** |
| **SYM** | `F` | `1.2x` | `$52.21` | **WAIT** |
| **PATH** | `F` | `1.1x` | `$10.45` | **WAIT** |
| **MDB** | `F` | `1.0x` | `$287.46` | **WAIT** |
| **RBLX** | `F` | `0.9x` | `$42.65` | **WAIT** |


---


### ASSET PERFORMANCE & EFFICIENCY


*   **High-Conviction Leads**: **CRWD** and **FSLY** are the standout performers, maintaining Sortino Ratios of `2.64` and `2.01` respectively. Their institutional footprint is confirmed by significant price-volume synchronization.


*   **Momentum Discovery**: **PLTR** and **IOT** show promising entry signals with **SCOUT** designations. **IOT** maintains a respectable Sortino of `1.5`, while **PLTR**'s high RVOL of `1.9x` suggests an impending breakout despite missing specific risk-adjusted data.


*   **Efficiency Laggards**: A significant portion of the universe (**SYM**, **PATH**, **MDB**, **CELH**) demonstrates negative Sortino Ratios, ranging from `-0.05` to `-2.54`. Despite passing the scanner's volume threshold, these tickers lack the structural integrity required for active execution.


*   **Data Exceptions**: Historical efficiency metrics (Sortino) for **NVDA**, **TSLA**, **AMD**, **PLTR**, **SOFI**, and **MARA** are currently `[DATA_UNAVAILABLE]` due to retrieval timeouts. Analysis for these symbols relies on raw price and volume metrics.


---


### EXECUTION PARAMETERS


*   **Strategy Lead**: Hybrid Momentum.


*   **Execution Status**: Targets acquired via SMC signature check.


*   **Exit Strategy**: Trim `50%` of position at `2R` (Risk Multiple). Trail the remaining position using a `5m 9EMA` to maximize capture during trend extension.


*   **Risk Parameters**:
    *   **Share Quantity**: `[DATA_UNAVAILABLE]`
    *   **Risk Unit**: `[DATA_UNAVAILABLE]`
    *   **Strike Zone (Entry)**: `[DATA_UNAVAILABLE]`
    *   **Hard Stop**: `[DATA_UNAVAILABLE]`


*   **System Note**: Background analysis orchestrator has been manually triggered to resolve stale data reports for missing parameters.