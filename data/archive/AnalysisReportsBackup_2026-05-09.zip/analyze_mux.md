> **Generated:** Friday, May 08, 2026 at 04:14 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**WAIT (Retain Cash)**


The technical structure for `MUX` remains bullish on a macro horizon following the confirmed Break of Structure (BOS) at `$24.88`, positioning the asset as a high-beta "Sword" for the portfolio. However, the current setup fails the strict **Sniper Strategy** mathematical filters. Specifically, the Sortino Ratio of `1.28` sits significantly below our institutional requirement of `2.0`, indicating that downside volatility is currently uncompensated.


Furthermore, price action is currently trapped in a "Premium" zone relative to the nearest bullish Fair Value Gaps (FVG) and is trading below the Macro Value Area High (VAH) of `$25.20`. A Sniper strike requires a high-velocity expansion; until the price clears the institutional supply overhead at `$24.88` — `$25.20` with an improved risk-adjusted profile, capital remains sidelined to preserve the `$250` Risk Unit.


***


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


***


# 3. Structural Audit & Tape Reading


*   **Institutional Trend**: Bullish (Macro BOS confirmed at `$24.88`).


*   **Market Structure**:
    *   **Macro Ceiling**: `$28.70` (Bearish Order Block).
    *   **Displacement Pivot**: `$24.88` (Immediate resistance/BOS level).
    *   **Institutional Magnet**: `$21.37` — `$22.26` (Bullish FVG).


*   **Volume Profile Analysis**:
    *   **60d Macro POC**: `$18.95`.
    *   **Macro VAH**: `$25.20`.
    *   **5d Tactical POC**: `$23.48`.


*   **Tape Synthesis**: The asset is currently in an accumulation phase after a `-4.04%` daily move. While the trend is technically intact, the lack of a liquidity sweep at the `$5m` timeframe suggests the market is not yet ready for a high-conviction displacement.


***


# 4. Mathematical Hurdle (Sortino)


*   **Metric**: Sortino Ratio ($S_{DR}$)


*   **Current Value**: `1.28`


*   **Hurdle Status**: **FAIL** (Required: `2.0`)


*   **Risk Note**: The current downside deviation of `0.49%` is too high relative to the projected alpha. The Sniper protocol demands efficient volatility; `1.28` suggests a "noisy" environment where stops are likely to be hunted before the target is reached.


***


# 5. Execution Parameters (Contingent)


*Tactical parameters below are only authorized if price clears the Strike Zone and the Sortino Ratio scales to `2.0`.*


*   **Execution State**: **WAIT**


*   **Strike Zone (Entry)**: `$25.25` (Breakout confirmation above Macro VAH).


*   **Hard Stop**: `$24.17` (Below intraday POC).


*   **Risk Unit (R)**: `$250`.


*   **Share Quantity**: `231` Shares.


*   **Target (4:1 RR)**: `$29.57`.


***


# 6. Risk Guardrails


*   **Daily Stop**: `3R` (`$750`).


*   **Kill Switch**: A violation of the `$23.40` level (5-day POC) invalidates the bullish thesis and requires immediate liquidation of any "Sword" exposure in this ticker.


*   **Tactical Guidance**: `MUX` is technically constructive but mathematically inefficient. We await a volatility contraction followed by a clear institutional expansion above `$25.20`. Until the Sortino hurdle is cleared, no capital is authorized for deployment.