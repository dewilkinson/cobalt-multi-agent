> **Generated:** Friday, May 08, 2026 at 10:30 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**Execution Authorization**: **WAIT** (Retain Cash)


KODK has entered a high-velocity tactical distribution phase, evidenced by the `-7.03%` intraday flush. While the macro structure remains bullish (CHoCH at `$7.97`), the mathematical efficiency has collapsed. With a **Sortino Ratio** of `0.12`, the asset fails the institutional risk hurdle (Target `> 2.0`). A Sniper does not fire into a high-volatility vacuum without a confirmed structural floor. We are observing aggressive institutional offloading as price slices through the 60-day Value Area High (VAH) of `$11.35`.


The current price action represents a "Broken Sword"—volatility is expanding to the downside, neutralizing the growth premium. We await a stabilization of the downside deviation before authorizing deployment.


***


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


***


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: Neutral-Bearish (Tactical Distribution)


*   **Macro Map (1d)**: Institutional Trend remains Bullish due to the Change of Character (CHoCH) at `$7.97`. However, current price is in a "Premium" zone, far extended from the Macro Point of Control (POC) of `$7.64`.


*   **Tactical DP (Displacement Pivot)**: `$12.73` — The 5-day POC is now acting as heavy overhead supply. Any rally into this zone is likely to be met with further selling.


*   **Institutional Footprint**:
    *   **Bearish FVG**: `$11.99` — `$13.91` (This imbalance acts as a magnet for mean reversion but heavy resistance for trend continuation).
    *   **Primary Order Block (Bullish)**: `$6.41` — `$6.83` (The "Shield" zone where institutional accumulation is mathematically most likely).
    *   **Liquidity Gap**: Sell-Side Liquidity (SSL) is resting at `$10.28`. A "Sniper" entry requires a sweep of this level to clear weak retail hands.


***


# 4. Mathematical Hurdle (Sortino)

*   **Hurdle Result**: **FAIL**
*   **Current Sortino**: `0.12`
*   **Downside Deviation**: `0.55%`


**Analysis**: The realized return is not compensating for the current downside volatility. Under the **Sniper Strategy**, we require a Sortino `> 2.0` to ensure we are trading high-probability efficiency. Engaging now would violate our institutional risk mandate.


***


# 5. Execution Parameters (The Sniper Path)

*The following parameters are authorized only upon a 5m Liquidity Sweep of `$10.28` and a subsequent Break of Structure (BOS) back above `$11.00`.*


*   **Strike Zone (Entry)**: `$10.50`
*   **Hard Stop**: `$9.50`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` shares
*   **Target (Minimum 4:1 RR)**: `$14.50`


***


# 6. Risk Guardrails

*   **Daily Stop (Account Level)**: `3R` (`$750`)
*   **Kill Switch**: A daily close below `$7.97` (Macro CHoCH Invalidation) nullifies the bullish thesis entirely.
*   **Volatility Warning**: ATR is currently `0.97`. Do not tighten stops within `1 ATR` of the entry price to avoid "market noise" stop-outs. 
*   **Strategy Note**: KODK is currently a "Sword" that has lost its edge. We wait for the target to stop moving and for the Sortino to stabilize before re-evaluating for a **STRIKE** authorization.