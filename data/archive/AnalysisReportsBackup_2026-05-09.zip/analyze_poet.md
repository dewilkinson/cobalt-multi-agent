> **Generated:** Wednesday, May 06, 2026 at 09:50 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**STRIKE Authorized**


**POET** has triggered a high-conviction **Sniper** entry following a structural Change of Character (**CHoCH**) at the `$8.27` level. The asset has successfully cleared its primary tactical resistance and is now operating in a "Low-Volume Node" expansion zone. With a **Sortino Ratio** of `2.98`, the ticker demonstrates exceptional downside protection and institutional support, far exceeding our mandatory `2.0` hurdle.


The current price action represents a classic "Sword" deployment. The reclaim of the `$8.86` **Value Area High (VAH)** suggests that the market has transitioned from value-accumulation to momentum-driven displacement. Total volume of `22,287,711` shares confirms significant institutional intent, as the "Smart Money" aggressively fills the bearish **Fair Value Gap (FVG)** extending toward the `$12.40` ceiling.


---


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


---


# 3. Technical & SMC Audit

**Institutional Footprint & Structure**
*   **Market Bias**: **Bullish** (Confirmed by MTF Alignment Scan).
*   **Macro Pivot (CHoCH)**: `$8.27` (Reclaimed and Verified).
*   **Tactical Displacement**: Price is currently entering a massive daily **Bearish FVG** between `$8.84` and `$12.40`. In SMC, this serves as a price "magnet" during bullish expansions.
*   **Order Block (OB)**: High-conviction Bullish OB located at `$4.87` — `$5.25`. This serves as the ultimate cycle floor.
*   **Liquidity Targets**: Internal buy-side liquidity is currently resting at `$10.18` and `$11.95`.


**Volumetric Analysis**
*   **60-Day Macro POC**: `$7.31`.
*   **5-Day Tactical POC**: `$7.87`.
*   **Current VAH**: `$8.86`.
*   **Analysis**: Trading above all major volume anchors confirms that the path of least resistance is significantly skewed to the upside.


---


# 4. Mathematical Hurdle (Sortino)

*   **Tactical Sortino (20d)**: `2.98`
*   **Downside Deviation**: `0.70%`
*   **Hurdle Status**: **PASS**
*   **Risk Profile**: This "Sword" asset provides top-tier risk-adjusted returns, suggesting that any intraday pullbacks are likely to be absorbed rapidly by institutional dip-buyers.


---


# 5. Execution Parameters

**STRIKE Mandate: High-Fidelity Deployment**

*   **Trade Tier**: **STRIKE** (1.0R Deployment authorized).
*   **Strike Zone (Entry)**: `$9.30` — `$9.56`.
*   **Hard Stop (Kill Switch)**: `$8.20` (Placed strictly below the tactical CHoCH pivot).
*   **Target 1 (1R Trailing Anchor)**: `$10.18`.
*   **Target 2 (Final Liquidity Pool)**: `$11.50` — `$12.00`.
*   **Volatility Expectation (ATR)**: `1.53`.


**Sizing & Risk Management**
*   **Risk Unit (R)**: `$250`.
*   **Share Quantity**: `183` Shares.
*   **Formula**: `$250` / (`$9.56` - `$8.20`).


---


# 6. Risk Guardrails & Strategy Narrative

The trade on **POET** is a momentum-based "Sword" play within the **War Barbell** framework. The primary risk is a structural failure back below the `$8.27` pivot; however, the `2.98` Sortino suggests a very low probability of sustained downside deviation. 


**Active Management**: Engage a **1R Trailing Anchor** immediately upon price hitting `$10.18`. Use the **5-minute 9 EMA** to trail the remaining 25% of the position once the trade is "Free." Exit the entire position at **3:55 PM ET** if price fails to hold the tactical POC.