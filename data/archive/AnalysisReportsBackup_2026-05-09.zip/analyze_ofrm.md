> **Generated:** Friday, May 08, 2026 at 03:45 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**Execution Authorization: WAIT (Retain Cash)**


The **Sniper Protocol** for `AFRM` is currently in a non-execution state. While the asset maintains a high-fidelity **Sortino Ratio** of `3.15` (surpassing our institutional hurdle of `2.0`), the technical structure has suffered a significant **Change of Character (CHoCH)** at the `$60.29` level. Price is currently drifting in a "Premium" zone relative to the quarterly accumulation base, showing intraday weakness of `-4.69%`.


We are observing a tactical mismatch: the macro trend has shifted bearish on the 1D timeframe, yet price has not yet reached a high-probability "Discount" entry or completed a liquidity sweep. To maintain a `4:1` Reward-to-Risk ratio, we must wait for a deeper retracement to the `$61.50` strike zone or a clear reclaim of the tactical Point of Control. Deploying capital at the current price of `$63.86` would constitute "front-running" a move without structural confirmation, violating the Sniper mandate.


---


# 2. Institutional News & Social Sentiment


*   **FMR LLC (Fidelity) 13G Filing (2h ago)**: Disclosed a massive `6.1%` passive stake in `AFRM`, holding over `17.7M` shares. This provides a significant "Shield" baseline of institutional support. [Source: Stock Titan]


*   **Insider Activity - Director Sale (4h ago)**: Director Noel Bertram Watson sold `2,000` shares at `$55.00` under a 10b5-1 plan. While small, it signals a lack of urgency to hold at local peaks. [Source: Investing.com]


*   **COO Equity Vesting (5h ago)**: COO Michael Linford reported RSU vesting with standard tax withholding. This is a neutral "maintenance" event. [Source: Stock Titan]


*   **Director Divorce Settlement (1d ago)**: Director Christa Quarles transferred `53,697` shares to a former spouse. This is a non-market transaction but explains recent filing volume. [Source: Stock Titan]


*   **Sentiment Synthesis**: Social sentiment on Reddit/X remains volatile but leans toward "buy the dip" due to the Fidelity stake news. However, institutional tape reading shows active distribution (selling) as price fails to hold the tactical Value Area High.


---


# 3. Structural Audit & Tape Reading


*   **Institutional Trend**: **Bearish** (Confirmed by CHoCH at `$60.29`)


*   **Volatility (ATR)**: `$0.36` (5m timeframe)


*   **Volume Profile Metrics**:
    *   **Macro POC (60d)**: `$50.07`
    *   **Tactical POC (5d)**: `$64.67`
    *   **Value Area High (VAH)**: `$69.81`
    *   **Value Area Low (VAL)**: `$59.53`


*   **Imbalance Mapping**:
    *   **Bearish FVG**: `$64.20` — `$65.41` (Immediate overhead resistance)
    *   **Liquidity Pool**: `$60.29` (Target for sell-side hunt)


---


# 4. Execution Parameters (The Sniper Path)


*   **Status**: **WAIT** (Pending Liquidity Sweep)


*   **Strike Zone (Entry)**: `$61.50` (Requires a sweep of `$60.29` first)


*   **Hard Stop**: `$60.25`


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `200 Shares`


*   **Target (Exit)**: `$66.50` (Projected `4:1` RR)


---


# 5. Risk Guardrails


*   **Kill Switch**: A daily close below `$60.29` invalidates the current "Sword" setup and shifts the bias to a macro-bearish distribution. 


*   **Psychological Reset**: As per the **CMA Protocol**, if this trade were to trigger and fail, we revert to `0.5R` Scouts. Given the current VIX environment and the bearish CHoCH, the Sniper remains patient. Do not chase the current `-4.69%` move; let the market come to the level.