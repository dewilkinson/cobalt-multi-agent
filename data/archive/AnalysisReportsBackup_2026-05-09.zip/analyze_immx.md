> **Generated:** Friday, May 08, 2026 at 10:24 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**Execution Authorization: WAIT**


**Rationale**: **IMMX** currently displays high-fidelity structural alignment with institutional accumulation, specifically holding near the Session POC of `$9.87`. However, the mathematical efficiency required for a **Sniper** strike is not yet met. The current Sortino Ratio of `1.82` fails the mandatory `2.0` hurdle for institutional deployment. Price is currently navigating a "Thin Air" regime above the Macro VAH, suggesting that while the trend is bullish, the risk-to-reward ratio is suboptimal for an immediate entry. We require a liquidity sweep or a volatility reset before authorizing a strike.


---


# 2. Institutional News & Social Sentiment

*   **Mizuho raises price target to `$15.00`**: Citing a robust cash position of approximately `$100M`, Mizuho analysts have increased their valuation, providing a fundamental floor for the current rally. (Source: *Investing.com*, ~4h ago)


*   **Morgan Stanley Initiates with Bullish View**: Institutional interest peaked following Morgan Stanley’s coverage launch, highlighting the potential of **IMMX**'s CAR-T therapy platform. (Source: *MSN*, ~6h ago)


*   **NEXICART-2 Enrollment Completed**: The company announced the successful completion of patient enrollment for its BLA-enabling trial in AL Amyloidosis, with topline results projected for `Q3 2026`. (Source: *TradingView*, ~2h ago)


*   **Price Target Hikes to `$18.62`**: Multiple analysts have adjusted their expectations upward by over `11%`, signaling high-conviction institutional sentiment. (Source: *MSN*, ~3h ago)


*   **Social Sentiment**: Reddit and Twitter discussions are focused on the "Sword" potential of this biotech play, specifically noting the low float and high relative strength against the `SPY` during session consolidation.


---


# 3. Structural SMC Audit & Tape Reading

*   **Institutional Bias**: **BULLISH** (Confirmed via MTF Apex Alignment)


*   **Key Structural Levels**:
    *   **Daily BOS (Break of Structure)**: `$7.73` (Confirmed institutional trend shift)
    *   **Tactical Displacement Pivot**: `$9.13` (Macro VAH acceleration point)
    *   **Liquidity Pool**: `$10.32` (Session VAH / External Buy-side Liquidity)


*   **Order Flow Imbalances**:
    *   **Bearish FVG**: `$8.81` - `$9.50` (Unfilled gap acting as a downside magnet)
    *   **Bullish FVG**: `$9.03` - `$9.21` (Immediate support zone)


*   **Volume Profile Analysis**:
    *   **Session POC**: `$9.87` (Point of Control)
    *   **Session VAL**: `$9.31` (Value Area Low)
    *   **RVOL**: `> 1.2` (Institutional Accumulation baseline confirmed)


---


# 4. Execution Parameters (Tactical Preparedness)

Should the Sortino Ratio stabilize above `2.0` on a 5-minute liquidity sweep, the following parameters are pre-authorized:


*   **Strike Zone (Entry)**: `$9.87` (Reclaim of Session/Tactical POC)


*   **Hard Stop**: `$9.71` (Momentum invalidation level)


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `1,562` Shares


*   **Anticipated RR**: `4:1` (Targeting `$10.51` for initial scale-out)


---


# 5. Risk Guardrails

*   **Hurdle Check**: Sortino Ratio currently `1.82`. **[FAIL]**


*   **Volatility Check**: ATR (5m) is `$0.11`. High intra-day chop expected near the `$10.00` psychological barrier.


*   **Kill Switch**: A violation of the Session VAL at `$9.31` invalidates the current "Sword" narrative and requires a full psych reset.


*   **Strategy Note**: IMMX is a high-conviction asset, but as a **Sniper**, we do not chase "grinding" price action. We wait for the specific displacement that offers the mathematically superior `4:1` RR. **Maintain cash position.**