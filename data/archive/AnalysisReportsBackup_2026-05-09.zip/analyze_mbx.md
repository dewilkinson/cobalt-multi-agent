> **Generated:** Friday, May 08, 2026 at 01:04 PM

Active Strategy: Sniper Strategy


---


# 1. EXECUTION SUMMARY


**Recommendation**: **SCOUT Authorized**


**Rationale**: MBX is currently in a state of high-velocity price discovery, trading at `$39.37` (`+15.66%`). While the macro structure maintains a trailing bearish CHoCH at `$27.04`, the tactical tape has completely decoupled from historical anchors. The asset presents an elite **Sortino Ratio** of `3.81`, significantly outperforming the Sniper hurdle of `2.0`. 

However, because price is currently trading in "Thin Air" above the 60-day Value Area High (VAH) of `$37.08`, the protocol dictates a **SCOUT** (0.5R) entry. This allows for participation in the momentum while mitigating the risk of a sharp mean-reversion toward the Macro Point of Control (POC).


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


[DATA_UNAVAILABLE]


---


# 3. STRUCTURAL AUDIT & TAPE READING


**Market Structure (Dual-Anchor Protocol)**:


*   **Tactical Bias**: Aggressively Bullish.
*   **Macro Structural Residue**: Bearish (Trend change required above `$44.89`).
*   **Macro VAH**: `$37.08` (Current support-flip candidate).
*   **Macro POC**: `$31.22` (High-density institutional magnet).
*   **Displacement Pivot**: `$34.55` (Upper boundary of Bullish FVG).


**Institutional Footprint**:


*   **Relative Volume (RVOL)**: High institutional participation confirmed by `1,053,591` shares traded pre-midday.
*   **Fair Value Gaps (FVG)**: Major imbalance detected between `$32.33` and `$34.55`.
*   **Order Blocks**: Deep structural demand sits at the `$27.56` - `$29.67` cluster.


---


# 4. MATHEMATICAL HURDLES


*   **Day Trading Sortino Ratio**: `3.81` (**PASS**)
*   **Downside Deviation**: `0.80%`
*   **Volatility (ATR 5m)**: `$0.40`


The Sortino Ratio confirms that for every unit of "bad" volatility, the asset is generating nearly 4 units of excess return. This is a "Sword" archetype configuration suitable for aggressive growth capture.


---


# 5. EXECUTION PARAMETERS


**Position Type**: SCOUT (0.5R)


*   **Strike Zone (Entry)**: `$39.20`
*   **Hard Stop**: `$38.20`
*   **Risk Unit (R)**: `$125`
*   **Share Quantity**: `125` shares
*   **Target (Sniper 4:1 RR)**: `$43.20`


---


# 6. RISK GUARDRAILS


*   **The "Sword" Breach**: If price closes below the `$37.00` handle (60d VAH), the immediate bullish thesis is invalidated. 
*   **Scale-In Rule**: Upgrade from SCOUT to STRIKE (Full 1R) only if the first unit reaches break-even and price secures a 15-minute close above `$40.50` on sustained RVOL.
*   **MOC Exit**: If MBX fails to hold the intraday VAH and market volatility (VIX) spikes, exit all laggards at `3:55 PM ET`.