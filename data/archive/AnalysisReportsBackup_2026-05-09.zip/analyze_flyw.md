> **Generated:** Thursday, May 07, 2026 at 11:16 AM

Active Strategy: Shield Strategy


# 1. Execution Summary

**STRIKE Authorized** (Shield Deployment)


FLYW demonstrates an elite mathematical profile for a **Shield** position, posting a **Sortino Ratio** of `7.54`. This significantly exceeds our institutional hurdle of `2.0`, signaling exceptional downside efficiency. While the macro trend shows a technical transition at the `12.01` level, the tactical volume profile and recent price action confirm that institutional players are defending higher value areas. 


The stock is currently trading in "Thin Air" above its historical value zones, but the internal volatility metrics (ATR `0.09`) suggest a stable, low-variance expansion characteristic of a primary portfolio anchor. We are authorizing a **STRIKE** execution to capture this low-volatility momentum, utilizing a tight structural stop to mitigate the risk of a mean-reversion toward the primary liquidity gaps.


***


# 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]


***


# 3. Structural Audit & Shield Metrics

*   **Primary Bias**: Neutral-Bullish (Shield Rotation)


*   **Sortino Efficiency**: `7.54` (Elite)


*   **Downside Deviation**: `0.40%`


*   **Institutional POC (Macro)**: `12.53`


*   **Tactical POC (5-Day)**: `13.66`


*   **Value Area High (VAH)**: `14.61`


*   **Current Price**: `$17.72`


*   **Relative Strength**: High Alpha vs. Sector baseline.


***


# 4. Technical Map & SMC Footprint

*   **Market Structure**: Bullish expansion confirmed above the `$12.00` handle. Currently testing the macro ceiling at `$17.85`.


*   **Bullish Order Block**: `11.16` — `11.81` (Primary accumulation floor).


*   **Fair Value Gap (FVG)**: `14.58` — `17.26` (Significant institutional imbalance).


*   **Liquidity Pool**: Buy-side liquidity resting at `$17.85`.


***


# 5. Execution Parameters

*   **Execution State**: **STRIKE**


*   **Strike Zone (Entry)**: `$17.40` — `$17.72`


*   **Share Quantity**: `250` Shares


*   **Risk Unit (R)**: `$250`


*   **Hard Stop**: `$16.40`


*   **Daily ATR Expectation**: `$0.09`


***


# 6. Risk Guardrails

*   **Tactical Kill Switch**: A daily close below `$14.50` (Tactical VAH) invalidates the current "Shield" thesis and requires an immediate exit.


*   **Sizing Logic**: Based on the current distance between entry and the structural stop, a `1R` risk allocation ($250) dictates a size of `250` shares. 


*   **Management**: If the price breaks and holds above `$17.85`, we will look to scale to a full `1R` unit if the initial probe reaches break-even, trailing the stop behind the 5-minute ATR clusters.