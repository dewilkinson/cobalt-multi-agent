> **Generated:** Friday, May 08, 2026 at 02:35 PM

Active Strategy: Shield Strategy


# INSTITUTIONAL ANALYST: EXECUTION ENGINE


## 1. Execution Summary

**STRIKE Authorized** (Institutional Shield Expansion)


**Rationale**: USA Rare Earth (USAR) has transitioned from a high-volatility "Sword" to a fundamental "Shield" asset following massive de-risking events, including the `$2.8B` acquisition of Serra Verde Group and first commercial production milestones. The asset has cleared the mandatory institutional hurdle with a **Sortino Ratio of `5.67`**, indicating exceptional risk-adjusted performance. 


**Technical Alignment**: Price action is currently maintaining a bullish posture above the Daily CHoCH at `21.4450` and the Tactical POC at `23.23`. This structural support, combined with high institutional accumulation (RVOL), confirms that the "Shield" is being actively defended by smart money.


---


## 2. Institutional News & Social Sentiment

*   **USA Rare Earth's $2.8B Power Play to Secure the Supply Chain** (TradingView, 4h ago)
    *   *Detail*: Acquisition of Serra Verde Group creates a comprehensive rare earth operation, securing critical global supply chains.


*   **USA Rare Earth, Inc. Reports Material Event [8-K]** (Stock Titan, 6h ago)
    *   *Detail*: Formal merger agreement for SVRE Holdings involving `$300M` cash and `126.85M` newly issued shares.


*   **USAR Jumps on First Commercial Yttrium Metal Production Milestone** (Quiver Quantitative, 1d ago)
    *   *Detail*: Subsidiary Less Common Metals achieved high-purity yttrium production, a key commercial validator.


*   **Bayshore Entities and Tready A. Smith Report 8.66M Shares** (Stock Titan, 2d ago)
    *   *Detail*: Significant institutional ownership disclosure via amended Schedule 13G/A filing.


*   **Social Sentiment**: Reddit and Twitter sentiment is currently **Highly Bullish**. The narrative has shifted from "speculative miner" to "strategic national security play," aligning with the Shield Strategy's focus on low-volatility, high-backing assets.


---


## 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Strongly Bullish** (MTF Alignment)


*   **Market Structure**:
    *   **Macro POC (60d)**: `17.23`
    *   **Tactical POC (5d)**: `23.23`
    *   **Bullish CHoCH (Daily)**: `21.4450`
    *   **Institutional FVG**: `23.69` – `24.16`


*   **Volume Profile Analysis**:
    The tape shows significant "Shield" properties with a massive volume shelf established between `21.75` and `23.23`. Any retracement into the `24.00` zone is being met with immediate institutional absorption, preventing downside slippage.


---


## 4. Mathematical Hurdles & Volatility


*   **Sortino Ratio**: `5.67` (**PASS** - Threshold > 2.0)


*   **Downside Deviation**: `0.34%` (Extremely low, signifying a stable Shield base)


*   **ATR (5m)**: `0.19` (Low intraday noise relative to price)


---


## 5. Execution Parameters


*   **Status**: **STRIKE Authorized**


*   **Execution Strategy**: Institutional Entry (Scale-in at Support)


*   **Strike Zone (Entry)**: `$27.23` – `$26.13`


*   **Hard Stop**: `$24.11` (Protective floor below Bullish FVG and Tactical VAL)


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `80 Shares`
    *   *Calculation: `$250` / (`$27.23` - `$24.11`) = `~80.12`*


---


## 6. Risk Guardrails


*   **Kill Switch**: Immediate liquidation if the price closes below the Tactical Anchor of `21.4450`.


*   **Shield Narrative**: USAR is no longer a volatile speculation. The influx of `$1.5B` in PIPE financing and federal-aligned supply chain importance has created a structural floor. We are treating this as a defensive growth position with a clear upside target toward the cycle resistance at `$32.07`.


*   **Volatility Warning**: Monitor macro industrial reports; however, the `0.34%` downside deviation currently suggests that the "Shield" is fully deployed.