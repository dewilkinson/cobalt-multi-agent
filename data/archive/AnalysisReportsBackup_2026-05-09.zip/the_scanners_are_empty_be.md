> **Generated:** Friday, May 08, 2026 at 09:56 AM

# 1. Execution Summary

**SCOUT Authorized**

The Sortino hurdle has been manually adjusted to `1.0` per Root Institutional directive, clearing `IOT` for immediate deployment. While the multi-timeframe (MTF) institutional trend remains technically **Bearish** following the Change of Character (`CHoCH`) at `$34.78`, the asset is currently testing a high-convexity support zone at the 5-day Value Area Low (`VAL`) of `$28.28`. 

This "Sword" position is a mean-reversion play targeting the high-volume nodes above. We are authorizing a **SCOUT** entry (0.5R) to probe for institutional absorption at these discounted levels. A full **STRIKE** authorization would require a bullish `CHoCH` on the 5-minute timeframe, specifically a reclaim of the `$29.13` level.


---


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


---


# 3. Execution Parameters

*   **Execution State**: **SCOUT Authorized** (0.5R)


*   **Risk Unit (R)**: `$125`


*   **Share Quantity**: `125` Shares


*   **Strike Zone (Entry)**: `$28.77`


*   **Hard Stop**: `$27.77`


*   **Target 1 (Trim 50%)**: `$30.67` (5d POC)


*   **Target 2 (Runner)**: `$31.37` (Tactical Displacement Pivot)


---


# 4. Technical Structural Audit

**Institutional Footprint & SMC Alignment**

*   **Trend Bias**: Bearish (Transitioning to Neutral)


*   **Macro Ceiling**: `$34.78` (Institutional Supply)


*   **Tactical Displacement**: `$31.37` (Local breakdown point)


*   **Liquidity Pool**: `$27.90` (Sell-side stops located just below our Hard Stop)


*   **Fair Value Gaps (FVG)**:
    *   **Bullish**: `$29.13` - `$30.45` (Unfilled attraction zone)
    *   **Bearish**: `$29.96` - `$31.37` (Resistance overhead)


**Volume Profile Metrics**

*   **60-Day POC**: `$32.12` (Primary Magnet)


*   **5-Day VAL**: `$28.28` (Current Support Anchor)


*   **RVOL**: `1.45` (Confirmed Institutional Activity)


---


# 5. Risk & Strategy Management

*   **Sortino Hurdle**: **PASS** (Threshold reduced to `1.0`; Asset Value: `1.32`)


*   **Volatility (ATR)**: `0.38` (5m timeframe)


*   **Sword/Shield Balance**: This is a high-growth "Sword" asset. Given the `-4.04%` intraday move, the position size is restricted to `0.5R` to mitigate further downside deviation.


*   **Exit Logic**: Hybrid Momentum. Trim 50% at `2R` profit. Trail the remaining position with a 5-minute `9EMA` to capture a potential squeeze toward the `$30.67` Point of Control.


*   **Psych Reset**: If the stop at `$27.77` is triggered, the system will revert to `0.5R` Scout mode for all subsequent trades today to preserve the `$100k` IRA principal.


---

**Status**: **Execution Authorized.** Parameters pushed to terminal.