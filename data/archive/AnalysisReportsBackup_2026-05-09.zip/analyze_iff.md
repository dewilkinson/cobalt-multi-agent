> **Generated:** Friday, May 08, 2026 at 04:35 PM

Active Strategy: Shield Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


International Flavors & Fragrances (**IFF**) is currently operating as a high-fidelity **Shield** asset within the Blueshell War Barbell. The technical profile confirms a significant institutional rotation into this defensive materials play, evidenced by the `+3.71%` price expansion. With a **Sortino Ratio** of `3.11`, the asset drastically exceeds our `2.0` hurdle, indicating that the recent volatility is overwhelmingly biased toward the upside.


The structural setup shows a clean breakout from the **Macro Value Area**. While price is currently in a "Premium" zone, the momentum is backed by a confirmed **Bullish Break of Structure (BOS)** at `$70.11` and deep institutional support at the `$70.74` **Point of Control (POC)**. We are authorizing a **STRIKE** execution to capture the current momentum shift toward the `$84.00` macro liquidity ceiling.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


`[DATA_UNAVAILABLE]`


---


# 3. EXECUTION PARAMETERS


*   **Position Type**: Shield (Long)
*   **Execution State**: **STRIKE**
*   **Share Quantity**: `250 Shares`
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$81.05` - `$81.50`
*   **Hard Stop**: `$80.05`
*   **Target (Macro Ceiling)**: `$84.45`


---


# 4. TECHNICAL STRUCTURAL AUDIT


**MARKET STRUCTURE (SMC)**
*   **Institutional Trend**: Bullish (MTF Alignment)
*   **BOS (Break of Structure)**: Confirmed at `$70.11`
*   **Primary Order Block (Bullish)**: `$68.78` — `$70.86`
*   **Primary Order Block (Bearish)**: `$82.04` — `$84.45`
*   **Fair Value Gaps (FVG)**: Major bullish imbalance identified between `$71.08` and `$78.12`.


**VOLUME PROFILE ANALYSIS**
*   **60d Macro POC**: `$70.53`
*   **5d Tactical POC**: `$70.74`
*   **Value Area High (VAH)**: `$74.57`
*   **Value Area Low (VAL)**: `$64.70`
*   **Current State**: Price is trading well above the **60d VAH**, indicating a high-momentum expansion phase out of the previous value range.


---


# 5. RISK & VOLATILITY METRICS


*   **Sortino Ratio**: `3.11` (Hurdle: `2.0` — **PASS**)
*   **Downside Deviation**: `0.35%`
*   **Average True Range (ATR)**: `0.16` (5m timeframe)
*   **Relative Volatility (RVOL)**: High institutional accumulation signature noted.


---


# 6. SHIELD STRATEGY NARRATIVE


IFF is performing its role as a **Shield** by providing defensive stability with superior risk-adjusted returns. The low **Downside Deviation** (`0.35%`) ensures that even during market-wide turbulence, IFF maintains structural integrity. 


The tight **Hard Stop** at `$80.05` is mathematically anchored just below the current psychological level and local momentum pivot to ensure a high **R-multiple** on this defensive deployment. Should the price close below the **Tactical Displacement Pivot** of `$78.12`, the "Shield" is considered breached, and the **Kill Switch** will be engaged to preserve IRA capital.