> **Generated:** Friday, May 08, 2026 at 01:34 PM

Active Strategy: Sniper Strategy


---


# 1. Execution Summary


**Execution Authorization: WAIT**


PUBM is currently exhibiting a **Macro Bearish Trend** (CHoCH at `$7.13`) despite a tactical price recovery to `$10.66`. While the Sortino Ratio (`2.94`) exceeds our institutional hurdle of `2.0`, the structural map indicates the asset is trading in "Thin Air" above the Macro Value Area High (VAH) of `$9.92`. 


In accordance with the **Sniper Strategy**, we do not fire into unanchored price action or low-volume extensions. The asset is currently in a "Premium Zone," significantly decoupled from the institutional point of control. We require a retracement to high-confluence liquidity zones before authorizing a strike.


---


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: Macro Bearish / Tactical Neutral-Bullish.
*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$7.13` (Institutional break of structure level).
    *   **Change of Character (CHoCH)**: Bearish CHoCH confirmed at `$7.13` on the 1d timeframe.
    *   **Current Zone**: **Premium**. Price is currently `29%` above the Macro POC.
*   **Volume Profile Anchors**:
    *   **Macro POC**: `$8.23`
    *   **Macro VAH**: `$9.92`
    *   **Macro VAL**: `$7.34`
*   **Institutional Footprint**:
    *   **Fair Value Gaps (FVG)**: Bearish FVG identified between `$9.65` - `$9.71`.
    *   **Order Blocks (OB)**: Bullish OB located at `$7.73` - `$8.06` (Deep Discount).
    *   **Liquidity**: External Sell-Side Liquidity (SSL) resting at `$7.13`.


---


# 4. Quantitative Performance Metrics


*   **Day Trading Sortino Ratio**: `2.94` (**PASS**)
*   **Downside Deviation**: `0.63%`
*   **Volatility (ATR 5m)**: `0.07`
*   **Relative Strength**: Positive intraday correlation, but volume is concentrated in lower nodes.


---


# 5. Execution Parameters (The Sniper Path)


If the asset retraces to the tactical support zone and completes a liquidity sweep, the following parameters are authorized:


*   **Strike Zone (Entry)**: `$9.85` (Convergence of Tactical POC and 5d VAH).
*   **Hard Stop**: `$9.35` (Below recent 5m consolidation).
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `500` Shares.
*   **Target (4:1 RR)**: `$11.85`


---


# 6. Risk Guardrails


*   **The Kill Switch**: A 1h candle close below the Macro POC of `$8.23` neutralizes the long thesis immediately.
*   **Institutional Narrative**: PUBM is overextended from its value anchors. Entering at `$10.66` risks catching a "Blow-off Top" in a low-volume environment (`LVN` between `$10.51` and `$10.91`). 
*   **Strategy Note**: The Sniper remains patient. We wait for price to return to the **Shield** of institutional liquidity near `$9.85` before deploying the **Sword**.


---


**Status: OK. Analysis Complete.**