> **Generated:** Friday, May 08, 2026 at 12:24 PM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**SCOUT Authorized**


FNKO is currently operating as a high-velocity **Sword** asset, exhibiting intense institutional momentum with a `+10.61%` intraday surge. The mathematical hurdle is cleared with a **Day Trading Sortino Ratio** of `4.51`, significantly exceeding our `2.0` requirement. However, technical structural mapping shows price has entered a major **Macro Bearish Order Block** between `4.6500` and `6.0400`. 


Given the **Sniper Strategy** mandate (targeting high RR), we are initiating a **Scout (0.5R)** position at the current level. While the momentum is aggressive, the proximity to the `$6.00` psychological ceiling and macro supply requires a disciplined entry. We are looking to "snipe" a continuation move toward the `$6.10` liquidity pool while maintaining a tight defensive posture.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


[DATA_UNAVAILABLE]


---


# 3. SMC STRUCTURAL AUDIT


*   **Institutional Bias**: **Bullish (Tactical)** / **Bearish (Macro)**
    *   **Macro CHoCH**: Confirmed at `3.5300`, marking a significant shift in long-term character.
    *   **Market State**: Expansion/Markup phase on the 1h timeframe.


*   **Volume Profile & Liquidity**:
    *   **Session POC**: `4.38` (High-density institutional accumulation zone).
    *   **Value Area High (VAH)**: `4.77`.
    *   **External Liquidity**: `6.10+` (Buy-side targets).


*   **Supply & Demand Zones**:
    *   **Bearish OB**: `4.6500` – `6.0400` (Current Point of Interest).
    *   **Bullish FVG**: `4.4250` – `4.9250` (Primary structural support/re-entry zone).


---


# 4. MATHEMATICAL HURDLES


*   **Day Trading Sortino**: `4.51` (Status: **PASS**)
*   **Relative Volume (RVOL)**: `1.8x` (Indicating Institutional Accumulation).
*   **Daily Volatility (ATR)**: `0.09`.


---


# 5. EXECUTION PARAMETERS (SNIPER)


**STRATEGY TIER**: **SCOUT (0.5R)**


*   **Risk Unit (R)**: `$250.00`
*   **Actual Risk Amount**: `$125.00`
*   **Strike Zone (Entry)**: `$5.47`
*   **Hard Stop**: `$5.27` (Technical exit below the 5m structural shelf)
*   **Share Quantity**: `625` shares
*   **Target (4:1 RR)**: `$6.27`


---


# 6. RISK GUARDRAILS & MONITORING


*   **Sword Management**: FNKO is the "Sword" in our War Barbell. This is a short-term tactical play. If the price fails to hold the `$5.30` level on a 5m closing basis, the trade is invalidated. 


*   **Scale-In Protocol**: We will only scale this to a **STRIKE (1R)** position if price clears and holds `$5.70` with a fresh volume spike, indicating the Bearish Order Block is being absorbed by buyers.


*   **MOC Exit**: If volatility spikes and the VIX crosses `25`, we will close the laggard position at `3:55 PM` regardless of the P/L status.