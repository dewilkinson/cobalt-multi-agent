> **Generated:** Wednesday, May 06, 2026 at 09:40 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


FIVN has triggered a high-conviction **Execution Authorization** following a structural **CHoCH** (Change of Character) at `$20.7650`, marking a definitive end to the previous bearish regime. The stock is currently exhibiting institutional displacement, moving out of the high-volume accumulation node centered at `$17.05`. With a **Sortino Ratio** of `5.37`, the asset meets the "Sniper" mandate for elite risk-adjusted momentum, far exceeding our `2.0` hurdle. 


The trade is a classic "Sword" deployment, fueled by a `$90M` accelerated share repurchase agreement and a robust Q1 earnings beat. Despite standard legal noise regarding fiduciary investigations, the "Tape" shows aggressive institutional call buying and a reclaim of the Macro **VAH** at `$19.82`. We are positioning for a continuation toward the **Macro Ceiling** at `$25.34`.


---


# 2. Institutional News & Social Sentiment


*   **Traders Purchase High Volume of Call Options on Five9** (MarketBeat) | **Bullish** | *2h ago* 
    Institutional flow indicates heavy positioning in near-term calls following the Q1 earnings beat.


*   **Five9 Inc. Commences $90M Accelerated Share Repurchase Agreement** (SEC Filing/Reuters) | **Bullish** | *1d ago*
    The company has entered an agreement with JPMorgan to aggressively buy back shares, providing a "Shield" against downside volatility.


*   **Sprinklr, Five9, and Varonis Systems Shares Soaring** (StockStory) | **Bullish** | *1d ago*
    Sector-wide rotation into cloud contact center solutions is accelerating following peer earnings from Twilio and Atlassian.


*   **Five9 Inc. Investigation: Bronstein, Gewirtz & Grossman, LLC** (ACCESS Newswire) | **Bearish** | *1d ago*
    Standard retail-level legal investigation regarding shareholder rights; historically has low impact on institutional price discovery.


**Social Sentiment Synthesis**: Sentiment on Twitter and financial subreddits is currently **Highly Bullish**. Retail traders are focused on the "AI revenue growth" narrative, while institutional data shows a significant increase in stake from firms like Van Berkom & Associates (now holding `$72.11M` in value).


---


# 3. Structural Audit (The Sniper Scope)


*   **Institutional Bias**: **Bullish** (Confirmed by 1d CHoCH).


*   **Dual-Anchor Alignment**:
    *   **Macro Ceiling (Target)**: `$25.34` (Cycle High).
    *   **Tactical DP (Pivot)**: `$20.76` (Reclaimed Displacement Pivot).


*   **Order Blocks (OB)**:
    *   **Breaker Zone**: `$16.73` - `$20.76` (Former bearish supply now acting as institutional demand).
    *   **Deep Value demand**: `$13.29` - `$13.89`.


*   **Fair Value Gaps (FVG)**:
    *   **Magnet Zone**: `$23.19` - `$23.88` (Immediate upside liquidity gap).
    *   **Support Gap**: `$17.41` - `$22.08`.


*   **Volume Profile**:
    *   **POC**: `$17.05` (Point of Control / Value Anchor).
    *   **VAH**: `$19.82` (Value Area High).
    *   **Status**: Price is currently in "Discovery Mode" above the Value Area.


---


# 4. Execution Parameters


*   **Strike Zone (Entry)**: `$22.75`
*   **Hard Stop**: `$20.50` (Below the Tactical Pivot)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `111` Shares
*   **Target 1 (1R Anchor)**: `$25.00` (Engagement of trailing stop)
*   **Final Target (Macro Ceiling)**: `$25.34`


---


# 5. Risk Guardrails & Strategy


*   **Sortino Validation**: `5.37` (Pass).
*   **RVOL Check**: Institutional intent is confirmed by the high-volume expansion above `$21.00`.
*   **Kill Switch**: Close full position if a 5-minute candle closes below `$20.00`. This would signify a "Retail Trap" and a failure to hold the Value Area High.
*   **The War Barbell**: As a "Sword" position, this trade is targeted for a fast momentum move. We will use the **5-min 9 EMA** to trail the final `25%` of the position once Target 1 is hit.


---


**Active Management Note**: Engaged a `1R` trailing stop once price hits `$25.00` (approaching the Macro Ceiling). Status: **Monitoring for Strike Entry.**