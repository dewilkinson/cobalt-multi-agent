> **Generated:** Friday, May 08, 2026 at 10:50 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**. PGNY has successfully confirmed an institutional trend reversal via a macro Change of Character (CHoCH) at `18.60`. The asset is currently exhibiting a high-velocity "Sword" profile, supported by a record earnings beat and aggressive institutional accumulation. With a **Sortino Ratio of 5.81**, the price action demonstrates elite downside efficiency, justifying a full `1R` deployment under the **Sniper** protocol.


The rationale is driven by the confluence of technical structural breaks and fundamental catalysts. Price has cleared the high-volume nodes of the previous 60-day range and is currently trading in a "Thin Air" zone with minimal overhead resistance until the `24.53` level. Significant insider buying and a Vanguard stake increase to `6.54%` provide the "Smart Money" backdrop required for a high-conviction sniper entry.


---


# 2. Institutional News & Social Sentiment


*   **Progyny Delivers Record Q1 2026 Revenue and Growth** (TipRanks, 2h ago): Reported record revenue of `$328.5 million`, showing resilience and growth despite the loss of a major client.
*   **Vanguard Portfolio Management Boosts PGNY Stake to 6.54%** (Stock Titan, 5h ago): Passive stake increased to `5,357,311` shares as of late Q1.
*   **Progyny, Inc. Expects Q2 Revenue Range $342.0M - $355.0M** (MarketScreener, 3h ago): Forward guidance exceeds consensus, signaling continued market share capture in the fertility benefits sector.
*   **Record Q1 revenue and major buybacks shape 2026 outlook** (Stock Titan, 4h ago): Completion of recent buyback programs reinforces management's view of significant undervaluation.


**Social Sentiment Synthesis**: Sentiment is **Extremely Bullish**. The retail narrative has pivoted from "loss of client" fears to "undervalued growth" following the massive earnings beat. Institutional interest is high, with DCF models circulating in professional circles suggesting a fair value north of `$30.00`.


---


# 3. Structural Audit & Quantitative Metrics


**Technical Footprint**
*   **Market Structure**: Bullish (CHoCH confirmed at `18.60`)
*   **Macro Anchor POC (60d)**: `17.94`
*   **Tactical Momentum POC (5d)**: `18.69`
*   **Value Area High (VAH)**: `24.53`
*   **Fair Value Gaps (FVG)**: `19.12` – `21.19` (Bullish Support Zone)


**Risk Efficiency (Sortino)**
*   **Day Trading Sortino**: `5.81`
*   **Downside Deviation**: `0.38%`
*   **Result**: **PASS** (Exceeds `2.0` hurdle)


**Volatility Profile**
*   **ATR (5m)**: `0.41`
*   **Relative Volume (RVOL)**: High (Accumulation Phase)


---


# 4. Execution Parameters


**STRIKE STATE: ACTIVE**


*   **Strike Zone (Entry)**: `$22.62`
*   **Hard Stop**: `$21.60` (Positioned below tactical support node)
*   **Primary Target (4:1 RR)**: `$26.70`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `245` Shares


---


# 5. Risk Guardrails


*   **Scale-In Protocol**: Add second unit only if price clears `$23.50` and the initial stop is moved to Break-Even.
*   **Invalidation Point**: A daily close below `$21.30` (re-entry into the FVG) invalidates the sniper momentum thesis.
*   **MOC Exit**: If VIX spikes above `25` and PGNY loses its intraday momentum, exit `50%` of the position at `3:55 PM`.


**Final Analyst Note**: PGNY is functioning as a "Sword" asset in the current War Barbell framework. The structural breakout from the `18.60` base is backed by institutional volume. We are targeting the macro liquidity void up to `$26.70` to satisfy the **Sniper** 4:1 Reward-to-Risk requirement. Adhere strictly to the `$21.60` hard stop to maintain institutional risk parity.