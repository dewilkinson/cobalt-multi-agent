> **Generated:** Thursday, May 07, 2026 at 10:48 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**STRIKE Authorized**: The institutional footprint for `SSSS` confirms a high-conviction accumulation phase. Macro and tactical alignment are synchronized, with the price currently sustained by a "Macro Shield" provided by significant insider buying from the CEO (`$65,825` investment) and a successful Dutch Auction share repurchase program that has tightened the float. 


The setup meets the **Sniper** threshold for high-reward entry. Despite a session pullback of `-2.28%`, the technical structure remains intact, trading well above the bullish `CHoCH` at `$9.94`. The presence of multiple bullish Fair Value Gaps (`FVG`) between `$13.45` and `$13.49` provides a high-probability "Strike Zone" for entry, targeting the revised analyst ceiling of `$15.45`.


---


# 2. Institutional News & Social Sentiment

**Headlines & Catalysts**:

*   **24h ago**: SuRo Capital Corp. CEO Mark Klein buys `$65,825` in company stock across two days, signaling deep internal confidence near 52-week highs. (Source: Investing.com)


*   **48h ago**: Analyst price target for `SSSS` increased by `15.65%` to `$15.45`, citing optimistic AI-infrastructure portfolio growth. (Source: MSN)


*   **Recent**: Q3 Earnings Report: EPS beat by `$0.04`, though revenue fell slightly short of consensus at `$459.27K`. (Source: Investing.com)


*   **Historical Context**: Completion of a modified "Dutch Auction" tender offer, repurchasing `2,000,000` shares (`7.9%` of float), creating a supply-constrained environment. (Source: Stock Titan)


**Social Sentiment**:
Sentiment is **Bullish/Neutral**. Twitter activity highlights the positive `+2.8%` comps in consumer-facing segments and the stock's ability to hold its highest levels of the year. While some traders express caution regarding broader market volatility, the insider buying narrative is the dominant theme on social platforms, acting as a sentiment floor.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bullish** 


*   **Market Structure**:
    *   **Macro Trend**: Bullish (Change of Character confirmed at `$9.94`).
    *   **Tactical POC (Point of Control)**: `$13.30` (The high-volume node where smart money is positioned).
    *   **Session VAH (Value Area High)**: `$14.01`.
    *   **Session VAL (Value Area Low)**: `$12.28`.


*   **Institutional Footprint**:
    *   **Order Block (Bullish)**: `$8.46` - `$9.16` (Primary Accumulation).
    *   **Imbalance (FVG)**: `$13.45` - `$13.49` (Immediate liquidity magnet).
    *   **Liquidity Pool**: `$14.48` (Previous peak resistance).


---


# 4. Mathematical Hurdle (Sortino)

*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `3.05`
*   **Hurdle Status**: **PASS** (Requirement >= `2.0`)
*   **Risk Profile**: Extremely low downside deviation of `0.49%` confirms tight institutional control and minimal "noise" for the Sniper execution.


---


# 5. Execution Parameters

*   **Strategy**: **STRIKE** (Full Deployment)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `192 Shares`
*   **Strike Zone (Entry)**: `$13.45` - `$13.73`
*   **Hard Stop**: `$12.43` (Protected by the Tactical VAL)
*   **Profit Target**: `$15.45` (Institutional Price Target)


---


# 6. Risk Guardrails

*   **Daily Stop-Loss**: Total account risk capped at `3R` (`$750`).
*   **Kill Switch**: A 5-minute candle close below `$12.28` (Session VAL) invalidates the tactical thesis.
*   **Scale-In Protocol**: No additional units until the first unit is at break-even and the `$14.48` liquidity pool is cleared.
*   **Performance Note**: `SSSS` acts as a "Sword" for the portfolio—high growth potential in AI-infra—but is currently shielded by the CEO's buy-side participation and the share buyback reduction in float.