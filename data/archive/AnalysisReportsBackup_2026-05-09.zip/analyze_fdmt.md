> **Generated:** Friday, May 08, 2026 at 10:17 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**Recommendation**: **WAIT (Cold Bore Monitor)**


**Rationale**: FDMT demonstrates high-conviction structural promise on the Macro Map (Daily Bullish BOS), but the current internal tape is inefficient. The **Mathematical Hurdle (Sortino)** has failed to clear the Sniper threshold, currently printing a negative value of `-0.03`. This indicates that recent volatility is skewed heavily toward the downside. 


Furthermore, while the fundamental narrative regarding the Wet AMD gene therapy remains a potent "Sword" catalyst, the recent **`$400M` shelf registration** has created a temporary liquidity overhang. As Snipers, we do not pull the trigger on mathematically inefficient targets or enter during "Post-Earnings Digestion" while the price remains below the Session Point of Control (POC). We are awaiting a reclaim of the `$9.74` level to confirm institutional re-accumulation before deployment.


---


# 2. Institutional News & Social Sentiment

*   **Wet AMD Gene Therapy Phase 3 (2h ago)**: 4DMT announced the completion of randomization for its 4D-150 Phase 3 clinical trial. Topline data is expected in 2027. (Source: Stock Titan)


*   **Q1 2026 Financial Results (2h ago)**: Reported a net loss of `$68.8 million` but confirmed a robust cash runway extending into the second half of 2028 with `$458 million` on hand. (Source: GlobeNewswire)


*   **$400M Shelf Registration (3h ago)**: Filed a shelf registration (S-3) to offer up to `$400 million` in various securities, acting as a short-term price anchor due to dilution concerns. (Source: Stock Titan)


*   **Investor Conference Participation (4d ago)**: Management confirmed attendance at the BofA Securities 2026 Healthcare Conference (May 13) and RBC 2026 Global Healthcare Conference. (Source: GlobeNewswire)


**Social Sentiment Synthesis**: 
Retail sentiment on X (Twitter) and Reddit remains cautiously optimistic regarding the "cash runway to 2028," viewing the recent dip as a "Shakeout." However, institutional "Smart Money" flow (Dark Pools) shows neutral activity, awaiting the digestion of the shelf registration.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bullish Macro** | **Bearish Tactical** 
    *   The long-term trajectory is protected by a 60d Macro POC at `$8.88`, but the session tape is currently being suppressed by intraday supply.


*   **Market Structure (SMC)**:
    *   **Macro Ceiling**: `$11.81` (Cycle Peak).
    *   **Tactical Displacement Pivot**: `$10.48` (Level of last bullish break).
    *   **BOS (Break of Structure)**: Confirmed Bullish at `$10.48` on the Daily; price is currently in a corrective retracement toward the **Discount Zone**.


*   **Institutional Footprint**:
    *   **Bullish FVG (Imbalance)**: `$9.55` - `$9.65` — Price is currently tapping the top of this magnet.
    *   **Bearish Order Block**: `$10.87` - `$11.64` — Significant institutional sell-side wall.
    *   **Liquidity Pool**: `$8.88` (Macro POC) — The primary anchor for institutional "Big Money."


---


# 4. Mathematical Hurdle (Sortino)

*   **Hurdle Result**: **FAIL**


*   **Sortino Ratio**: `-0.03`


*   **Analysis**: The asset is failing the Sniper threshold of `2.0` (and the stretch target of `20.0`). The current negative value confirms that FDMT is "bleeding" downside deviation faster than it is capturing upside premium. No long entry is authorized under these conditions.


---


# 5. Tactical Execution Parameters (Target Calibration)

*While current status is WAIT, the following parameters are calibrated for the "Reclaim Trigger":*


*   **Trigger**: Reclaim and hold of Session POC at `$9.74`.
*   **Strike Zone (Entry)**: `$9.75` (Limit Order)
*   **Hard Stop**: `$9.37` (Liquidity Sweep below Session VAL)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `675 Shares`
*   **Profit Target (4:1 Sniper)**: `$11.27` (Entry into Bearish Order Block)


---


# 6. Risk Guardrails

*   **Kill Switch**: `$8.88`. A daily close below the Macro POC invalidates the multi-month bullish thesis and mandates an immediate exit of all speculative scouts.


*   **Sword/Shield Balance**: FDMT is a high-conviction "Sword" asset. Given the Sortino failure, the portfolio must maintain its "Shield" allocations (Low-Vol ETFs) until FDMT stabilizes.


*   **Daily Stop**: `3R` (`$750`). Total session halt if the daily loss limit is reached.


**Analyst Note**: Stay disciplined. The Sniper protocol demands patience; we do not "catch falling knives" in the biotech sector. We wait for the `$9.74` tactical pivot reclaim to ensure we are aligned with institutional momentum. Hold fire.