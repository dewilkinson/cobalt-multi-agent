> **Generated:** Thursday, May 07, 2026 at 11:21 AM

Active Strategy: Shield Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


OSCR presents a rare high-conviction "Shield" opportunity characterized by a massive institutional floor. While the ticker is exhibiting momentum typically seen in "Sword" assets, the mathematical stability—specifically a **Sortino Ratio** of `6.38`—confirms that the upward expansion is orderly and devoid of the erratic downside volatility that threatens capital preservation. This execution is predicated on the "Volumetric Moat" created by a `$11.9M` insider purchase by CEO Mark Bertolini, which has effectively re-indexed the stock's valuation floor. 


The technical structure shows a completed **Liquidity Sweep** at `19.78`, providing a clear tactical launchpad. Despite trading above the 60-day Value Area High (`16.58`), the presence of fresh bullish Fair Value Gaps (FVG) and institutional absorption suggests this is a "Value Breakout" rather than an overextended peak.


***


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Oscar Health CEO 2025 Pay Revealed; 20% Increase Noted** (Quiver Quantitative | 2h ago)
    *   Mark T. Bertolini’s compensation details released via SEC filing, signaling long-term leadership stability.


*   **OSCR Up 22% Following CEO's $11.9M Share Purchase & Regulatory Tailwind** (Yahoo Finance | 12h ago)
    *   CEO purchase of 1,000,000 shares increases ownership above 10%, signaling massive internal confidence.


*   **Bertolini buys Oscar Health (OSCR) shares for $11.92 million** (Investing.com | 1d ago)
    *   Confirms massive insider accumulation despite previous Q4 earnings misses; market shifting focus to profitability.


*   **Director Sid Sankaran Appointed Independent Board Chair** (MarketScreener | 1d ago)
    *   Leadership restructuring continues to favor institutional governance standards.


*   **Social Sentiment Synthesis**:
    *   **Reddit (r/Stocks)**: Strong interest in OSCR as a "Turnaround Play" following Medicare Advantage regulatory updates.
    *   **Twitter (X)**: FinTwit "Smart Money" accounts are flagging the `$11.9M` insider buy as a primary signal for a structural trend shift.


***


# 3. EXECUTION PARAMETERS


*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$20.31`
*   **Hard Stop**: `$19.45`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `290 Shares`
*   **Risk-to-Reward (Target 3:1)**: `$22.89`


***


# 4. QUANTITATIVE ANALYSIS & SMC DATA


**SMC STRUCTURAL AUDIT**
*   **Institutional Trend**: Bullish (MTF Alignment)
*   **CHoCH Level**: `15.25`
*   **Liquidity Sweep**: YES (Bullish) at `19.78`
*   **Primary Order Block**: `10.69` — `11.25`
*   **Tactical FVG**: `18.76` — `19.23`


**VOLUMETRIC METRICS**
*   **60d POC**: `13.43`
*   **60d VAH**: `16.58`
*   **60d VAL**: `11.95`
*   **5d POC**: `14.55`
*   **Current RVOL**: High (Institutional Accumulation Profile)


**RISK & VOLATILITY**
*   **Sortino Ratio**: `6.38` (Hurdle: `>= 2.0`)
*   **ATR (5m)**: `0.18`
*   **Downside Deviation**: `0.26%`


***


# 5. RISK GUARDRAILS & MONITORING


*   **Shield Integrity**: The current Sortino of `6.38` is elite. Any degradation of this ratio below `3.0` should trigger a review of the position size.
*   **Invalidation Point**: A session close below the `$18.75` level (bottom of the institutional FVG) invalidates the "Shield" thesis and suggests a return to the macro value area.
*   **Trailing Protocol**: Once price reaches `2:1` RR (`$22.03`), move the Hard Stop to **Break-Even** (`$20.31`) to ensure wealth preservation in accordance with Blueshell Securities LLC risk mandates.