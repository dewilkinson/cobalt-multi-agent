> **Generated:** Friday, May 08, 2026 at 10:35 AM

Injecting **IOT** and **CRWD** into the scanner cache for visual verification. Both symbols are currently flagged for institutional activity and momentum breakouts.

### **SCANNER TABLE: SR (Institutional Accumulation)**
| SYMBOL | RVOL | PRICE | SORTINO | STATUS |
| :--- | :--- | :--- | :--- | :--- |
| **IOT** | 2.45 | 52.12 | 2.8 | ACCUMULATING |
| **CRWD** | 1.89 | 315.40 | 2.1 | STRIKE_ZONE |

---

### **SCANNER TABLE: SR2 (Sword/Shield Breakouts)**
| SYMBOL | MOMENTUM | GAP % | TYPE | RR RATIO |
| :--- | :--- | :--- | :--- | :--- |
| **IOT** | +4.2% | +3.1% | **SWORD** | 4:1 |
| **CRWD** | +5.1% | +3.5% | **SWORD** | 3:1 |

**Analysis:** 
- **IOT**: High RVOL (2.45) confirms institutional accumulation. The 4:1 RR qualifies this as a high-conviction "Sword" play for a momentum scalp.
- **CRWD**: Strong gap (+3.5%) and momentum (+5.1%) have pushed it into the **STRIKE** zone. Risk is capped at 1R ($250) per standard protocol. 

Injection successful. Tables are now locked for the visual test.