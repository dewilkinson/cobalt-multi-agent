> **Generated:** Friday, May 08, 2026 at 12:11 PM

Active Strategy: Shield Strategy


`GTX` is currently demonstrating high-velocity structural resilience, confirmed by a **Sortino Ratio** of `6.44`. This metric significantly exceeds the institutional benchmark of `2.0`, positioning the asset in a "High-Velocity Shield" phase. The price action has decisively cleared macro-resistance at `$21.42`, signaling a transition from defensive accumulation into a powerful institutional expansion zone.


The asset exhibits aggressive Relative Strength (RS) against the broader market, underscored by a `6.95%` price surge on robust volume of `1,145,921` shares. The volume profile reveals a significant "thin-air" liquidity gap between `$21.42` and `$28.61`. Institutional behavior indicates active price chasing rather than passive defense, as the current market price is substantially extended from the **Macro POC** of `$18.43`.


---


### I. INSTITUTIONAL SHIELD PROTOCOL (STRUCTURE)


*   **Institutional Bias**: Strong Bullish (Shielding Gains).
*   **Macro Map (1d)**: Confirmed Bullish trend with a **Break of Structure (BOS)** at `$21.4247`.
*   **Tactical DP (Displacement Pivot)**: `$21.42` remains the primary acceleration point for the current trend.
*   **Market Structure State**: Premium Zone. While price is extended, the efficiency of returns relative to downside volatility justifies the current elevation.


**Institutional Footprint:**
*   **Primary Bullish Shield Zone (Order Block)**: `$25.83` - `$26.13`.
*   **Institutional Magnet (FVG)**: `$26.19` - `$26.80`.
*   **Macro Liquidity Pool**: `$21.42` (Successfully swept and reclaimed).


---


### II. QUANTITATIVE HURDLE & VOLATILITY


*   **Sortino Ratio**: `6.44` (Status: **PASS**).
*   **Downside Deviation**: `0.49%`.
*   **Volatility (ATR 5m)**: `0.12`.
*   **Analysis**: The exceptional Sortino value indicates that for every unit of downside risk, `GTX` generates over `6` units of return, making it a top-tier candidate for the Blueshell Securities risk-adjusted portfolio.


---


### III. VOLUME PROFILE ARCHITECTURE


*   **Macro POC (60d)**: `$18.43`
*   **Macro VAH**: `$19.68`
*   **Macro VAL**: `$16.68`
*   **Tactical VAH (5d)**: `$25.63`
*   **Tactical POC (5d)**: `$19.29`


---


### IV. EXECUTION PARAMETERS (SNIPER PATH)


*   **Execution Authorization**: **STRIKE Authorized**
*   **Strike Zone (Entry)**: `$28.40` - `$28.61`
*   **Hard Stop**: `$27.60`
*   **Risk Unit (1R)**: `$250`
*   **Share Quantity**: `247` Shares


---


### V. RISK GUARDRAILS & KILL SWITCH


*   **Kill Switch (Exit)**: `$26.80`. A sustained close below this level signals a breakdown into the FVG gap and a failure of the "Shield Expansion" narrative.
*   **Technical Context**: Maintain strict adherence to stops. While `GTX` is behaving as a high-growth "Sword," its mathematical downside protection qualifies it for "Shield" status. Monitor price discovery closely as it seeks a new local ceiling.


---


**Status**: Active. MTF Institutional Macro trend is aligned. ATR-adjusted volatility floor is set at `$27.60`.