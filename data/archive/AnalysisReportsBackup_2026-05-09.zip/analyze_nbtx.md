> **Generated:** Thursday, May 07, 2026 at 10:20 AM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized** (Pending 5m Liquidity Sweep confirmation)


NBTX is currently exhibiting a high-velocity institutional mark-up phase, characterized by a massive **Sortino Ratio** of `8.09`. This significantly exceeds our institutional hurdle of `2.0`, indicating that the recent price expansion is occurring with remarkably low downside deviation (`0.69%`). 


The technical narrative is dominated by a clean **Macro Break of Structure (BOS)** at `$41.88`. While the price is currently trading at `$44.19`, it is operating in a low-volume vacuum. As **Snipers**, we do not chase "thin air." The strategy mandates waiting for a mean reversion toward the **Value Area High (VAH)** at `$41.35` to capture a high-probability retest of the breakout level, ensuring our risk-to-reward ratio remains optimized at `4:1` or better.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


[DATA_UNAVAILABLE]


---


# 3. STRUCTURAL AUDIT (SMC PROTOCOL)


*   **Institutional Bias**: Ultra-Bullish.
*   **Macro Structure**: Confirmed **BOS** at `$41.88`. Price has transitioned from a consolidation phase into active discovery.
*   **Tactical Displacement**: A significant price expansion has left a large **Fair Value Gap (FVG)** between `$34.78` and `$42.08`. This zone acts as a primary magnet for any short-term corrective price action.
*   **Liquidity Profile**: External buy-side liquidity has been cleared. Internal sell-side liquidity is now pooling near the `$41.35` mark, which aligns with the structural floor.
*   **Volume Profile (VPVR)**:
    *   **POC (Point of Control)**: `$30.48`
    *   **VAH (Value Area High)**: `$41.35`
    *   **VAL (Value Area Low)**: `$27.89`


---


# 4. EXECUTION PARAMETERS


*   **Active Strategy**: **Sniper Strategy**
*   **Execution State**: **STRIKE** (Entry at Retest)
*   **Strike Zone (Entry)**: `$41.50` - `$42.00`
*   **Hard Stop**: `$40.50`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250 Shares`
*   **Target (Min 4:1 RR)**: `$46.00`+


---


# 5. MATHEMATICAL HURDLES & VOLATILITY


*   **Sortino Ratio**: `8.09` (Pass)
*   **Downside Deviation**: `0.69%`
*   **ATR (5m)**: `0.90` (Used to calibrate the stop-loss buffer below the BOS level)
*   **RVOL**: Current price action is skating on thin liquidity; higher relative volume is required on the retest to confirm institutional defense of the zone.


---


# 6. RISK GUARDRAILS


*   **Kill Switch**: A daily close below `$39.28` (60d Macro Value Area) invalidates the bullish structural thesis. 
*   **Sizing Note**: Per the **Sniper** protocol, we are deploying a full `1R` unit of `$250`. If the 5-minute tape shows aggressive selling through the strike zone without a structural shift, the order will be pulled to preserve capital.
*   **Sword/Shield Balance**: NBTX is a pure **Sword** position. It is highly sensitive to momentum shifts. This position must be monitored for a **MOC Exit** at `3:55 PM` if price fails to hold the `$42.00` handle.