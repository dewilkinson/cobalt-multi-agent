> **Generated:** Monday, May 04, 2026 at 07:03 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Execution Unauthorized)**

The technical and mathematical audit for `MAX` (MediaAlpha, Inc.) has resulted in a **FAIL** across all primary Sniper Strategy hurdles. While the asset has displayed strong fundamental growth in its Q1 2026 earnings report, the institutional "Tape" is heavily skewed toward distribution. A bearish Change of Character (`CHoCH`) at `11.46` has shifted the macro trend to bearish, and the current price of `9.10` remains trapped under significant supply overhead.

The core deterrent is the **Sortino Ratio**, which currently sits at `0.97`. Under the Sniper Mandate, a minimum hurdle of `2.0` is required to ensure that the asset's "Shield" (downside protection) is active. With a sub-`1.0` ratio, `MAX` is exhibiting high downside deviation that is not being offset by rapid recovery wicks. Furthermore, consistent insider selling by the CEO and Directors (exceeding `$2M` in recent weeks) creates a structural supply wall that overrides the positive earnings narrative. We will remain in cash and monitor for a reclaim of the Tactical Displacement Pivot.


---


# 2. Institutional News & Social Sentiment

*   **[2h ago] MediaAlpha director Eugene Nonko sells over $1.15 million in shares** – *Investing.com* | Polarity: `Somewhat-Bearish`
    > Director Eugene Nonko offloaded over `$1.15M` in Class A stock between April 27 and April 29, 2026, under a Rule 10b5-1 plan.
*   **[4h ago] MediaAlpha CEO Steven Yi sells $669k in company stock** – *Investing.com* | Polarity: `Somewhat-Bearish`
    > CEO Steven Yi executed sales of approximately `$669,175` to cover tax obligations; however, the persistent volume of executive sales is weighing on sentiment.
*   **[3d ago] MediaAlpha Announces First Quarter 2026 Financial Results** – *The Manila Times* | Polarity: `Bullish`
    > Record revenue of `$310.0M` reported, marking a `17%` year-over-year increase with a net income of `$14.0M`. 
*   **[4d ago] MediaAlpha (MAX) Earnings Growth and 3.4% Margin Test Bullish Valuation** – *Sahm* | Polarity: `Neutral`
    > Trailing twelve-month revenue reached `$1.16B`, but the thin `3.4%` net margin remains a point of institutional scrutiny.
*   **[12d ago] [SCHEDULE 13D/A] MediaAlpha, Inc. Amended Major Shareholder Report** – *Stock Titan* | Polarity: `Neutral`
    > White Mountains Insurance Group filed an amended report indicating modified beneficial ownership structures.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: `Bearish` (Macro `CHoCH` at `11.46` confirmed).
*   **Sortino Sniper Hurdle**: `0.97` (Required: `2.0`). **FAIL**.
*   **Price Action Zone**: Deep Discount (Trading near Macro `VAL` of `9.08`).
*   **Order Block (OB)**: Bearish supply at `10.01` – `10.30`.
*   **Fair Value Gaps (FVG)**: Bearish magnet at `9.61` – `9.74`.
*   **Volume Profile (POC)**: `9.31` (The high-volume node acting as immediate resistance).


---


# 4. Execution Parameters

*   **Execution Authorization**: `WAIT`
*   **Strike Zone (Entry)**: `N/A` (Requires reclaim of `10.30`)
*   **Hard Stop**: `N/A`
*   **Risk Unit (R)**: `$0`
*   **Share Quantity**: `0`
*   **Target (3R)**: `N/A`


---


# 5. Strategic Risk Guardrails

*   **The "Sword" Status**: The growth potential is evident in the `17%` YoY revenue increase, but the "Sword" is currently dull due to technical displacement. 
*   **The "Shield" Status**: Non-existent. A Sortino of `0.97` suggests that any attempt to "buy the dip" carries an uncompensated risk of further drawdown.
*   **Dual-Anchor Protocol**:
    *   **Macro Ceiling**: `13.86`
    *   **Tactical DP**: `10.01`
    *   **Current Alignment**: Price is currently `-9.1%` below the Tactical DP. We do not authorize a "STRIKE" until price reclaims the `10.01` pivot with `RVOL > 2.0`.
*   **MOC Exit Alert**: If an experimental "Scout" position were held (not recommended), it would be subject to immediate liquidation if price closes a 5-minute candle below the `VAL` of `9.08`.

**Final Directive**: No trade. Institutional distribution and insider selling are the dominant forces. Await a structural shift and mathematical improvement in volatility recovery.