> **Generated:** Friday, May 08, 2026 at 12:06 PM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**STRIKE Authorized**


The Sniper Strategy has triggered a high-conviction **STRIKE** authorization for **INVE**. Following a decisive institutional Change of Character (`CHoCH`) at the `$3.90` level, price has transitioned into a momentum-driven expansion phase. The current price action is trading well above the Tactical Value Area High (`VAH`) of `$4.71`, suggesting that former resistance has been completely absorbed by institutional demand. 


The rationale for this entry is anchored in the elite risk-adjusted performance profile, evidenced by a **Sortino Ratio** of `4.61`. This indicates that the vast majority of current volatility is skewed to the upside, minimizing the "downside noise" typically found in retail-heavy tickers. With the macro trend realigned to bullish, we are hunting the extension toward the external liquidity pool at `$5.44` and beyond.


---


# 2. Institutional News & Social Sentiment

**Sentiment Synthesis**: Bullish momentum is being fueled by tangible product expansion and a transition from "Sell" to "Hold/Buy" ratings among institutional analysts. Social sentiment is beginning to reflect "Aggressive Accumulation" as the stock crosses key technical moving averages.


*   **Identiv Expands ID-Safe NFC Tag Portfolio** (5d ago) | **Bullish**  
    Source: Packaging News – *Expansion of the ID-Safe portfolio to combat counterfeiting across multiple industries.*


*   **Identiv Sets First Quarter 2026 Earnings Call for May 13, 2026** (3d ago) | **Neutral**  
    Source: Moomoo – *Company to discuss financial results; typically provides a volatility catalyst.*


*   **Identiv (NASDAQ:INVE) Rating Increased to Hold at Wall Street Zen** (10d ago) | **Bullish/Neutral**  
    Source: MarketBeat – *Upgrade from previous bearish sentiment, establishing a moderate buy consensus with a target of `$5.33`.*


*   **Identiv Stock Crosses Above 200-Day Moving Average** (11d ago) | **Bullish Technical**  
    Source: MarketBeat – *Technical breakout above the `$4.00` psychological level, confirming a long-term trend shift.*


---


# 3. Structural Audit & SMC Metrics

*   **Institutional Trend**: Bullish (Confirmed via Macro `CHoCH` at `$3.90`).


*   **Market Structure**:
    *   **Tactical Displacement Pivot**: `$4.50` (The current support floor).
    *   **Premium/Discount Zone**: Currently in the **Premium Zone**; momentum protocol is active.
    *   **Liquidity Targets**: Major buy-side liquidity sitting at `$5.44`.


*   **Institutional Footprint**:
    *   **Fair Value Gaps (FVG)**: Bullish imbalance identified between `$4.39` and `$4.50`.
    *   **Order Blocks**: Primary institutional accumulation zone located at `$3.50` - `$3.76`.


---


# 4. Volume Profile Analysis

*   **Tactical POC (Point of Control)**: `$3.86`
*   **Tactical VAH (Value Area High)**: `$4.71`
*   **Tactical VAL (Value Area Low)**: `$3.58`


**Analysis**: Price is currently operating in a "Thin Air" zone above the Tactical Value Area. This high-velocity environment is ideal for the **Sniper Strategy**, as there is minimal overhead volume to impede the move toward the `$5.44` target.


---


# 5. Execution Parameters

*   **Strike Zone (Entry)**: `$5.15` - `$5.16`
*   **Hard Stop**: `$4.90` (Placed below the intraday low-volume node)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `961 Shares`
*   **Profit Target (+3R)**: `$5.94`
*   **Sortino Ratio**: `4.61` (Threshold `2.0` passed)
*   **ATR (5m)**: `$0.04`


---


# 6. Risk Guardrails & Management

*   **Kill Switch**: A break below `$4.89` invalidates the momentum narrative and triggers an immediate full liquidation.
*   **Scale-In**: No scaling authorized for this trade; enter with full `1R` exposure at the Strike Zone.
*   **MOC Exit**: If the target is not reached by `3:55 PM ET`, close all laggard positions to avoid overnight gap risk.
*   **Trailing Stop**: Move stop to break-even once price clears the `$5.44` liquidity pool. Aggressively trail the stop upon touching `$5.50`.