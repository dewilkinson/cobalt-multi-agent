> **Generated:** Friday, May 01, 2026 at 07:23 PM

# LLY Resident Analysis Report

> **Generated:** Friday, May 01, 2026 at 07:23 PM

# 1. Execution Summary


**WAIT (Retain Cash)**


Eli Lilly ($LLY$) is currently trapped in a high-volatility structural transition that prohibits a "STRIKE" authorization under the Sortino Sniper mandate. While the intraday price action shows a `3.25%` bounce, the institutional tape remains under heavy pressure following a decisive **Bearish Break of Structure (BoS)** at `$993.58`. 


Critically, the asset’s **Sortino Ratio of 1.14** significantly fails our tactical hurdle of `2.0`. This indicates that the recent downside volatility is not being adequately compensated by recovery alpha, making it a high-risk "Sword" that lacks the necessary mathematical protection for an IRA deployment. We will remain on the sidelines until the price reclaims the **Tactical Displacement Pivot (DP)** and the Sortino math stabilizes.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bearish (MTF Alignment)**
    *   The primary trend has shifted following institutional displacement below the `$993.58` level.


*   **Market Structure (Dual-Anchor Protocol)**:
    *   **Macro Ceiling (Cycle High)**: `$1,133.95`
    *   **Tactical DP (Displacement Pivot)**: `$993.58` (The "Line in the Sand" for a bullish reversal).
    *   **Current Position**: Trading in a **Discount Zone** relative to the 60-day range, but lacking a **CHoCH** (Change of Character) to confirm a bottom.


*   **Volume Profile Clusters**:
    *   **Macro POC (60d)**: `$1,045.38` (Massive overhead supply).
    *   **Tactical POC (5d)**: `$924.73` (Current magnet and local support).
    *   **Value Area Low (VAL)**: `$933.18`.


*   **Institutional Footprint**:
    *   **Bearish Order Block**: `$925.99` – `$976.68` (Price is currently stalling within this supply zone).
    *   **Fair Value Gap (Magnet)**: `$900.42` – `$902.23` (Unfilled liquidity gap below).


---


# 4. Mathematical Hurdles


*   **Sortino Ratio**: `1.14` (**FAIL**; Hurdle is `2.0`)
*   **RVOL**: `1.2` (Baseline Institutional Intent).
*   **Daily ATR**: `$32.79`.
*   **Downside Deviation**: `0.15%`.


---


# 5. Execution Parameters (Contingent)


Should the structure shift to a **Bullish CHoCH** on a 1-hour close above `$993.58`, the following parameters are authorized for a **SCOUT** entry:


*   **Execution State**: **WAIT**
*   **Risk Tier**: **SCOUT** (`0.5R` due to Sortino failure)
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$968.00` – `$975.00`
*   **Hard Stop**: `$935.00` (Below Tactical POC)
*   **Trailing Anchor**: `1R` Trailing Stop once target one is hit.
*   **Share Quantity**: `7 Shares` (`$250` / (`$971` - `$935`) = `6.94`)


---


# 6. Risk Guardrails & Kill Switch


*   **The "Sword" Warning**: $LLY$ is currently exhibiting "Falling Sword" characteristics. Do not attempt to "front-run" the institutional pivot. 
*   **Kill Switch**: A break and hold below `$921.37` (Tactical VAL) invalidates all long-side interest and suggests a deeper correction toward the macro discount zone of `$850.00`.
*   **MOC Exit**: If a scout position is entered and the VIX spikes above `25`, exit at `3:55 PM ET` regardless of P/L.