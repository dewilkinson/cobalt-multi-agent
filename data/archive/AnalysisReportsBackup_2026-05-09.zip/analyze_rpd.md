> **Generated:** Monday, May 04, 2026 at 06:57 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary

**WAIT (Retain Cash)**. RPD is currently exhibiting a fragmented technical profile that fails the Sniper Strategy’s "Asymmetry Mandate." While the **Sortino Ratio** is robust at `2.94`, proving the asset's historical ability to recover from downside deviation, the **Institutional Macro Trend** is strictly **Bearish** following a significant Break of Structure (BOS) at `$13.21`. 


The execution trigger on the 5-minute "Scope" chart currently shows accumulation without a confirmed **Liquidity Sweep** or **Change of Character (CHoCH)**. Entering now would be "fighting the tape" against established Smart Money displacement. We will remain on the sidelines until a clear bullish reversal pattern aligns with institutional displacement.


---


# 2. Institutional News & Social Sentiment

`[DATA_UNAVAILABLE]`


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bearish**. The daily chart confirms a major **Break of Structure (BOS)** at `$13.21`, indicating that high-level institutional flow is positioned to the downside.


*   **The Anchor (Order Blocks)**: 
    *   **Bearish OB**: `$6.87` — `$7.17` (Immediate overhead supply zone).
    *   **Bullish OB**: `$15.95` — `$16.28` (Distal macro target, currently irrelevant for tactical entry).


*   **The Displacement (FVG)**: 
    *   A significant **Bearish Fair Value Gap** exists between `$5.95` and `$6.08`. Price is currently hovering just above this zone, suggesting a potential magnet for a further liquidity hunt.


*   **Volume Profile Context**:
    *   **60-Day POC**: `$6.21` (Price is currently trading just above the high-volume node).
    *   **60-Day VAH**: `$8.44`.
    *   **60-Day VAL**: `$4.97`.
    *   **Tactical POC (5-Day)**: `$5.82`.


---


# 4. Mathematical Hurdle (Sortino Sniper)

*   **Metric**: **Day Trading Sortino Ratio**
*   **Result**: `2.94` (**PASS**)
*   **Threshold**: `≥ 2.0`
*   **Analysis**: From a pure volatility-adjusted return perspective, RPD is an "A-Tier" candidate. The downside deviation of `0.53%` is remarkably low for a stock experiencing a `-$0.78` intraday move. This suggests that the current selling is orderly rather than a "Sword Crash," but the technical structure has not yet bottomed.


---


# 5. Volatility & ATR Projection

*   **Daily ATR**: `$0.40`.
*   **Current Price**: `$6.35`.
*   **Expected Session Range**: Based on the ATR, we anticipate a tactical floor near `$5.95` (aligning with the Bearish FVG and POC) and a tactical ceiling near `$6.75`. 


---


# 6. Risk Guardrails & Execution Parameters

*   **Status**: **WAITING FOR TRIGGER**.


*   **Sniper Entry Requirements**:
    1.  **Liquidity Sweep**: Must see a clear "Stop Hunt" below the Tactical POC of `$5.82`.
    2.  **CHoCH**: A 5-minute displacement breaking above the local internal high.
    3.  **Dual-Anchor Reclamation**: Price must reclaim the **EMA 50** and the **Tactical POC** of `$6.21` on high RVOL.


*   **Stop Loss Placement**: Strictly at the low of the future Liquidity Sweep wick.


*   **Profit Target (3R)**: Initial target would be the lower boundary of the Bearish Order Block at `$6.87`.


---


**Analyst Note**: RPD's `2.94` Sortino Ratio makes it a high-priority watch-list item. However, as a Sniper, we do not front-run the turn. We wait for the Smart Money to leave their footprint (CHoCH) before deploying the `$250` Risk Unit. Retain cash.