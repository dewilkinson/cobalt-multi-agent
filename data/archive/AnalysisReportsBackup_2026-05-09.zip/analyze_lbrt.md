> **Generated:** Friday, May 08, 2026 at 01:29 PM

Active Strategy: Shield Strategy


# 1. Execution Summary

**SCOUT Authorized**

`LBRT` demonstrates high structural integrity and institutional commitment, aligning with the **Shield Strategy** requirements for portfolio protection and yield-backed stability within the Blueshell Securities "War Barbell." With a **Sortino Ratio** of `2.50`, the asset significantly exceeds our mandatory `2.0` hurdle, proving efficient downside management. The perfect alignment of the 1-day and 5-day Point of Control (POC) at `$32.85` confirms an active institutional defensive line where "Smart Money" is currently anchored.

The technical narrative is one of high-volume absorption. Despite news of a `$500M` convertible note offering and minor insider selling by the Chairman, price action remains resilient at the `$32.80` - `$33.00` level. This suggests new institutional buyers, such as Vanguard, are absorbing supply to build long-term defensive positions. As a "Shield" asset, `LBRT` provides both energy macro-exposure and a `$0.09` per share dividend, serving as a robust hedge against volatility.


---


# 2. Institutional News & Social Sentiment

*   **Chairman Insider Sale** (Investing.com | 3d ago): Chairman William F. Kimble sold `7,350` shares totaling `$249,312` as the stock neared 52-week highs.
*   **Vanguard Stake Disclosure** (Stock Titan | 5d ago): Vanguard reported a beneficial ownership of `10,584,957` shares, a `6.53%` stake in `LBRT`, providing a massive institutional floor.
*   **Capital Raise** (Quantisnow | 4d ago): Liberty Energy announced a proposed offering of `$500M` in convertible senior notes to bolster the balance sheet.
*   **Q1 Earnings Beat** (TradingView | 2w ago): The company reported better-than-expected Q1 `2026` earnings and revenues, driven by technological innovation and strong operational execution.
*   **Social Sentiment**: General sentiment across Reddit and Twitter remains **Somewhat Bullish**, with retail traders focusing on the stock's `70%` year-to-date run and its status as a "top-tier" energy services play, though some caution is noted regarding overvaluation at current levels.


---


# 3. Structural Audit & Tape Reading

*   **Institutional Bias**: **Bullish** (Confirmed by 1d BOS at `$20.96`)
*   **Market Structure**: 
    *   **Macro Ceiling**: `$34.57` (Tactical VAH)
    *   **Tactical Pivot (Anchor)**: `$32.85` (Dual-Anchor POC)
    *   **Current Zone**: **Premium** (Trading near highs, necessitating a Scout entry).
*   **Institutional Footprint**:
    *   **Primary Magnet**: `$29.53` - `$31.41` (Bullish FVG / Shield Support).
    *   **Hard Floor**: `$25.83` - `$26.92` (Bullish Order Block).
    *   **Target Liquidity**: `$34.50`+ (External Liquidity Pool).


---


# 4. Mathematical Hurdles

*   **Sortino Ratio**: `2.50` (**PASS**)
*   **RVOL**: `1.2` (Institutional Accumulation baseline met)
*   **Volatility (ATR)**: `0.08` (Low intraday volatility, ideal for Shield stability)
*   **Analysis**: The Sortino result indicates that for every unit of downside volatility, the asset provides `2.5` units of return. This is a superior metric for a Shield position, ensuring the asset protects the portfolio during broader market pullbacks.


---


# 5. Execution Parameters

*   **Execution State**: **SCOUT Authorized**
*   **Risk Unit (R)**: `$125` (0.5R sizing for Premium Zone)
*   **Strike Zone (Entry)**: `$32.50` - `$32.85`
*   **Hard Stop**: `$31.40`
*   **Share Quantity**: `86` Shares
*   **Profit Target (Initial)**: `$37.20` (`3:1` RR)


---


# 6. Risk Guardrails

*   **Kill Switch**: `$31.00`. A loss of the Fair Value Gaps (FVG) zone at `$31.00` invalidates the Shield thesis and requires an immediate exit.
*   **Tactical Narrative**: `LBRT` is currently acting as a "Reinforced Wall." The convergence of the 1d and 5d POCs exactly at `$32.85` creates a high-probability pivot or "Anchor Point." We deploy a Scout position here to lock in the structural support, ready to scale to a full Strike if the Macro Ceiling at `$34.57` is breached with volume.
*   **Portfolio Impact**: This position balances the "Sword" (fast-growth) elements of the portfolio by providing a steady, high-Sortino anchor that benefits from institutional accumulation.