> **Generated:** Friday, May 08, 2026 at 11:01 AM

Active Strategy: Shield Strategy


---


# 1. Execution Summary


**STRIKE Authorized**


WSC has transitioned into a primary **Shield** asset following an institutional re-rating. The stock has delivered a massive structural breakout of `12.47%`, driven by a Q1 2026 earnings beat that defied previous bearish construction-sector narratives. With a **Sortino Ratio** of `8.46`, WSC offers exceptional downside protection and efficiency, making it a superior stabilizer for the portfolio barbell.


The technical "tape" confirms a **Value Breakout** with high relative volume (`3,456,511` shares). Price has successfully cleared the tactical ceiling at `$24.55`, shifting the macro character from accumulation to expansion. We are authorizing a full **STRIKE** deployment on a retest of the current consolidation zone, utilizing the stock's low downside deviation to maintain a tight risk profile.


---


# 2. Institutional News & Social Sentiment


*   **Earnings Call: WillScot Mobile Mini beats Q1 2026 forecasts** (Investing.com) | **2h ago**
    *   Reported strong earnings surpassing analyst expectations with an EPS of `$0.21` and revenue of `$549 million`.


*   **WillScot faces earnings test as construction activity slows** (Investing.com) | **5h ago**
    *   Initial bearish sentiment regarding non-residential construction slowdown was neutralized by the subsequent earnings surprise.


*   **Trading Systems Reacting to (WSC) Volatility** (Stock Traders Daily) | **1d ago**
    *   Institutional AI systems identified strong near and mid-term sentiment shifts despite a previously weak long-term outlook.


*   **WillScot Mobile Mini Hits Day Low at $17 Amid Price Pressure** (Markets Mojo) | **Historical context**
    *   Previous liquidity sweeps at the `$17.00` level formed the "Shield Floor" where the current bullish order block was established.


**Social Sentiment Synthesis**: Sentiment has pivoted from "Bearish/Caution" to "Aggressive Accumulation." Institutional desks are rotating into WSC as a lean, cash-flow-positive industrial shield, offsetting broader market volatility.


---


# 3. Structural Audit & Tape Reading


*   **Institutional Bias**: **Bullish** (Expansion Phase)


*   **Market Structure**:
    *   **CHoCH (Change of Character)**: Confirmed at `$24.55`.
    *   **Macro Ceiling**: `$27.78` (Current test of 1d distribution highs).
    *   **Tactical Displacement Pivot**: `$24.55` (The level where sellers were absorbed).


*   **Institutional Footprint**:
    *   **Fair Value Gap (FVG)**: `$21.29` - `$24.55` (Acts as the structural safety net).
    *   **Order Block**: `$16.52` - `$17.34` (The foundational support zone).
    *   **Session POC**: `$22.63` (The high-volume springboard for today's move).


---


# 4. Mathematical Hurdle (Sortino)


*   **Hurdle Result**: **PASS**


*   **Sortino Ratio**: `8.46`


*   **Downside Deviation**: `0.33%`


**Analysis**: The `8.46` Sortino is a top-tier metric for a Shield strategy. It indicates that the stock's recent volatility is almost entirely skewed to the upside, providing the "Shield" effect of protecting capital while participating in growth.


---


# 5. Execution Parameters


*   **Execution State**: **STRIKE**


*   **Strike Zone (Entry)**: `$27.10` - `$27.35`


*   **Hard Stop**: `$26.10`


*   **Risk Unit (R)**: `$250`


*   **Share Quantity**: `250` Shares


*   **Risk/Reward Profile**: `3:1` Minimum Target


---


# 6. Risk Guardrails


*   **Kill Switch**: A daily close below `$24.55` invalidates the structural breakout and the Shield thesis.


*   **Tactical Narrative**: We are entering WSC to capitalize on the momentum shift following the earnings beat. The objective is to utilize WSC as a core "Shield" position in the IRA. The stop loss at `$26.10` is placed below the local structural pivot and liquidity sweep zone to ensure the position is protected from minor morning "noise" while adhering to the `1R` risk mandate.


*   **Volatility Warning**: Monitor for profit-taking at the `$27.80` sell-side liquidity pool. If price fails to hold the `$27.00` handle, revert to a **PROBE** (0.5R) sizing.