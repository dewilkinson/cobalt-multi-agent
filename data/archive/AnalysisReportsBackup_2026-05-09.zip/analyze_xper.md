> **Generated:** Friday, May 08, 2026 at 04:26 PM

Active Strategy: Sniper Strategy


# 1. EXECUTION SUMMARY


**STRIKE Authorized**


XPER has executed a definitive macro **CHoCH** (Change of Character) at `$6.3150`, shifting the long-term institutional bias from neutral to aggressively bullish. The "Sniper" protocol identifies this as a high-velocity momentum play triggered by a significant earnings beat and revenue expansion. With a **Sortino Ratio** of `3.14`, the stock is demonstrating elite risk-adjusted performance, meaning the recent volatility is heavily concentrated in the upward price action. 


The trade rationale is based on institutional price acceptance above the previous macro ceiling. We are targeting a continuation of the earnings-induced gap-up, utilizing the newly formed Fair Value Gaps (FVG) as structural support. As a "Sword" asset in the Dave Wilkinson portfolio, XPER provides the high-growth potential required for the current interest rate environment, provided we maintain a strict `4:1` Reward-to-Risk ratio.


***


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Xperi (XPER) Q1 earnings and revenues surpass estimates** (MSN) | **Bullish** | *1d ago*
    > Reported adjusted EPS of `$0.06`, significantly higher than the anticipated loss.


*   **Xperi Inc. Up Over 12%, On Track for Largest Percent Increase Since May 2025** (Moomoo) | **Bullish** | *18h ago*
    > Stock experiencing a high-volume surge, poised for multi-year technical breakout.


*   **Xperi targets TiVo One ARPU to move toward double-digit dollars in H2 2026** (MSN) | **Bullish** | *20h ago*
    > Media Platform revenue surged `45%` to `$12,000,000`, signaling successful monetization of the connected car platform.


*   **DTS AutoStage Is Now in 16 Million Vehicles, Xperi Reports** (Radio World) | **Bullish** | *22h ago*
    > Technology expansion reached `13` automotive brands, reinforcing the fundamental growth narrative.


*   **Social Sentiment Synthesis**:
    > Institutional sentiment is heavily skewed positive following the profitability swing. Discussion on Reddit and Twitter (X) centers on the TiVo One growth and the IP licensing spinoff, with "Smart Money" appearing to accumulate on the break above `$7.00`.


***


# 3. TECHNICAL & SMC METRICS


*   **Current Tape Price**: `$8.03`
*   **Daily Change**: `+4.02%`
*   **Macro Structure**: **Bullish** (Confirmed CHoCH at `$6.3150`)
*   **Institutional Order Blocks (OB)**:
    *   Primary: `$5.4500` - `$5.5700`
    *   Secondary: `$5.0650` - `$5.6300`
*   **Fair Value Gaps (FVG)**:
    *   `$7.0200` - `$7.5670` (High Probability Support)
    *   `$6.6900` - `$6.9400`
*   **Volume Profile Analytics**:
    *   **POC (Point of Control)**: `$6.67`
    *   **VAH (Value Area High)**: `$7.02`
    *   **VAL (Value Area Low)**: `$5.81`
*   **Sortino Ratio**: `3.14` (Exceeds `2.0` Hurdle)
*   **Volatility (ATR 5m)**: `$0.03`


***


# 4. EXECUTION PARAMETERS


*   **Strategy**: **SNIPER** (40% WR | 4:1 RR)
*   **Risk Unit (R)**: `$250`
*   **Strike Zone (Entry)**: `$7.95`
*   **Hard Stop**: `$7.65`
*   **Share Quantity**: `833` **Shares**
*   **Target (4R)**: `$9.15`


***


# 5. RISK GUARDRAILS


*   **Max Account Risk**: `0.25%` (Based on `$100,000` NAV and `$250` Risk Unit)
*   **Kill Switch**: `$7.50`. If price accepts below the top of the `$7.02` FVG, the immediate momentum thesis is invalidated.
*   **Tactical Note**: As a "Sniper" entry, we are looking for immediate expansion. Do not hold this position if price stagnates at the `$8.00` level for more than two hours without making a new session high.
*   **Scale-In**: Only authorized if the first unit is at Break-Even (Price > `$8.25`).


***


**Status**: **Execution Authorized**. Move to STRIKE state on the next 5m consolidation at `$7.95`.