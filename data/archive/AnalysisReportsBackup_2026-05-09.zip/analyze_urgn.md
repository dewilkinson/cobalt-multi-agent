> **Generated:** Friday, May 08, 2026 at 11:54 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**STRIKE Authorized**


URGN has achieved a massive structural expansion, clearing the `$22.50` Macro Ceiling with high velocity. The **Sortino Ratio of 5.94** is elite, confirming that the current move is driven by extreme positive drift with negligible downside volatility. Price is currently in "Thin Air" above the 60d Macro VAH (`$23.48`), indicating a pure momentum chase by institutional players. 


This is a classic "Sword" play—a high-velocity growth asset accelerating as it enters a price discovery phase. The technical structure shows a confirmed Bullish Change of Character (**CHoCH**) on the daily timeframe, supported by an aggressive institutional footprint. We are deploying a full **STRIKE** unit to capture the extension toward the next psychological liquidity pool at `$31.50`.


---


# 2. Institutional News & Social Sentiment


`[DATA_UNAVAILABLE]`


---


# 3. Execution Parameters


*   **Execution State**: **STRIKE**
*   **Strike Zone (Entry)**: `$29.50` - `$29.70`
*   **Hard Stop**: `$28.70`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `250` Shares
*   **Target (4:1 RR)**: `$33.70`


---


# 4. Technical Structural Audit


**Institutional Flow & Market Structure**


*   **Macro Trend**: **Bullish** (CHoCH confirmed at `$22.50`)
*   **Key Order Block (OB)**: `$22.61` - `$24.58` (Primary defensive base)
*   **Fair Value Gap (FVG)**: `$24.94` - `$25.36` (Unfilled institutional efficiency)
*   **60d POC**: `$19.12`
*   **5d VAH**: `$27.36` (Current price is trading significantly above value)


**Efficiency & Volatility Metrics**


*   **Sortino Ratio**: `5.94` (Passes the Sniper `2.0` hurdle)
*   **Daily ATR (5m)**: `0.34`
*   **Relative Strength**: `+13.23%` vs Benchmark
*   **Volume**: `1,046,233` (Significant institutional accumulation detected)


---


# 5. Risk Guardrails & Strategy Narrative


**The Sword Logic**
URGN has transitioned from a structural "Shield" to a high-velocity "Sword." The expansion is mathematically backed by a `5.94` Sortino, suggesting that the risk of a "rug pull" is statistically lower than the probability of continued momentum. 


**Kill Switch Protocol**
If price violates `$28.50`, the intraday momentum narrative is invalidated. As a Sniper, we do not average down. We exit immediately if the `$28.70` hard stop is triggered. 


**Tactical Management**
*   **Scale-In**: Only add to the position if the first unit reaches Break-Even (BE).
*   **MOC Exit**: If volatility spikes and VIX hits `> 25`, close laggards at `3:55 PM`.
*   **Liquidity Target**: We are looking for a sweep of the `$30.45` level before trailing the stop to lock in gains.