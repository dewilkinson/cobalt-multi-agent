> **Generated:** Friday, May 08, 2026 at 11:44 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


**SCOUT Authorized**


OUST has completed a Macro CHoCH at `25.07`, signaling a structural shift to bullish institutional intent. However, the price is currently trading beneath the Tactical POC of `26.95` and within a bearish order block. The **Sortino Ratio** of `1.99` sits just below the strict `2.0` mathematical hurdle required for a full deployment. Consequently, we are authorizing a half-size **SCOUT** entry to probe the position while maintaining strict risk mitigation. A transition to a full **STRIKE** will be considered upon a clean reclamation of the high-volume node at `26.95`.


***


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


***


# 3. Execution Parameters


*   **Execution State**: **SCOUT** (0.5R)
*   **Strike Zone (Entry)**: `$25.23`
*   **Hard Stop**: `$24.23`
*   **Risk Unit**: `$125`
*   **Share Quantity**: `125 Shares`
*   **Target (1R Primary)**: `$27.15` (Liquidity Pool)
*   **Target (Apex)**: `$30.49` (Cycle Resistance)


***


# 4. Structural SMC Audit


*   **Institutional Trend**: **Bullish**
*   **Structural Pivot (CHoCH)**: `25.07` (Confirmed)
*   **Market Alignment**:
    *   **Macro (1d)**: Bullish expansion following the `25.07` breakout.
    *   **Tactical (1h)**: Consolidating within a bearish order block (`22.13` - `25.07`).
*   **Order Blocks**:
    *   **Bullish Demand**: `16.40` - `18.15`
    *   **Bearish Supply**: `22.13` - `25.07`
*   **Fair Value Gaps (FVG)**:
    *   **Bullish Magnet**: `25.49` - `27.30`
    *   **Bearish Resistance**: `26.57` - `27.15`


***


# 5. Tri-Mandate Volume Profiling


*   **Macro POC (60d)**: `21.39` (Institutional Accumulation Floor)
*   **Tactical POC (5d)**: `26.95` (Current Overhead Resistance)
*   **Value Area High (VAH)**: `29.57`
*   **Value Area Low (VAL)**: `24.81`
*   **Profile Narrative**: Price is currently trading in a "no-man's land" between the tactical **VAL** and **POC**. The current position is a **Discount** entry relative to the weekly range but a **Premium** entry relative to the macro 60-day floor.


***


# 6. Risk & Performance Metrics


*   **Sortino Ratio**: `1.99` (Result: **FAIL**)
*   **Volatility (ATR 5m)**: `0.24`
*   **Daily Stop Level**: `3R` (`$750` total account risk)
*   **Asset Classification**: **Sword** (High-alpha potential, interest rate sensitive).
*   **Liquidity Sweep**: **NONE** (Active Accumulation Phase).


***


# 7. Final Analyst Notes


OUST presents a classic **Sniper** setup where structural intent has shifted bullish, but the mathematical "Shield" (Sortino) is slightly weakened. We are using the **Sword** for high-growth potential but capping exposure to `0.5R` until the price clears the `27.00` liquidity pool. If a 1-hour candle closes above `27.20`, the protocol permits scaling to a full **STRIKE** (1R) position. 

**Kill Switch**: A close below `24.20` invalidates the intraday bullish structure and triggers an immediate MOC exit.