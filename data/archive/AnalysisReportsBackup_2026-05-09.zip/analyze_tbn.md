> **Generated:** Thursday, May 07, 2026 at 10:53 AM

Active Strategy: Sniper Strategy

---

# 1. EXECUTION SUMMARY


**Execution Authorization: WAIT**


**Rationale**: TBN is currently in a high-volatility price discovery phase following significant equity dilution through a series of capital raises totaling approximately `A$282.6M`. While the macro structure remains technically bullish with a Break of Structure (`BOS`) at `$32.88`, the current tactical environment fails the Sniper entry criteria. The **Sortino Ratio** is deeply negative at `-2.01`, indicating that downside volatility is currently uncompensated by returns. 


Furthermore, the price is currently trading at `$34.99`, which is below both the tactical Point of Control (`POC`) of `$35.50` and the institutional offering floor of `$35.00`. In the Sniper protocol, we do not fire into high-supply dilution gaps. We wait for the "recoil" and stabilization above the institutional anchor.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT


*   **Tamboran (TBN) prices underwritten and institutional stock offerings** (Source: Stock Titan, ~2h ago) 
*   **Bryan Sheffield group (TBN) lifts Tamboran stake via $35 share offer** (Source: Stock Titan, ~3h ago)
*   **RBC upgrades Tamboran Resources stock rating on Beetaloo momentum** (Source: Investing.com, ~5h ago)
*   **Tamboran Resources completes equity offerings raising over $50 million** (Source: Investing.com, ~6h ago)
*   **Tamboran Resources secures US$198M for Beetaloo growth** (Source: Yahoo Finance, ~8h ago)


**Synthesis**: The prevailing narrative is dominated by a massive capital injection intended to fast-track the Beetaloo gas development. Social and institutional sentiment is polarized; while analysts (RBC) and insiders (Sheffield/Pace) are showing high-conviction accumulation, the sheer volume of new shares hitting the market is creating a "supply overhang." The market is currently "digesting" this float, pinning the price near the `$35.00` offering level.


---


# 3. TECHNICAL STRUCTURAL AUDIT


*   **Macro Institutional Trend**: Bullish (Confirmed by `BOS` at `$32.8799`)


*   **Tactical Price Action**: Bearish/Consolidating
    *   Current Price: `$34.99`
    *   Change: `-2.18%`


*   **Volume Profile Mapping (Macro)**:
    *   **Value Area High (VAH)**: `$49.79`
    *   **Point of Control (POC)**: `$35.89`
    *   **Value Area Low (VAL)**: `$30.45`


*   **Institutional Footprint (SMC)**:
    *   **Bearish Fair Value Gap (FVG)**: `$37.43` - `$42.63` (Target Magnet)
    *   **Bullish Order Block**: `$28.25` - `$29.79` (Safety Zone)
    *   **Liquidity Pool**: Sell-side liquidity rests at `$33.71`.


---


# 4. MATHEMATICAL HURDLE (SORTINO)


*   **Metric**: Day Trading Sortino Ratio
*   **Value**: `-2.01`
*   **Status**: **FAIL**


**Analyst Note**: The Sniper Strategy requires a Sortino Ratio `>= 2.0` for a high-probability **STRIKE**. A negative value indicates that current price action is erratic and dominated by downside risk. Tactical deployment is prohibited until the ratio pivots positive.


---


# 5. EXECUTION PARAMETERS


If the trigger is met (Liquidity sweep of `$34.00` followed by 5m Change of Character), the following parameters apply:


*   **Strike Zone (Entry)**: `$35.10`
*   **Hard Stop**: `$33.60`
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `166 Shares`
*   **Target (4:1 RR)**: `$41.10`


---


# 6. RISK GUARDRAILS


*   **Daily ATR**: `0.28`
*   **Kill Switch**: A daily close below `$32.80` invalidates the macro bullish thesis and triggers a full strategy reset.
*   **Liquidity Warning**: Current volume is `72,276`. This is below the required `100,000` pre-market threshold for high-conviction Sniper entries. 


**Tactical Summary**: Snipers wait for the recoil. The institutional floor is at `$35.00`. We allow the market to sweep the local lows near `$34.00` to clear out weak retail hands before considering a long position. Until the negative Sortino is resolved, cash remains the primary position.