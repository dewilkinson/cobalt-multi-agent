> **Generated:** Thursday, May 07, 2026 at 11:19 AM

Active Strategy: Shield Strategy


# 1. EXECUTION SUMMARY

**Execution Authorization: STRIKE Authorized**


NBIS (Nisun International Enterprise Development Group Co., Ltd.) is currently designated as a primary **SHIELD** asset for the Blueshell Securities LLC War Barbell. The ticker demonstrates elite risk-adjusted performance with a **Sortino Ratio** of `7.01`, signifying that the prevailing volatility is almost exclusively concentrated in upside price discovery rather than downside erosion. This profile is the mathematical ideal for the defensive "Shield" role, providing a high-fidelity buffer against broader market drawdown.


Structural alignment is confirmed across all timeframes. Institutional accumulation is evident following the **Macro CHoCH** at `110.50`, with the asset currently stabilizing in a premium structural zone. Despite a localized bearish liquidity sweep at `188.25`, the tape shows significant absorption, as price maintains its floor above the recent consolidation. This trade is authorized as a "Shield" deployment to lock in steady growth while minimizing portfolio downside deviation.


---


# 2. INSTITUTIONAL NEWS & SOCIAL SENTIMENT

`[DATA_UNAVAILABLE]`


---


# 3. EXECUTION PARAMETERS (STRIKE)

*   **Strategy**: Shield Strategy (Capital Preservation / Volatility Buffer)
*   **Strike Zone (Entry)**: `$192.61` (Market Price)
*   **Hard Stop**: `$187.50` (Below liquidity sweep and local consolidation)
*   **Risk Unit (R)**: `$250`
*   **Share Quantity**: `49 Shares`
*   **Target RR**: `3:1` Minimum
*   **Kill Switch (Emergency Exit)**: `$182.34` (Full loss of Bullish FVG support)


---


# 4. QUANTITATIVE ANALYSIS & SMC AUDIT

### **Structural Health**
*   **Macro Trend (1d)**: Bullish (Institutional Pivot at `$110.50`)
*   **Tactical Bias (1h)**: Bullish
*   **Displacement Pivot**: `$188.25` (Level of recent institutional defense)
*   **Value Area Status**: Price is currently trading in a **Premium** zone, significantly above the 60-day **Value Area High (VAH)** of `$125.34`.


### **Liquidity & Volume Profile**
*   **Macro POC (60d)**: `$96.84`
*   **Tactical POC (5d)**: `$159.11`
*   **Institutional Imbalance (FVG)**: `$179.96` - `$184.50` (Primary attraction zone on retracement)
*   **Institutional Order Block**: `$132.70` - `$141.46` (Macro defense floor)


### **Volatility & Risk Metrics**
*   **Sortino Ratio**: `7.01` (Elite risk-efficiency; target is `>= 2.0`)
*   **Downside Deviation**: `0.27%` (Exceptional capital protection profile)
*   **ATR (5m)**: `1.81` (Normal intraday range expectation)
*   **RVOL (Relative Volume)**: Institutional footprints are confirmed by the shift from the `$96.84` Macro POC to the `$159.11` Tactical POC, indicating a fundamental repricing of the asset.


---


# 5. RISK MANAGEMENT PROTOCOL

*   **Sizing**: This position adheres to the `STRIKE` tier (1R) given the VIX is below `24` and the Sortino hurdle has been cleared with a significant margin.
*   **Scaling**: Only add to this unit if the first tranche reaches **Break-Even (BE)** and a new bullish structural break (BOS) occurs above `$197.89`.
*   **Institutional Mandate**: As a **SHIELD** asset, the primary objective is the maintenance of the Sortino Ratio above `2.0`. If downside deviation increases or price breaches the Hard Stop at `$187.50`, the position will be liquidated to preserve the core capital of the `$100k` account.