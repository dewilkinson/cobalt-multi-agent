> **Generated:** Thursday, May 07, 2026 at 11:14 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


- **Recommendation**: **WAIT (Target Sweep)**


- **Rationale**: ZVRA exhibits a clean institutional turnaround story following a profitable Q1 2026 earnings report and the successful clearance of `$63M` in debt. While the **Macro Trend is Bullish** (confirmed by a Break of Structure at `$9.62`), the asset is currently retracting from local highs in a "Premium" zone. The Sniper objective is to wait for a high-probability entry at the **Displacement Pivot (DP)** confluence near `$10.11`.


- **Decision Matrix**: Despite strong fundamentals, the **Sortino Ratio** of `1.79` currently fails the institutional hurdle of `2.0`. This indicates that current downside volatility is slightly elevated for an immediate STRIKE. We are waiting for a volatility compression and a liquidity sweep of the session Point of Control (POC) before deploying capital.


---


# 2. Institutional News & Social Sentiment


- **Zevra Therapeutics Swings to Q1 Profit and Clears Debt** (Stock Titan, 18h ago): Reported a net profit of `$37.9 million`, a massive reversal from prior losses, driven by the SDX portfolio sale which liquidated `$63M` in debt.


- **Earnings Beat & Revenue Growth** (Investing.com, 17h ago): Exceptional Q1 results exceeded analyst forecasts in both earnings and revenue, triggering an initial `6.03%` surge in the stock.


- **FMR LLC (Fidelity) Discloses 5.5% Stake** (Stock Titan, 1d ago): Institutional filing reveals FMR LLC holds `3,211,876` shares, signaling significant "Smart Money" backing and long-term confidence.


- **Social Sentiment Synthesis**: Sentiment across Reddit and specialized biotech forums is highly bullish, focusing on the "cleaned-up balance sheet" and takeover speculation mentioned in recent MSN reports. The narrative has shifted from "risk-heavy biotech" to "profitable growth asset."


---


# 3. Structural Audit & Tape Reading


- **Institutional Trend**: Bullish (MTF Alignment)


- **Market Structure**:
  - **Macro Ceiling**: `$11.40` (Historical Liquidity Pool)
  - **Tactical POC**: `$10.11` (High Volume Gravity Well)
  - **BOS (Break of Structure)**: `$9.62` (Confirms Institutional Trend)
  - **Value Area High (VAH)**: `$10.81`
  - **Value Area Low (VAL)**: `$9.62`


- **Institutional Footprint**:
  - **Fair Value Gap (FVG)**: `$10.50` - `$10.57` (Currently being filled)
  - **Demand Order Block**: `$9.47` - `$9.88` (The primary defensive wall)
  - **Liquidity Profile**: Massive concentration of volume at `$10.11`. Smart money is likely to defend this level on a re-test.


---


# 4. Quantitative Metrics


- **Current Price**: `$10.565`
- **Session Change**: `-6.30%` (Healthy pull-back)
- **Sortino Ratio**: `1.79` (Hurdle: `2.0` | Status: **FAIL**)
- **Volatility (ATR 5m)**: `0.14`
- **RVOL**: Institutional accumulation confirmed via post-earnings volume spike.


---


# 5. Execution Parameters (Sniper Protocol)


- **Status**: **WAIT (Target Sweep)**


- **Strike Zone**: `$10.11` - `$10.20` (Entry on re-test of POC)


- **Hard Stop**: `$9.85` (Below Tactical VAL and Order Block)


- **Risk Unit (R)**: `$250.00`


- **Share Quantity**: `961 Shares`


- **Target 1 (4:1 RR)**: `$11.15`


---


# 6. Risk Guardrails


- **Macro Invalidation**: If price closes below `$9.60`, the bull thesis is liquidated as it breaks the structural BOS.


- **Sword/Shield Classification**: ZVRA is a **Sword** asset (High growth potential). Given the debt clearance, it now possesses a "Shield" fundamental floor, but technical execution must remain disciplined. Revert to `0.5R` SCOUT sizing if 3 consecutive losses occur within the sector.


- **MOC Exit**: If volatility remains above ATR expectations or VIX remains > `25` at 3:55 PM, exit any open intraday laggards.