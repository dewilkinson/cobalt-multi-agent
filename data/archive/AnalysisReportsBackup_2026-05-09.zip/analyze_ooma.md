> **Generated:** Thursday, May 07, 2026 at 10:22 AM

Active Strategy: Sniper Strategy


# 1. Execution Summary


- **Recommendation**: **SCOUT Authorized**


- **Rationale**: OOMA is currently exhibiting a high-velocity structural expansion following a confirmed Macro CHoCH (Change of Character) at `$12.41`. The asset has cleared its primary Macro Value Area High (VAH) of `$14.37` and is operating in a low-volume "Sword" expansion phase. While the Sortino Ratio of `5.54` indicates elite risk-adjusted performance, the current price of `$18.88` is significantly extended from the Tactical Point of Control (POC) at `$16.03`. Consequently, a **SCOUT** (0.5R) deployment is authorized to probe for further upside toward the `$20.00` psychological barrier while maintaining a tight risk tether to account for the extreme premium.


***


# 2. Institutional News & Social Sentiment


[DATA_UNAVAILABLE]


***


# 3. Structural Audit & Tape Reading


- **Bias / Trend**: **Strongly Bullish** (Institutional Markup Phase)


- **Market Structure (Dual-Anchor Protocol)**:
  - **Macro Ceiling**: `$19.06` (Primary cycle resistance node)
  - **Tactical DP (Displacement Pivot)**: `$16.03` (5-Day Tactical Volume Anchor)
  - **BOS/CHoCH**: `$12.41` (Confirmed Institutional Trend Shift)
  - **Positioning Zone**: **Extreme Premium** (Trading above all primary volume value areas)


- **Institutional Footprint**:
  - **Imbalance/FVG**: `$16.50` - `$17.61` (Major liquidity magnet; must hold on any deep retracement)
  - **Order Block (Bullish)**: `$13.44` - `$13.97` (High-conviction accumulation base)
  - **Liquidity Targets**: `$19.10` (External buy-side liquidity pool)


- **Tape Reading**: Buying pressure is aggressively absorbing supply above the `$18.50` level. The lack of a recent liquidity sweep suggests price is being "marked up" by institutional algorithms with high urgency.


***


# 4. Mathematical Hurdle (Sortino)


- **Sortino Ratio**: `5.54`
- **Downside Deviation**: `0.42%`
- **Analysis**: OOMA’s efficiency is exceptional. The `5.54` Sortino confirms that the vertical move is being supported by consistent institutional buying rather than erratic retail volatility. Pullbacks are being shallowly bought, providing the high-fidelity signal required for a **SNIPER** entry.


***


# 5. Execution Parameters


- **Execution State**: **SCOUT** (0.5R)
- **Risk Unit (R)**: `$125`
- **Strike Zone (Entry)**: `$18.88`
- **Hard Stop**: `$17.88`
- **Share Quantity**: `125 Shares`
- **Target (3:1 RR)**: `$21.88`


***


# 6. Risk Guardrails


- **Kill Switch**: Close position immediately if price closes below `$17.60`, as this indicates a failure to hold the high-level Fair Value Gap (FVG).
- **Strategy Note**: This is a "Sword" position. Use an active trailing stop once price clears the `$19.10` liquidity pool. Do not scale to a full 1R **STRIKE** position until a new 15m consolidation base is established above `$18.00`.
- **MOC Exit**: Close laggard exposure at 3:55 PM ET if VIX rises above `25`.