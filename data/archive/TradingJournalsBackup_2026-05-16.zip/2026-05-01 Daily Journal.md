# 2026-05-01 Daily Journal

## Trades
| Symbol | Direction | Entry | Exit | PnL | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| | | | | | |

## Notes
- 
