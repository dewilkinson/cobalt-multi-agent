# Project Cobalt | Daily Post-Mortem: 2026-05-15
**Analyst**: Gemini (Trading Analyst & Risk Manager) **Trader**: Dave Wilkinson

**1. Market Context & Environment**
Today’s session was a masterclass in the psychological battle between momentum chasing and institutional patience. We saw a flurry of activity concentrated in the mid-afternoon, as high-flying "Sword" tickers like QUCY and BW drew aggressive interest. The broader indices seemed to provide a backdrop of relative stability, allowing individual sector narratives—specifically Energy (XLE) and Cybersecurity (CRWD, PANW)—to drive the tape.

However, the environment felt "frothy" in the tactical zones. While the morning analysis for several names like ARMK and STM suggested a disciplined "Shield" approach, the actual execution drifted significantly into "Sword" territory. We saw multiple tickers pushing into extreme overbought territory (RSI > 75) as entries were being clicked. The scanner performed well by flagging the structural setups, but the execution layer struggled with entry efficiency, often buying into the local apex of the move rather than waiting for the institutional pullbacks mapped in the morning context.

**2. Trade-by-Trade Analysis**

**Trade 1: XLE – "The Shield" [Grade: C-]**
- **Setup**: Structural consolidation in Energy.
- **Analysis**: Entries at 13:08-13:09 ($59.13-$59.14) were technically "low efficiency." The intraday snapshot showed a Sortino of 1.83 and RVOL of 0.86, both failing the institutional hurdle for a STRIKE. You essentially bought a laggard with weak institutional participation.
- **The Tape**: Price was holding above the $56.71 POC, but without the RVOL engine, it was a slow grind.
- **Result**: Small win (+$0.21/share).
- **Grade**: C- | *Note: Metric failure (Sortino < 2.0). Result does not justify the protocol breach.*

**Trade 2: QUCY – "The Sword" [Grade: F]**
- **Setup**: Parabolic Momentum Chase.
- **Analysis**: This was the primary contributor to today's P/L drag. After small probing buys at $3.75, you aggressively added 200 shares at $4.17 (13:28). The RSI was a screaming 70.78 and price was astronomical relative to the $0.59 POC. This is the definition of "buying the top."
- **The Tape**: You were exit liquidity for the early morning accumulators.
- **Result**: Significant Loss (-$0.34/share on the heavy add).
- **Grade**: F | *Note: Severe FOMO sizing at the local high. Total disregard for POC distance.*

**Trade 3: TH – "The Shield" [Grade: B+]**
- **Setup**: Value Area Entry.
- **Analysis**: This was one of your cleanest executions. Entry at $18.74 (13:29) aligned with a Sortino of 4.23 and RVOL of 1.25. You caught a ticker with actual institutional support.
- **The Tape**: Price was well above POC but supported by a healthy RSI of 67.
- **Result**: Profit (+$0.06/share).
- **Grade**: B+ | *Note: Good selection, though exit could have been extended.*

**Trade 4: CRWD – "The Shield" [Grade: D]**
- **Setup**: Premium Zone Expansion.
- **Analysis**: Entries at $595-$596 (13:30) were taken with an RSI of 76.94. You bought into a vertical move that had already traveled nearly $150 from the POC ($453). 
- **The Tape**: Overextended. No institutional "shield" exists at an RSI of 77.
- **Result**: Small Loss.
- **Grade**: D | *Note: Chasing premium in a defensive asset.*

**Trade 5: HUM – "The Shield" [Grade: F]**
- **Setup**: Direct Protocol Breach.
- **Analysis**: The morning directive was **SCOUT at $297.50 - $298.50**. You entered at $309.14 (13:31) into an RSI of 74.31. You ignored the mapped FVG and bought the local peak.
- **The Tape**: Massive mean-reversion risk realized immediately.
- **Result**: Loss (-$1.50/share).
- **Grade**: F | *Note: Explicit violation of the $298 Strike Zone directive.*

**Trade 6: PCT – "The Sword" [Grade: B]**
- **Setup**: Momentum Continuation.
- **Analysis**: You scaled into this nicely from $12.62 to $12.82. While the Sortino was high (6.24), the RSI (72) was elevated. However, your scale-in logic worked here.
- **The Tape**: Acceptance above the $7.45 POC was maintained.
- **Result**: Profit (+$0.04 to $0.24 per unit).
- **Grade**: B | *Note: Best "Sword" handling of the day.*

**Trade 7: PANW – "The Shield" [Grade: D-]**
- **Setup**: FOMO Trap.
- **Analysis**: Entry at $245.56 (13:49) with an RSI of **78.87**. This was the absolute ceiling of the 14:00 window.
- **The Tape**: The intraday snapshot showed negative CVD (-5.8M), indicating aggressive selling into your buying pressure.
- **Result**: Loss (-$1.55/share).
- **Grade**: D- | *Note: Buying the literal top against negative delta.*

**Trade 8: BW – "The Sword" [Grade: D]**
- **Setup**: Directive Breach.
- **Analysis**: Morning directive was **WAIT for $15.50**. You bought at $21.44 with an RSI of 81.58. 
- **The Tape**: You got lucky with a small exit at $21.50, but the risk of a 5R flush was extreme here.
- **Result**: Tiny Profit.
- **Grade**: D | *Note: Successful "gamble," but a failure of the Shield methodology.*

**3. Overall Performance & Post-Mortem [Grade: D+]**
**Daily P/L**: $-99.85  **Win/Loss Ratio**: 37.5%  **Average RR**: 0.6:1 (Inverted)

**The Proficiency Check**
- **Daily Grade**: D+
- **Proficiency Level**: Developing (Struggling with Discipline)
- **Sortino Health**: Mixed. While TH and PCT were healthy, the entries into QUCY, HUM, and PANW were mathematically "toxic" due to extreme overextension.

**Strengths**
- **Ticker Selection**: You are finding the right "heat" in the market (BW, QUCY, PCT).
- **Scale-In Logic**: On PCT, your ability to build a winner was evident.

**Weaknesses / Growth Areas**
- **RSI Discipline**: You are consistently buying stocks with RSI > 70. This is the opposite of the "Shield" philosophy.
- **Directive Adherence**: You are ignoring the "WAIT" and "STRIKE ZONE" price levels in favor of market-orders on green candles.

**4. Immediate Next Steps**
- **Action Item**: For tomorrow, **unplug the market order button**. You are only allowed to use LIMIT orders placed within the structural zones (FVG/POC) defined in the morning analysis. If the price doesn't hit your limit, you do not get the trade.
- **Question**: Dave, looking at the HUM and BW trades today—you essentially paid a $10 premium over the recommended entry price just to "be in the move." What was the emotional trigger at 13:30 that made you feel the $298 level wasn't coming back?

*Generated by Project Cobalt | Brain Layer*
