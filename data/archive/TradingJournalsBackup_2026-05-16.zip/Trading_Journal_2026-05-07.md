# Trade Journal - May 07, 2026

## Overview
- **Account**: Dave Wilkinson (Blueshell Securities LLC)
- **Total Realized PNL**: $-612.07

## Trading Activity
| Time | Symbol | Action | Quantity | Price | Total |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 14:50:00 | BAND | SELL | 50.0 | $48.4251 | $2,421.26 |
| 14:49:44 | ETHD | SELL | 50.0 | $50.355 | $2,517.75 |
| 12:37:41 | CELH | SELL | 100.0 | $34.92 | $3,492.00 |
| 12:15:03 | XLC | SELL | 117.7 | 100.0 | $11,770.00 |
| 11:42:30 | CDE | SELL | 250.0 | $19.44 | $4,860.00 |
| 11:41:31 | CELH | SELL | 100.0 | $34.92 | $3,492.00 |
| 11:40:50 | CELH | BUY | 100.0 | $35.325 | $3,532.50 |
| 11:24:50 | ETHD | BUY | 50.0 | $50.6 | $2,530.00 |
| 11:23:05 | GLDM | SELL | 250.0 | $93.74 | $23,435.00 |
| 11:22:37 | RIOT | SELL | 150.0 | $23.65 | $3,547.50 |
| 11:21:37 | XLC | SELL | 100.0 | $117.7 | $11,770.00 |
| 11:09:30 | ETHD | SELL | 50.0 | $50.05 | $2,502.50 |
| 10:59:05 | CGNT | SELL | 250.0 | $10.9404 | $2,735.10 |
| 10:58:18 | CGNT | BUY | 250.0 | $11.1799 | $2,794.98 |
| 10:56:37 | XLC | BUY | 100.0 | $117.92 | $11,792.00 |
| 10:54:52 | GLDM | BUY | 250.0 | $94.1999 | $23,549.98 |
| 10:53:55 | XLK | SELL | 100.0 | $171.65 | $17,165.00 |
| 10:51:51 | BAND | BUY | 50.0 | $48.4 | $2,420.00 |
| 10:50:49 | IREN | SELL | 100.0 | $61.24 | $6,124.00 |
| 10:50:00 | OMDA | SELL | 200.0 | $16.08 | $3,216.00 |
| 10:47:03 | IREN | BUY | 100.0 | $61.97 | $6,197.00 |
| 10:44:43 | RIOT | BUY | 150.0 | $23.83 | $3,574.50 |
| 10:43:02 | CDE | BUY | 250.0 | $19.79 | $4,947.50 |
| 10:40:31 | MUX | SELL | 200.0 | $25.9301 | $5,186.02 |
| 10:38:00 | FTNT | SELL | 100.0 | $110.41 | $11,041.00 |
| 10:37:02 | ETHD | SELL | 50.0 | $50.05 | $2,502.50 |
| 10:34:21 | MUX | SELL | 200.0 | $25.9301 | $5,186.02 |
| 10:29:25 | OMDA | BUY | 200.0 | $16.3 | $3,260.00 |
| 10:11:20 | XLK | BUY | 50.0 | $170.9256 | $8,546.28 |
| 10:09:13 | XLK | BUY | 50.0 | $170.98 | $8,549.00 |
| 10:04:39 | MUX | BUY | 100.0 | $25.6 | $2,560.00 |
| 09:55:23 | FTNT | BUY | 100.0 | $110.87 | $11,087.00 |
| 09:51:33 | MUX | BUY | 100.0 | $25.5 | $2,550.00 |
| 09:49:33 | ETHD | BUY | 50.0 | $49.905 | $2,495.25 |

## Summary of Moves
The session was characterized by high-velocity turnover across multiple names (ETHD, XLK, MUX, OMDA, CELH). The execution log shows a pattern of entering positions early in the morning session (09:49–10:29) and liquidating them within 1-2 hours. Notably, several positions were closed for minor losses or break-evens (ETHD, FTNT, CELH, CGNT), suggesting a lack of follow-through or defensive tightening in a volatile environment.

## Execution Efficiency & SMC Audit

### 1. XLK (Shield Audit)
- **SMC Baseline**: STRIKE Authorized. Strike Zone: $169.50–$170.03. POC: $154.46.
- **Efficiency**: BUY executions at $170.98 and $170.92 were **Premium Entries**, slightly above the authorized Strike Zone. SELL at $171.65 captured a small profit but failed to hold for the target expansion toward $173.66. Entry was within the upper FVG support, but exit was premature based on Shield Strategy momentum trailing rules.

### 2. IREN (Shield Audit)
- **SMC Baseline**: **WAIT (Protect Capital)**. Authoritative Strike Zone: $53.24–$54.00.
- **Efficiency**: **FAILED PROTOCOL**. The BUY at $61.97 was a gross violation of the "Wait" directive. The analysis explicitly warned that the price was "trading in thin air" above the $53.24 VAH. Liquidation at $61.24 confirms a "Chasing the Wick" error, resulting in avoidable slippage.

### 3. RIOT (Shield Audit)
- **SMC Baseline**: SCOUT Authorized (0.5R). Strike Zone: $22.80–$23.10.
- **Efficiency**: BUY at $23.83 was an **Over-Extended Entry**, ignoring the premium zone warning. SELL at $23.65 indicates a failed scout. Entering $0.70 above the authorized zone in a high-beta asset significantly compromised the RR ratio.

### 4. OMDA (Sniper Audit)
- **SMC Baseline**: STRIKE Authorized. Strike Zone: $15.15–$15.30. Target: $16.35.
- **Efficiency**: BUY at $16.30 was a **Maximum Premium Entry**, essentially buying at the primary target price instead of the strike zone. SELL at $16.08 realized a loss on a trade that should have been a winner if entered at the $15.15 base. This is a clear case of "FOMO Chasing" at structural resistance.

### 5. BAND (Sniper Audit)
- **SMC Baseline**: **WAIT (Retain Cash)**. Trigger: $47.55.
- **Efficiency**: BUY at $48.40 and SELL at $48.42. While mathematically break-even, this trade ignored the "Wait" directive and entered in a "Distribution" phase identified by insider selling.

## Performance Notes
- **Strategy Reflection**: The - $612.07 PNL is a direct result of **Structural Chasing**. The auditor reports for IREN, BAND, and RIOT all explicitly advised waiting or scouting at lower levels, yet entries were consistently placed in "Premium" or "Thin Air" zones.
- **Risk Violation**: Entering OMDA at the target price ($16.30) and IREN at $61.97 indicates a significant deviation from the Grinder/Sniper risk tiers. You are paying the "Retail Premium" rather than wait for the "Institutional Discount" (Strike Zones).
- **Corrective Action**: REVERT to 0.5R Scouts. You are currently fighting the tape by chasing vertical extensions. Re-anchor to the Point of Control (POC) and only fire when price is within the authorized Strike Zone.

---
*Generated by Cobalt Multiagent Journaler*