> **Generated:** Saturday, May 16, 2026 at 07:03 AM

Active Strategy: Sniper Strategy

### 1. Execution Summary

**SCOUT Authorized** (Transitioning to **WAIT** at current levels). 

SPIR is presenting as a high-velocity "Sword" asset today, surging `7.87%` to `$20.01`. Despite the bullish macro structural shift triggered by a Daily CHoCH at `$10.19`, current conditions dictate strict Sniper discipline. The stock's Day Trading Sortino Ratio currently sits at `0.71`, drastically failing our strict `2.0` institutional hurdle. This highlights extreme downside deviation relative to its recent vertical expansion. 

Furthermore, the tape is reacting to a confirmed 5-minute bearish liquidity sweep at `$19.84`, compounded by heavy supply overhang news regarding a massive resale registration. A full `1R` STRIKE is denied. We are authorizing a `0.5R` SCOUT deployment only if the price safely retraces into the `$18.52` high-volume institutional pocket. Chasing the current premium is mathematically prohibited.

---

### 2. Institutional News & Social Sentiment

- **5,000,000-share resale registration by Spire Global after $70M private placement** (Stock Titan, ~2h ago)
- **Spire Global CEO Theresa Condor sells $21,972 in stock** (Investing.com, ~4h ago)
- **Spire Global registers 3,162,500 shares; Canada contract terminated** (Stock Titan, ~6h ago)

**Sentiment Synthesis**: The prevailing institutional narrative is clouded by a massive potential distribution wall. Private investors registering `5,000,000` shares for resale acts as a heavy supply overhang, naturally capping upside momentum and aligning perfectly with the bearish liquidity sweep observed on the tape. Insider tax sales add minor friction, making social and institutional sentiment largely cautious at these elevated premiums.

---

### 3. Structural Audit & Tape Reading

- **Macro Trend (1d)**: Bullish (CHoCH mapped at `$10.19`)
- **Current Price**: `$20.01`
- **Session Volume**: `2,900,400` shares
- **Mathematical Hurdle**: **[FAIL]** Day Trading Sortino Ratio is `0.71` (Minimum required is `2.0`).

**Volume Profile (Dual-Anchor)**:
- **Macro 60d POC**: `$18.52` (Primary institutional defense node)
- **Macro 60d VAH / VAL**: `$23.59` / `$12.09`
- **Tactical 5d POC**: `$18.17`
- **Tactical 5d VAH / VAL**: `$20.04` / `$16.59`

**Institutional Footprint (SMC)**:
- **Liquidity Sweep**: YES. Bearish sweep triggered at `$19.84` on the 5m timeframe. Price is currently rejecting this premium zone.
- **Bullish Fair Value Gaps (FVG)**: `$18.13` - `$18.27` (Immediate downside magnet) and `$16.05` - `$17.63`.
- **Order Blocks**: Macro Bullish OB established at `$8.30` - `$8.87`.

---

### 4. Execution Parameters

Deploy a half-sized Sniper Scout only upon a confirmed test of the Macro POC and upper FVG. 

- **Execution State**: **SCOUT**
- **Risk Unit**: `0.5R` (`$125.00`)
- **Strike Zone (Entry)**: `$18.50` - `$18.75`
- **Hard Stop**: `$17.90` (Placed safely below the `$18.17` 5-day Tactical POC)
- **Share Quantity**: `208` Shares
- **Invalidation Level (Kill Switch)**: A break below `$16.59` (Session VAL) invalidates the intraday thesis. Halt all engagement if breached.