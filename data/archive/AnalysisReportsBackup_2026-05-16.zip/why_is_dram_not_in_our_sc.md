> **Generated:** Monday, May 11, 2026 at 09:10 AM

The exclusion of **$DRAM** (Roundhill Memory ETF) from the institutional scanner list is primarily a function of **structural seasoning** and **statistical noise** rather than a lack of liquidity or performance. 

As of **May 11, 2026**, the asset is currently being filtered out by automated risk parameters designed to ensure data fidelity and trend reliability.


---


### I. INSTITUTIONAL AGE & SEASONING HURDLES

Most high-fidelity scanners, including those utilizing **SMC (Smart Money Concepts)** or **ATR (Average True Range)** baselines, require a minimum lookback period to establish technical validity.

*   **Timeline Deficit**: **$DRAM** launched on `April 2, 2026`. As of the current date, it has only been trading for approximately `27` sessions.
*   **Standard Filter**: Institutional protocols typically require a **63-day** (one full quarter) seasoning period to calculate reliable volatility metrics. 
*   **Status**: The asset is currently trapped in the "New Listing" filter zone, preventing it from populating in scans that require established trend history.


---


### II. STATISTICAL ANOMALIES & SORTINO DISRUPTION

The recent price action in **$DRAM** has created a statistical profile that professional risk engines often interpret as "Incomplete Data."

*   **Extreme Sortino Ratio**: The asset is showing a **Day Trading Sortino** of `8.96`. While seemingly positive, any value over `5.0` is frequently flagged as an anomaly or a "news-driven squeeze."
*   **Volatility Gap**: A massive `13.43%` gap has distorted the downside deviation calculation. Because there hasn't been enough sustained downside price action since the launch, the scanner views the risk-adjusted return as mathematically "unsustainable" for long-term trend following.
*   **Volume Profile**: While daily volume is significant at `41,325,404` shares, the lack of a **three-month average** prevents the system from confirming if this liquidity is structural or temporary.


---


### III. STRUCTURAL FILTERS & EXCHANGE MAPPING

The technical architecture of the ETF itself may be triggering "Diversity" or "Exchange" suppression rules within the scanner logic.

*   **Exchange Listing**: **$DRAM** is listed on the **Cboe BZX**. Scanners strictly configured for **NYSE** or **NASDAQ** primary listings will bypass this asset by default to avoid potential liquidity gaps common in secondary exchange ETFs.
*   **Concentration Risk**: The fund is an ultra-concentrated "pure play" with only `13` holdings. 
*   **Proxy Overlap**: Nearly `75%` of the fund's weight is concentrated in three names:
    1.  **Micron ($MU)**: `27.33%`
    2.  **SK Hynix**: `26.37%`
    3.  **Samsung**: `20.42%`
*   **System Logic**: If **$MU** is already active in your scanner, the system may suppress **$DRAM** to prevent "Over-Concentration" signals in the memory sector, as the ETF effectively trades as a high-fee proxy for the top holdings.


---


### EXECUTION PARAMETERS (PROXY)

Because **$DRAM** is currently "Shadow-Banned" by age and technical noise, the recommendation is to utilize the primary underlying component for trade execution until the ETF hits the **63-day** maturity mark.

*   **Primary Vehicle**: **$MU** (Micron Technology Inc)
*   **Rationale**: **$MU** provides the necessary historical data (ATR, POC, VAH) required for valid **SMC** structural analysis.
*   **Strike Zone**: Monitor the current **$DRAM** price of `$52.80` as a sentiment gauge, but execute on **$MU** levels to ensure hard-stop integrity.


---


**Status**: **Filtered for Maturity**.
The asset will likely populate automatically once the **Q1 2026** lookback window is satisfied and the Sortino ratio stabilizes below the anomaly threshold.