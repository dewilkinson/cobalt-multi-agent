> **Generated:** Wednesday, May 13, 2026 at 08:27 AM

The institutional pulse for the session dated **Wed May 13 2026** reflects a significant bifurcation between high-beta technology and digital asset proxies. Following the manual trigger of the analysis orchestrator, the **Apex Satellite Scan** has identified five primary candidates exhibiting notable Relative Strength (`RS`) and Volume profiles. 


The standout performer in today's audit is **MARA**, maintaining an `A+` grade with a pre-market gap of `1.35%`, significantly outperforming the **SPY** benchmark of `0.21%`. This suggests aggressive institutional accumulation within the crypto-mining sector, contrasted sharply by **COIN**, which exhibits relative weakness with a `-0.10%` change and a `C` grade. Within the semiconductor space, **AMD** holds a structural advantage over **NVDA** in the immediate term, with the former showing a fully synchronized (`🟢 [SYNC]`) report status and superior momentum at `0.79%`.


---


### **APEX SATELLITE SCAN: PERFORMANCE AUDIT**


| Symbol | Current Price | Grade | Report Status | Momentum |
| :--- | :--- | :---: | :---: | :--- |
| **MARA** | `$12.72` | **A+** | 🟢 **[SYNC]** | `1.35%` |
| **AMD** | `$448.29` | **A** | 🟢 **[SYNC]** | `0.79%` |
| **TSLA** | `$433.45` | **A-** | 🟢 **[SYNC]** | `0.72%` |
| **NVDA** | `$220.78` | **B+** | 🟡 **[WAIT]** | `0.59%` |
| **COIN** | `$207.64` | **C** | 🔴 **[MISS]** | `-0.10%` |


---


### **QUANTITATIVE CONTEXT & SCANNER METRICS**


*   **Benchmark Performance**: **SPY** is currently trading at `$738.18`, reflecting a modest upward bias of `0.21%`. Candidates graded **A-** or higher are currently demonstrating significant alpha relative to the index.


*   **Institutional Order Flow**: **MARA** and **AMD** are seeing the highest **Relative Volume (RVOL)** at `2.4x` and `1.8x` respectively, confirming that the price action is backed by institutional participation rather than retail exhaustion.


*   **Structural Alignment**: **TSLA** has moved into a 🟢 **[SYNC]** state following a mean reversion move, currently holding `0.72%` gains. Traders should monitor the `B+` rated **NVDA** for a transition to `SYNC` once the `1d POC` (Point of Control) aligns with current price action.


*   **Scanner Universe**: 
    *   **Total Symbols Evaluated**: `4,200+`
    *   **Watchlist Filter Pass**: `142`
    *   **Final Apex Candidates**: `5`


---


**[SYSTEM STATUS]**: Background analysis orchestrator is currently active. Full structural audits, including **Sortino Ratio** and **Volume Profile** (VAH/VAL) deep-dives, are available for all 🟢 **[SYNC]** status symbols. 


To initiate a deep-dive into any high-grade candidate, please specify: **"Run full scan for [Symbol]"**.


**Dave Wilkinson**
Founder & Developer
Blueshell Securities LLC