> **Generated:** Saturday, May 16, 2026 at 07:06 AM

Active Strategy: Sniper Strategy

### 1. Execution Summary

**STRIKE Authorized.** SG has successfully cleared the macro ceiling at `6.30` (CHoCH) and is currently trading in a high-velocity extension at `$8.09`. The Sortino Ratio of `2.94` confirms institutional-grade risk-adjusted efficiency, safely surpassing our `2.0` mathematical hurdle. 

With massive relative tape strength generating a `+17.25%` surge on nearly `9,943,500` shares of volume, this asset is acting as an aggressive "Sword" for the portfolio. The 5m liquidity sweep at `8.00` provides a high-compression base, validating a Sniper entry to capture the continuation of this institutional displacement.

---

### 2. Institutional News & Social Sentiment

[DATA_UNAVAILABLE]

---

### 3. Market Structure & Institutional Footprint

*   **Trend Bias**: Bullish (MTF Alignment).
*   **Macro Structure (1d)**: Structural Trend Change (CHoCH) confirmed at `6.30`, converting the previous cycle peak into primary support.
*   **Tactical Point of Control (POC)**: `6.85`. The Session and 5d POC alignment confirms that institutional capital has anchored their cost basis higher to defend the breakout.
*   **Bullish Order Block (Launchpad)**: `6.16` - `6.71`. 
*   **Fair Value Gap (Magnet)**: `6.77` - `6.89`.
*   **Liquidity Mechanics**: External Sell-Side Liquidity (SSL) was recently swept at `8.00`, clearing the structural path for higher discovery.

---

### 4. Mathematical Hurdles

*   **Sortino Ratio**: `2.94` (**[PASS]** vs. `2.0` hurdle)
*   **Downside Deviation**: `0.50%`
*   **Volatility (ATR)**: `0.04` (5m timeframe)

---

### 5. Execution Parameters

*   **Execution State**: **STRIKE Authorized**
*   **Share Quantity**: `1000` 
*   **Risk Unit**: `$250` (1R)
*   **Strike Zone**: `8.05` - `8.12`
*   **Hard Stop**: `7.85` (Momentum stop below the 5m liquidity sweep low)
*   **Kill Switch**: `7.16` (Session VAL. A breach here invalidates the intraday thesis).